--
-- PostgreSQL database dump
--

\restrict hdZ4s6X8j8fV9Y252u3h9Kf8vmuNNpayYQnC0zvfSfuZdLOe2NyWN8mEUyOIUv0

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_credor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_credor (
    credor_id text NOT NULL,
    portal_slug text NOT NULL,
    fornecedor_cpf_cnpj text,
    fornecedor_nome text,
    fornecedor_cidade text
);


--
-- Name: dim_date; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_date (
    data date NOT NULL,
    ano integer NOT NULL,
    mes_num integer,
    dia integer,
    dia_semana integer,
    mes_nome text,
    inicio_mes date,
    fim_mes date,
    trimestre integer
);


--
-- Name: dim_elemento_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_elemento_despesa (
    elemento_codigo text NOT NULL,
    elemento_descricao text NOT NULL,
    categoria_macro text NOT NULL
);


--
-- Name: dim_funcao_subfuncao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_funcao_subfuncao (
    funcao_subfuncao_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    funcao_nome text NOT NULL,
    subfuncao_codigo text NOT NULL,
    subfuncao_nome text NOT NULL
);


--
-- Name: dim_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_metadata (
    portal_slug text,
    key text,
    value text
);


--
-- Name: dim_natureza_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_natureza_despesa (
    natureza_despesa_codigo text NOT NULL,
    categoria_economica_codigo text NOT NULL,
    categoria_economica_nome text NOT NULL,
    gnd_codigo text NOT NULL,
    gnd_nome text NOT NULL,
    modalidade_codigo text NOT NULL,
    modalidade_nome text NOT NULL
);


--
-- Name: dim_orgao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_orgao (
    orgao_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    orgao_nome text
);


--
-- Name: dim_portais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_portais (
    portal_slug text NOT NULL,
    display_name text,
    uf text,
    portal_url text,
    base_host text,
    cidade_clean text,
    ano_inicial integer,
    empresa_padrao text,
    brasao_asset text,
    data_extracao date
);


--
-- Name: fct_analise_despesas_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_analise_despesas_metricas (
    analise_despesas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    orgao_codigo text NOT NULL,
    unidade_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    total_dotacao_atualizada numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL
);


--
-- Name: fct_caprem_cadprev_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_cadprev_metricas (
    caprem_cadprev_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empenho_id text,
    descricao text,
    data_empenho date,
    empenhado numeric NOT NULL,
    pago numeric NOT NULL
);


--
-- Name: fct_caprem_entidades_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_entidades_metricas (
    caprem_entidade_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    entidade text NOT NULL,
    empenhado numeric NOT NULL,
    liquidado numeric NOT NULL,
    pago numeric NOT NULL,
    taxa_execucao numeric NOT NULL
);


--
-- Name: fct_caprem_natureza_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_natureza_metricas (
    caprem_natureza_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empenho_id text,
    elemento text NOT NULL,
    natureza_despesa text NOT NULL,
    destino text NOT NULL,
    descricao text,
    data_empenho date,
    empenhado numeric NOT NULL,
    liquidado numeric NOT NULL,
    pago numeric NOT NULL
);


--
-- Name: fct_caprem_tendencia_atuarial_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_tendencia_atuarial_metricas (
    caprem_tendencia_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    aporte_exigido numeric NOT NULL,
    aporte_quitado numeric NOT NULL,
    taxa_adimplencia numeric NOT NULL,
    amortizacao_divida numeric NOT NULL
);


--
-- Name: fct_contratos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_contratos (
    contrato_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    contrato_numero text,
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    objeto text,
    valor_contrato numeric,
    valor_aditado numeric,
    licitacao_numero text,
    modalidade text,
    mes text,
    tipo_obra text,
    numero_obra text,
    fundlegal text,
    empenhado numeric,
    objeto_completo text,
    data_inicio date,
    vencimento_atual date,
    saldo_a_empenhar numeric
);


--
-- Name: fct_contratos_servicos_vigentes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_contratos_servicos_vigentes (
    contrato_servico_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    contrato_numero text,
    fornecedor_nome text,
    fornecedor_cnpj text,
    objeto_descricao text,
    data_inicio date,
    vencimento_atual date,
    valor_aditado numeric,
    total_empenhado numeric,
    total_liquidado numeric,
    total_pago numeric,
    status_execucao text NOT NULL
);


--
-- Name: fct_despesas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas (
    despesa_id text NOT NULL,
    portal_slug text NOT NULL,
    fonte text,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    empenho_id text NOT NULL,
    pk_empenho text,
    tipo_empenho text,
    orgao_codigo text,
    unidade_codigo text,
    funcao text,
    funcao_nome text,
    subfuncao text,
    subfuncao_nome text,
    elemento text,
    natureza_despesa text,
    grupo_natureza text,
    modalidade text,
    programa text,
    programa_nome text,
    proj_atividade text,
    projeto_atividade_nome text,
    mes text,
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    licitacao_numero text,
    licitacao_modalidade text,
    fonte_recurso_desc text,
    descricao text,
    natureza_despesa_codigo text,
    natureza_despesa_codigo_sugerido text,
    natureza_despesa_nome_sugerido text,
    categoria_objeto_sugerida text,
    categoria_gasto_sensivel text,
    credor_id text,
    orgao_id text,
    data_empenho date,
    empenhado numeric,
    empenhado_liquido numeric,
    liquidado numeric,
    pago numeric,
    dotacao_inicial numeric,
    alteracao_dotacao numeric,
    dotacao_atualizada numeric,
    reforco numeric,
    valor_anulacoes numeric
);


--
-- Name: fct_despesas_diarias_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_diarias_metricas (
    diarias_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    favorecido text NOT NULL,
    cargo text NOT NULL,
    total_valor numeric NOT NULL,
    qtd_concessoes integer NOT NULL
);


--
-- Name: fct_despesas_fornecedores_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_fornecedores_metricas (
    fornecedores_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    fornecedor_codigo text NOT NULL,
    fornecedor_nome text NOT NULL,
    fornecedor_cidade_clean text NOT NULL,
    total_empenhado numeric NOT NULL,
    total_pago numeric NOT NULL
);


--
-- Name: fct_despesas_por_fornecedor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_por_fornecedor (
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    fornecedor_cpf_cnpj text,
    fornecedor_cidade_clean text,
    fornecedor_cidade text,
    empenhado numeric,
    liquidado numeric,
    pago numeric
);


--
-- Name: fct_despesas_por_orgao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_por_orgao (
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    empenhado numeric,
    liquidado numeric,
    pago numeric,
    dotacao_atualizada numeric
);


--
-- Name: fct_despesas_por_unidade; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_por_unidade (
    portal_slug text,
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    empenhado numeric,
    liquidado numeric,
    pago numeric,
    dotacao_atualizada numeric
);


--
-- Name: fct_despesas_restos_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_restos_metricas (
    restos_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    restos_inscritos numeric,
    restos_liquidados numeric,
    restos_pagos numeric,
    restos_cancelados numeric,
    saldo_restos numeric,
    divida_mais_antiga_ano integer NOT NULL
);


--
-- Name: fct_diarias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_diarias (
    id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    diaria_id text,
    valor numeric,
    favorecido text,
    cargo text,
    data date,
    unidade text,
    descricao text
);


--
-- Name: fct_emendas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_emendas (
    emenda_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    numero_emenda text,
    resumo text,
    valor_total numeric,
    empenhado numeric,
    autor text,
    tipo_emenda text,
    esfera_origem text,
    ato_normativo text,
    destinacao text
);


--
-- Name: fct_execucao_orcamentaria_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_execucao_orcamentaria_metricas (
    execucao_orcamentaria_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    orgao_codigo text NOT NULL,
    orgao_nome text,
    unidade_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    subfuncao_codigo text NOT NULL,
    total_dotacao_atualizada numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL,
    saldo_orcamentario numeric NOT NULL,
    taxa_execucao numeric NOT NULL,
    alerta_execucao text NOT NULL
);


--
-- Name: fct_fontes_receita_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_fontes_receita_metricas (
    fontes_receita_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    receita_propria_previsto numeric NOT NULL,
    receita_propria_arrecadado numeric NOT NULL,
    transferencias_uniao_previsto numeric NOT NULL,
    transferencias_uniao_arrecadado numeric NOT NULL,
    transferencias_estado_previsto numeric NOT NULL,
    transferencias_estado_arrecadado numeric NOT NULL,
    receita_extra_orcamentaria_arrecadado numeric NOT NULL,
    total_previsto numeric NOT NULL,
    total_arrecadado numeric NOT NULL,
    pct_propria numeric NOT NULL,
    alerta_dependencia boolean NOT NULL,
    fpm_arrecadado numeric NOT NULL,
    icms_arrecadado numeric NOT NULL,
    iss_iptu_arrecadado numeric NOT NULL,
    emendas_pix_arrecadado numeric NOT NULL,
    emendas_individuais_arrecadado numeric NOT NULL,
    emendas_total_arrecadado numeric NOT NULL,
    emendas_total_empenhado numeric NOT NULL
);


--
-- Name: fct_historia_caprem_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_historia_caprem_metricas (
    historia_caprem_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    total_aporte_exigido numeric NOT NULL,
    total_aporte_quitado numeric NOT NULL,
    taxa_adimplencia_aporte numeric NOT NULL,
    total_empenhado_patronal numeric NOT NULL,
    total_liquidado_patronal numeric NOT NULL,
    total_pago_patronal numeric NOT NULL,
    rombo_patronal_nao_repassado numeric NOT NULL,
    total_amortizacao_divida numeric NOT NULL,
    total_casp_plano_saude numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL,
    servidores_efetivos integer NOT NULL,
    servidores_temporarios integer NOT NULL
);


--
-- Name: fct_historia_saude_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_historia_saude_metricas (
    historia_saude_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    dotacao_total numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL,
    medicamentos_insumos_empenhado numeric NOT NULL,
    medicamentos_insumos_pago numeric NOT NULL,
    judicializacao_empenhado numeric NOT NULL,
    judicializacao_pago numeric NOT NULL,
    emendas_saude_arrecadado numeric NOT NULL,
    hhi_concentracao_fornecedores integer NOT NULL,
    receita_uniao_saude numeric NOT NULL,
    receita_estado_saude numeric NOT NULL,
    repasses_prefeitura_saude numeric NOT NULL,
    uniao_sus_pct integer NOT NULL,
    estado_pct integer NOT NULL,
    propria_pct integer NOT NULL
);


--
-- Name: fct_licitacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_licitacoes (
    licitacao_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    licitacao_numero text,
    modalidade text,
    objeto text,
    discriminacao text,
    valor numeric,
    situacao text,
    data_abertura date,
    carona text
);


--
-- Name: fct_licitacoes_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_licitacoes_metricas (
    licitacao_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    tipo_contratacao text,
    numero text,
    licitacao_numero text,
    contrato_numero text,
    fornecedor_nome text,
    objeto text,
    modalidade text,
    fundlegal text,
    carona text,
    mes integer,
    numero_obra text,
    tipo_obra text,
    quantidade integer,
    licitacao_valor numeric(15,2),
    valor_contrato numeric(15,2),
    empenhado_contrato numeric(15,2),
    pago_contrato numeric(15,2),
    data_referencia date,
    limite_dispensa numeric(15,2),
    isento_legalmente boolean,
    acima_limite boolean
);


--
-- Name: fct_licitacoes_modalidades_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_licitacoes_modalidades_metricas (
    modalidade_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    modalidade text,
    quantidade integer,
    valor_total numeric(15,2)
);


--
-- Name: fct_opacidade_contabil_credores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_opacidade_contabil_credores (
    opacidade_credor_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    credor_codigo text NOT NULL,
    credor_nome text NOT NULL,
    total_empenhos integer NOT NULL,
    total_pago numeric NOT NULL,
    pago_desvio_sensivel numeric NOT NULL,
    categoria_predominante text NOT NULL,
    amostra_objeto text NOT NULL,
    ranking integer NOT NULL
);


--
-- Name: fct_opacidade_contabil_elementos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_opacidade_contabil_elementos (
    opacidade_elemento_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    elemento_codigo text NOT NULL,
    elemento_descricao text NOT NULL,
    categoria_macro text NOT NULL,
    tipo_residual text NOT NULL,
    total_empenhos integer NOT NULL,
    total_pago numeric NOT NULL,
    percentual_do_residual_99 numeric NOT NULL,
    ranking integer NOT NULL
);


--
-- Name: fct_opacidade_contabil_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_opacidade_contabil_metricas (
    opacidade_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    total_empenhos integer NOT NULL,
    empenhos_residual_99 integer NOT NULL,
    empenhos_desvio_sensivel_99 integer NOT NULL,
    taxa_empenhos_opacidade_pct numeric NOT NULL,
    total_pago numeric NOT NULL,
    pago_residual_99 numeric NOT NULL,
    pago_desvio_sensivel_99 numeric NOT NULL,
    taxa_valor_opacidade_pct numeric NOT NULL,
    taxa_desvio_sensivel_pct numeric NOT NULL,
    classificacao_risco text NOT NULL
);


--
-- Name: fct_orcamento_funcional_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_orcamento_funcional_metricas (
    orcamento_funcional_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    funcao_nome text NOT NULL,
    subfuncao_nome text NOT NULL,
    dotacao_atualizada numeric NOT NULL,
    empenhado numeric NOT NULL,
    liquidado numeric NOT NULL,
    pago numeric NOT NULL
);


--
-- Name: fct_pessoal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_pessoal (
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    proventos numeric,
    categoria_funcional text,
    vinculo text,
    cargo text,
    forma_provimento text
);


--
-- Name: fct_pessoal_departamento_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_pessoal_departamento_metricas (
    departamento_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    descricao text,
    total_pago numeric(15,2)
);


--
-- Name: fct_pessoal_folha_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_pessoal_folha_metricas (
    pessoal_folha_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    total_folha numeric(15,2),
    total_pago numeric(15,2),
    empenhado_13 numeric(15,2),
    empenhado_bruto_13 numeric(15,2),
    liquidado_13 numeric(15,2),
    pago_13 numeric(15,2),
    efetivos_confianca integer,
    comissionados_externos integer,
    bin_0_25k integer,
    bin_25k_5k integer,
    bin_5k_75k integer,
    bin_75k_10k integer,
    bin_10k_125k integer,
    bin_125k_15k integer,
    bin_15k_175k integer,
    bin_175k_20k integer,
    bin_acima_20k integer
);


--
-- Name: fct_posicao_fiscal_detalhes_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_posicao_fiscal_detalhes_metricas (
    posicao_fiscal_detalhes_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    administracao text NOT NULL,
    valor_empenhado numeric NOT NULL,
    valor_liquidado numeric NOT NULL,
    valor_pago numeric NOT NULL,
    valor_pendente numeric NOT NULL,
    fornecedor_nome text
);


--
-- Name: fct_posicao_fiscal_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_posicao_fiscal_metricas (
    posicao_fiscal_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    total_arrecadado numeric NOT NULL,
    despesas_pagas numeric NOT NULL,
    restos_liquidados_no_ano numeric NOT NULL,
    restos_pagos_no_ano numeric NOT NULL,
    restos_pendentes_adm_anterior numeric NOT NULL,
    restos_pendentes_adm_atual numeric NOT NULL,
    saldo_estimado numeric NOT NULL
);


--
-- Name: fct_receita_extra_orcamentaria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_receita_extra_orcamentaria (
    receita_extra_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    codigo text,
    descricao text,
    valor_arrecadado numeric NOT NULL
);


--
-- Name: fct_receitas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_receitas (
    receita_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    tipo_receita text,
    codigo text,
    descricao text,
    previsao_atualizada numeric,
    arrecadado numeric
);


--
-- Name: fct_transferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_transferencias (
    transferencia_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    mes text,
    entidade_pagadora text,
    entidade_recebedora text,
    repasse numeric,
    devolucao numeric
);


--
-- Name: seed_constantes_fiscais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_constantes_fiscais (
    dominio text,
    chave text,
    ano_inicio integer,
    ano_fim integer,
    valor_num numeric,
    valor_txt text,
    descricao text,
    base_legal text,
    url_base_legal text
);


--
-- Name: seed_elemento_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_elemento_despesa (
    elemento_codigo text,
    elemento_descricao text,
    categoria_macro text
);


--
-- Name: seed_funcao_subfuncao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_funcao_subfuncao (
    funcao_subfuncao_codigo text,
    funcao_codigo text,
    funcao_nome text,
    subfuncao_codigo text,
    subfuncao_nome text
);


--
-- Name: seed_natureza_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_natureza_despesa (
    natureza_despesa_codigo text,
    categoria_economica_codigo text,
    categoria_economica_nome text,
    gnd_codigo text,
    gnd_nome text,
    modalidade_codigo text,
    modalidade_nome text
);


--
-- Name: seed_naturezas_despesa_stn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_naturezas_despesa_stn (
    natureza_codigo text,
    natureza_descricao text,
    elemento_codigo text,
    categoria_macro text,
    is_sensivel boolean
);


--
-- Name: seed_porciuncula_prefeitura_orgaos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_porciuncula_prefeitura_orgaos (
    portal_slug text,
    empresa_id integer,
    nome text
);


--
-- Name: seed_portais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_portais (
    portal_slug text,
    display_name text,
    uf text,
    portal_url text,
    base_host text,
    cidade_clean text,
    ano_inicial integer,
    empresa_padrao text,
    brasao_asset text
);


--
-- Name: dim_elemento_despesa dim_elemento_despesa__dbt_tmp_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_elemento_despesa
    ADD CONSTRAINT dim_elemento_despesa__dbt_tmp_pkey1 PRIMARY KEY (elemento_codigo);


--
-- Name: dim_funcao_subfuncao dim_funcao_subfuncao__dbt_tmp_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_funcao_subfuncao
    ADD CONSTRAINT dim_funcao_subfuncao__dbt_tmp_pkey1 PRIMARY KEY (funcao_subfuncao_codigo);


--
-- Name: dim_natureza_despesa dim_natureza_despesa__dbt_tmp_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_natureza_despesa
    ADD CONSTRAINT dim_natureza_despesa__dbt_tmp_pkey1 PRIMARY KEY (natureza_despesa_codigo);


--
-- Name: 036b5d63e1c0b8fca8fe76c8ab51ee36; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "036b5d63e1c0b8fca8fe76c8ab51ee36" ON public.fct_despesas USING btree (funcao);


--
-- Name: 3a44aa73eca990a4bda5fc0acaade816; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "3a44aa73eca990a4bda5fc0acaade816" ON public.fct_despesas USING btree (categoria_gasto_sensivel);


--
-- Name: 3d937f2703d2c9bd2b3003c639792cd6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "3d937f2703d2c9bd2b3003c639792cd6" ON public.fct_despesas USING btree (fornecedor_cpf_cnpj);


--
-- Name: 7d9eb55e146e91d4365271bc470741a3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "7d9eb55e146e91d4365271bc470741a3" ON public.fct_despesas USING btree (portal_slug, ano, empresa_id);


--
-- Name: 7f20e1c23e9ad13ffc093c2f49ad4480; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "7f20e1c23e9ad13ffc093c2f49ad4480" ON public.fct_despesas USING btree (elemento);


--
-- Name: 8bd25cf6f748f337409c957286340cba; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "8bd25cf6f748f337409c957286340cba" ON public.fct_despesas USING btree (portal_slug, ano);


--
-- Name: ace7b3382a309dca45db76c0f5f969ab; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ace7b3382a309dca45db76c0f5f969ab ON public.fct_despesas USING btree (fonte);


--
-- Name: dim_credor; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_credor ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_date; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_date ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_elemento_despesa; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_elemento_despesa ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_funcao_subfuncao; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_funcao_subfuncao ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_metadata; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_metadata ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_natureza_despesa; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_natureza_despesa ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_orgao; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_orgao ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_portais; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dim_portais ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_analise_despesas_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_analise_despesas_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_caprem_cadprev_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_caprem_cadprev_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_caprem_entidades_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_caprem_entidades_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_caprem_natureza_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_caprem_natureza_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_caprem_tendencia_atuarial_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_caprem_tendencia_atuarial_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_contratos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_contratos ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_contratos_servicos_vigentes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_contratos_servicos_vigentes ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_despesas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_despesas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_despesas_diarias_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_despesas_diarias_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_despesas_fornecedores_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_despesas_fornecedores_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_despesas_por_fornecedor; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_despesas_por_fornecedor ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_despesas_por_orgao; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_despesas_por_orgao ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_despesas_por_unidade; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_despesas_por_unidade ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_despesas_restos_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_despesas_restos_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_diarias; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_diarias ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_emendas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_emendas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_execucao_orcamentaria_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_execucao_orcamentaria_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_fontes_receita_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_fontes_receita_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_historia_caprem_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_historia_caprem_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_historia_saude_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_historia_saude_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_licitacoes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_licitacoes ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_licitacoes_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_licitacoes_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_licitacoes_modalidades_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_licitacoes_modalidades_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_opacidade_contabil_credores; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_opacidade_contabil_credores ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_opacidade_contabil_elementos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_opacidade_contabil_elementos ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_opacidade_contabil_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_opacidade_contabil_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_orcamento_funcional_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_orcamento_funcional_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_pessoal; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_pessoal ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_pessoal_departamento_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_pessoal_departamento_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_pessoal_folha_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_pessoal_folha_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_posicao_fiscal_detalhes_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_posicao_fiscal_detalhes_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_posicao_fiscal_metricas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_posicao_fiscal_metricas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_receita_extra_orcamentaria; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_receita_extra_orcamentaria ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_receitas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_receitas ENABLE ROW LEVEL SECURITY;

--
-- Name: fct_transferencias; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fct_transferencias ENABLE ROW LEVEL SECURITY;

--
-- Name: dim_credor read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_credor FOR SELECT TO read_only USING (true);


--
-- Name: dim_date read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_date FOR SELECT TO read_only USING (true);


--
-- Name: dim_elemento_despesa read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_elemento_despesa FOR SELECT TO read_only USING (true);


--
-- Name: dim_funcao_subfuncao read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_funcao_subfuncao FOR SELECT TO read_only USING (true);


--
-- Name: dim_metadata read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_metadata FOR SELECT TO read_only USING (true);


--
-- Name: dim_natureza_despesa read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_natureza_despesa FOR SELECT TO read_only USING (true);


--
-- Name: dim_orgao read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_orgao FOR SELECT TO read_only USING (true);


--
-- Name: dim_portais read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.dim_portais FOR SELECT TO read_only USING (true);


--
-- Name: fct_analise_despesas_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_analise_despesas_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_caprem_cadprev_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_caprem_cadprev_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_caprem_entidades_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_caprem_entidades_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_caprem_natureza_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_caprem_natureza_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_caprem_tendencia_atuarial_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_caprem_tendencia_atuarial_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_contratos read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_contratos FOR SELECT TO read_only USING (true);


--
-- Name: fct_contratos_servicos_vigentes read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_contratos_servicos_vigentes FOR SELECT TO read_only USING (true);


--
-- Name: fct_despesas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_despesas FOR SELECT TO read_only USING (true);


--
-- Name: fct_despesas_diarias_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_despesas_diarias_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_despesas_fornecedores_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_despesas_fornecedores_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_despesas_por_fornecedor read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_despesas_por_fornecedor FOR SELECT TO read_only USING (true);


--
-- Name: fct_despesas_por_orgao read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_despesas_por_orgao FOR SELECT TO read_only USING (true);


--
-- Name: fct_despesas_por_unidade read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_despesas_por_unidade FOR SELECT TO read_only USING (true);


--
-- Name: fct_despesas_restos_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_despesas_restos_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_diarias read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_diarias FOR SELECT TO read_only USING (true);


--
-- Name: fct_emendas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_emendas FOR SELECT TO read_only USING (true);


--
-- Name: fct_execucao_orcamentaria_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_execucao_orcamentaria_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_fontes_receita_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_fontes_receita_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_historia_caprem_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_historia_caprem_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_historia_saude_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_historia_saude_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_licitacoes read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_licitacoes FOR SELECT TO read_only USING (true);


--
-- Name: fct_licitacoes_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_licitacoes_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_licitacoes_modalidades_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_licitacoes_modalidades_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_opacidade_contabil_credores read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_opacidade_contabil_credores FOR SELECT TO read_only USING (true);


--
-- Name: fct_opacidade_contabil_elementos read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_opacidade_contabil_elementos FOR SELECT TO read_only USING (true);


--
-- Name: fct_opacidade_contabil_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_opacidade_contabil_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_orcamento_funcional_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_orcamento_funcional_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_pessoal read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_pessoal FOR SELECT TO read_only USING (true);


--
-- Name: fct_pessoal_departamento_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_pessoal_departamento_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_pessoal_folha_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_pessoal_folha_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_posicao_fiscal_detalhes_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_posicao_fiscal_detalhes_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_posicao_fiscal_metricas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_posicao_fiscal_metricas FOR SELECT TO read_only USING (true);


--
-- Name: fct_receita_extra_orcamentaria read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_receita_extra_orcamentaria FOR SELECT TO read_only USING (true);


--
-- Name: fct_receitas read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_receitas FOR SELECT TO read_only USING (true);


--
-- Name: fct_transferencias read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.fct_transferencias FOR SELECT TO read_only USING (true);


--
-- Name: seed_constantes_fiscais read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.seed_constantes_fiscais FOR SELECT TO read_only USING (true);


--
-- Name: seed_elemento_despesa read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.seed_elemento_despesa FOR SELECT TO read_only USING (true);


--
-- Name: seed_funcao_subfuncao read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.seed_funcao_subfuncao FOR SELECT TO read_only USING (true);


--
-- Name: seed_natureza_despesa read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.seed_natureza_despesa FOR SELECT TO read_only USING (true);


--
-- Name: seed_naturezas_despesa_stn read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.seed_naturezas_despesa_stn FOR SELECT TO read_only USING (true);


--
-- Name: seed_porciuncula_prefeitura_orgaos read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.seed_porciuncula_prefeitura_orgaos FOR SELECT TO read_only USING (true);


--
-- Name: seed_portais read_only_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY read_only_select ON public.seed_portais FOR SELECT TO read_only USING (true);


--
-- Name: seed_constantes_fiscais; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seed_constantes_fiscais ENABLE ROW LEVEL SECURITY;

--
-- Name: seed_elemento_despesa; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seed_elemento_despesa ENABLE ROW LEVEL SECURITY;

--
-- Name: seed_funcao_subfuncao; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seed_funcao_subfuncao ENABLE ROW LEVEL SECURITY;

--
-- Name: seed_natureza_despesa; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seed_natureza_despesa ENABLE ROW LEVEL SECURITY;

--
-- Name: seed_naturezas_despesa_stn; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seed_naturezas_despesa_stn ENABLE ROW LEVEL SECURITY;

--
-- Name: seed_porciuncula_prefeitura_orgaos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seed_porciuncula_prefeitura_orgaos ENABLE ROW LEVEL SECURITY;

--
-- Name: seed_portais; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seed_portais ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict hdZ4s6X8j8fV9Y252u3h9Kf8vmuNNpayYQnC0zvfSfuZdLOe2NyWN8mEUyOIUv0

--
-- PostgreSQL database dump
--

\restrict xVVcu98blM36FS3ULbTefDkmrgrYEdfUBWsRIyeuImys8iUZ3KpfNsidtbXfEsE

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: seed_constantes_fiscais; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2000, 2020, 33000.00, NULL, 'Limite dispensa obras e engenharia histórico', 'Decreto 9.412/2018', 'http://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/decreto/d9412.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2000, 2020, 17600.00, NULL, 'Limite dispensa compras e serviços histórico', 'Decreto 9.412/2018', 'http://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/decreto/d9412.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2000, 2020, 8000.00, NULL, 'Limite dispensa manutenção de veículos histórico', 'Decreto 9.412/2018', 'http://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/decreto/d9412.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2021, 2021, 100000.00, NULL, 'Limite dispensa obras e engenharia', 'Lei 14.133/2021 Art. 75 I', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2021, 2021, 50000.00, NULL, 'Limite dispensa compras e serviços', 'Lei 14.133/2021 Art. 75 II', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2021, 2021, 8000.00, NULL, 'Limite dispensa manutenção de veículos', 'Lei 14.133/2021 Art. 75 § 7º', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2022, 2022, 108040.82, NULL, 'Limite dispensa obras e engenharia', 'Decreto 10.922/2021', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/decreto/d10922.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2022, 2022, 54020.41, NULL, 'Limite dispensa compras e serviços', 'Decreto 10.922/2021', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/decreto/d10922.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2022, 2022, 8643.27, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 10.922/2021', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/decreto/d10922.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2023, 2023, 114416.65, NULL, 'Limite dispensa obras e engenharia', 'Decreto 11.317/2022', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2022/decreto/d11317.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2023, 2023, 57208.33, NULL, 'Limite dispensa compras e serviços', 'Decreto 11.317/2022', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2022/decreto/d11317.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2023, 2023, 9153.33, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 11.317/2022', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2022/decreto/d11317.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2024, 2024, 119812.02, NULL, 'Limite dispensa obras e engenharia', 'Decreto 11.871/2023', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/decreto/d11871.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2024, 2024, 59906.02, NULL, 'Limite dispensa compras e serviços', 'Decreto 11.871/2023', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/decreto/d11871.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2024, 2024, 9584.96, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 11.871/2023', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/decreto/d11871.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2025, 2025, 125451.15, NULL, 'Limite dispensa obras e engenharia', 'Decreto 12.343/2024', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/decreto/d12343.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2025, 2025, 62725.59, NULL, 'Limite dispensa compras e serviços', 'Decreto 12.343/2024', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/decreto/d12343.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2025, 2025, 10036.10, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 12.343/2024', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/decreto/d12343.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2026, 2099, 130984.20, NULL, 'Limite dispensa obras e engenharia', 'Decreto 12.807/2025', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/d12807.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2026, 2099, 65492.11, NULL, 'Limite dispensa compras e serviços', 'Decreto 12.807/2025', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/d12807.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2026, 2099, 10478.74, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 12.807/2025', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/d12807.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('pessoal', 'lrf_limite_maximo_executivo', 2000, 2099, 54.00, NULL, 'Limite máximo LRF Pessoal Executivo', 'LC 101/2000 Art. 20 III b', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('pessoal', 'lrf_limite_prudencial_executivo', 2000, 2099, 51.30, NULL, 'Limite prudencial LRF Pessoal Executivo', 'LC 101/2000 Art. 22', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('pessoal', 'lrf_limite_alerta_executivo', 2000, 2099, 48.60, NULL, 'Limite de alerta LRF Pessoal Executivo', 'LC 101/2000 Art. 59 § 1º I', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('despesas', 'elemento_folha_pessoal', 2000, 2099, NULL, '11', 'Código do elemento de despesa de folha de pagamento', 'Portaria STN/SOF', 'https://www.gov.br/tesouronacional/pt-br');
INSERT INTO public.seed_constantes_fiscais VALUES ('despesas', 'elemento_subvencoes_sociais', 2000, 2099, NULL, '43', 'Código do elemento de despesa de subvenções sociais', 'Portaria STN/SOF', 'https://www.gov.br/tesouronacional/pt-br');
INSERT INTO public.seed_constantes_fiscais VALUES ('opacidade', 'opacidade_limite_atencao_pct', 2000, 2099, 15.00, NULL, 'Limite de atenção para taxa de subitens residuais .99', 'Lei 4.320/64 Arts. 5º e 15', 'http://www.planalto.gov.br/ccivil_03/leis/l4320.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('opacidade', 'opacidade_limite_critico_pct', 2000, 2099, 30.00, NULL, 'Limite de concentração elevada para subitens residuais .99', 'Acórdão TCU 1540/2014 e Lei 4.320/64', 'http://www.planalto.gov.br/ccivil_03/leis/l4320.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_especificacao_orcamentaria', 2000, 2099, NULL, NULL, 'Princípio da Especificação Orçamentária', 'Lei 4.320/1964 Arts. 5º e 15', 'http://www.planalto.gov.br/ccivil_03/leis/l4320.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_transparencia_lrf', 2000, 2099, NULL, NULL, 'Transparência da Gestão Fiscal e Acesso Público', 'LC 101/2000 Art. 48', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_fracionamento_despesa', 2000, 2099, NULL, NULL, 'Vedação ao Fracionamento de Despesas e Crime de Burla a Licitação', 'Lei 14.133/2021 Art. 75 e CP Art. 337-E', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO public.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_carater_residual_tcu', 2000, 2099, NULL, NULL, 'Caráter Residual Excepcional do Subitem 99', 'Acórdão TCU nº 1.540/2014 - Plenário', 'https://pesquisa.apps.tcu.gov.br/');


--
-- Data for Name: seed_elemento_despesa; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.seed_elemento_despesa VALUES ('00', 'A Classificar / Sem Elemento', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('01', 'Aposentadorias do RPPS, Reserva Remunerada e Reformas dos Militares', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('02', 'Pensões Militares', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('03', 'Pensões do RPPS e do Militar', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('04', 'Contratação por Tempo Determinado', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('05', 'Outros Benefícios Previdenciários do Servidor ou do Militar', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('06', 'Benefício Mensal ao Deficiente e ao Idoso', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('07', 'Contribuição a Entidades Fechadas de Previdência', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('08', 'Outros Benefícios Assistenciais do Servidor e do Militar', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('09', 'Salário-Família', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('10', 'Outros Benefícios de Natureza Social', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('11', 'Vencimentos e Vantagens Fixas - Pessoal Civil', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('12', 'Vencimentos e Vantagens Fixas - Pessoal Militar', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('13', 'Contribuições Patronais', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('14', 'Diárias - Civil', 'Diárias');
INSERT INTO public.seed_elemento_despesa VALUES ('15', 'Diárias - Militar', 'Diárias');
INSERT INTO public.seed_elemento_despesa VALUES ('16', 'Outras Despesas Variáveis - Pessoal Civil', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('17', 'Outras Despesas Variáveis - Pessoal Militar', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('18', 'Auxílio-Financeiro a Estudantes', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('19', 'Auxílio-Fardamento', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('20', 'Auxílio-Financeiro a Pesquisadores', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('21', 'Juros sobre a Dívida por Contrato', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('22', 'Outros Encargos sobre a Dívida por Contrato', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('23', 'Juros, Deságios e Descontos da Dívida Mobiliária', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('24', 'Outros Encargos sobre a Dívida Mobiliária', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('25', 'Encargos sobre Operações de Crédito por Antecipação da Receita', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('26', 'Arrendamento Mercantil', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('27', 'Encargos pela Honra de Avais, Garantias, Fianças e Referendos', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('28', 'Remuneração de Cotas de Fundos Autárquicos', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('29', 'Distribuição de Resultado de Empresas Estatais Dependentes', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('30', 'Material de Consumo', 'Material');
INSERT INTO public.seed_elemento_despesa VALUES ('31', 'Premiações Culturais, Artísticas, Científicas, Desportivas e Outras', 'Material');
INSERT INTO public.seed_elemento_despesa VALUES ('32', 'Material, Bem ou Serviço para Distribuição Gratuita', 'Material');
INSERT INTO public.seed_elemento_despesa VALUES ('33', 'Passagens e Despesas com Locomoção', 'Material');
INSERT INTO public.seed_elemento_despesa VALUES ('34', 'Outras Despesas de Pessoal decorrentes de Contratos de Terceirização', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('35', 'Serviços de Consultoria', 'Serviços de Terceiros');
INSERT INTO public.seed_elemento_despesa VALUES ('36', 'Outros Serviços de Terceiros - Pessoa Física', 'Serviços de Terceiros');
INSERT INTO public.seed_elemento_despesa VALUES ('37', 'Locação de Mão-de-Obra', 'Serviços de Terceiros');
INSERT INTO public.seed_elemento_despesa VALUES ('38', 'Arrendamento Mercantil', 'Serviços de Terceiros');
INSERT INTO public.seed_elemento_despesa VALUES ('39', 'Outros Serviços de Terceiros - Pessoa Jurídica', 'Serviços de Terceiros');
INSERT INTO public.seed_elemento_despesa VALUES ('40', 'Serviços de Tecnologia da Informação e Comunicação - PJ', 'Serviços de Terceiros');
INSERT INTO public.seed_elemento_despesa VALUES ('41', 'Contribuições', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('42', 'Auxílios', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('43', 'Subvenções Sociais', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('44', 'Obras e Instalações', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('45', 'Subvenções Econômicas', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('46', 'Auxílio-Alimentação', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('47', 'Obrigações Tributárias e Contributivas', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('48', 'Outros Auxílios Financeiros a Pessoas Físicas', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('49', 'Auxílio-Transporte', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('50', 'Sede de Direitos Orçamentários', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('51', 'Obras e Instalações', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('52', 'Equipamentos e Material Permanente', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('53', 'Elemento Reservado 53', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('54', 'Elemento Reservado 54', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('55', 'Elemento Reservado 55', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('56', 'Elemento Reservado 56', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('57', 'Elemento Reservado 57', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('58', 'Elemento Reservado 58', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('59', 'Elemento Reservado 59', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('60', 'Elemento Reservado 60', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('61', 'Aquisição de Imóveis', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('62', 'Aquisição de Bens para Revenda', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('63', 'Aquisição de Títulos de Crédito', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('64', 'Aquisição de Títulos Representativos de Capital já Constituído', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('65', 'Constituição ou Aumento de Capital de Empresas', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('66', 'Concessão de Empréstimos e Financiamentos', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('67', 'Depósitos Compulsórios', 'Investimentos');
INSERT INTO public.seed_elemento_despesa VALUES ('68', 'Elemento Reservado 68', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('69', 'Elemento Reservado 69', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('70', 'Rateio pela Participação em Consórcio Público', 'Transferências');
INSERT INTO public.seed_elemento_despesa VALUES ('71', 'Principal da Dívida Contratual Resgatado', 'Amortização da Dívida');
INSERT INTO public.seed_elemento_despesa VALUES ('72', 'Principal da Dívida Mobiliária Resgatado', 'Amortização da Dívida');
INSERT INTO public.seed_elemento_despesa VALUES ('73', 'Correção Monetária ou Câmbio da Dívida Contratual Resgatada', 'Amortização da Dívida');
INSERT INTO public.seed_elemento_despesa VALUES ('74', 'Correção Monetária ou Câmbio da Dívida Mobiliária Resgatada', 'Amortização da Dívida');
INSERT INTO public.seed_elemento_despesa VALUES ('75', 'Amortização da Dívida de Operações de Crédito por ARO', 'Amortização da Dívida');
INSERT INTO public.seed_elemento_despesa VALUES ('76', 'Principal Operações de Crédito por Antecipação da Receita', 'Amortização da Dívida');
INSERT INTO public.seed_elemento_despesa VALUES ('77', 'Atuação em Outros Encargos de Amortização', 'Amortização da Dívida');
INSERT INTO public.seed_elemento_despesa VALUES ('78', 'Elemento Reservado 78', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('79', 'Elemento Reservado 79', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('80', 'Elemento Reservado 80', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('81', 'Correção Monetária de Outras Dívidas', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('82', 'Elemento Reservado 82', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('83', 'Elemento Reservado 83', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('84', 'Elemento Reservado 84', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('85', 'Elemento Reservado 85', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('86', 'Elemento Reservado 86', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('87', 'Elemento Reservado 87', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('88', 'Elemento Reservado 88', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('89', 'Elemento Reservado 89', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('90', 'Elemento Reservado 90', 'Outros');
INSERT INTO public.seed_elemento_despesa VALUES ('91', 'Sentenças Judiciais', 'Sentenças');
INSERT INTO public.seed_elemento_despesa VALUES ('92', 'Despesas de Exercícios Anteriores', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('93', 'Indenizações e Restituições', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('94', 'Indenizações e Restituições Trabalhistas', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('95', 'Indenização pela Execução de Trabalhos de Campo', 'Outras Despesas Correntes');
INSERT INTO public.seed_elemento_despesa VALUES ('96', 'Ressarcimento de Despesas de Pessoal Requisitado', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('97', 'Aporte para Cobertura do Déficit Atuarial do RPPS', 'Aporte Atuarial');
INSERT INTO public.seed_elemento_despesa VALUES ('98', 'Compensação Financeira entre Regimes de Previdência', 'Pessoal e Encargos');
INSERT INTO public.seed_elemento_despesa VALUES ('99', 'A Classificar', 'Outros');


--
-- Data for Name: seed_funcao_subfuncao; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.seed_funcao_subfuncao VALUES ('01.031', '01', 'Legislativa', '031', 'Ação Legislativa');
INSERT INTO public.seed_funcao_subfuncao VALUES ('01.032', '01', 'Legislativa', '032', 'Controle Externo');
INSERT INTO public.seed_funcao_subfuncao VALUES ('02.061', '02', 'Judiciária', '061', 'Ação Judiciária');
INSERT INTO public.seed_funcao_subfuncao VALUES ('02.062', '02', 'Judiciária', '062', 'Defesa do Interesse Público no Processo Judiciário');
INSERT INTO public.seed_funcao_subfuncao VALUES ('03.091', '03', 'Essencial à Justiça', '091', 'Defesa da Ordem Jurídica');
INSERT INTO public.seed_funcao_subfuncao VALUES ('03.092', '03', 'Essencial à Justiça', '092', 'Representação Judicial e Extrajudicial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.121', '04', 'Administração', '121', 'Planejamento e Orçamento');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.122', '04', 'Administração', '122', 'Administração Geral');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.123', '04', 'Administração', '123', 'Administração Financeira');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.124', '04', 'Administração', '124', 'Controle Interno');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.125', '04', 'Administração', '125', 'Normatização e Fiscalização');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.126', '04', 'Administração', '126', 'Tecnologia da Informação');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.127', '04', 'Administração', '127', 'Ordenamento Territorial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.128', '04', 'Administração', '128', 'Formação de Recursos Humanos');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.129', '04', 'Administração', '129', 'Administração de Receitas');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.130', '04', 'Administração', '130', 'Administração de Concessões');
INSERT INTO public.seed_funcao_subfuncao VALUES ('04.131', '04', 'Administração', '131', 'Comunicação Social');
INSERT INTO public.seed_funcao_subfuncao VALUES ('05.151', '05', 'Defesa Nacional', '151', 'Defesa Aérea');
INSERT INTO public.seed_funcao_subfuncao VALUES ('05.152', '05', 'Defesa Nacional', '152', 'Defesa Naval');
INSERT INTO public.seed_funcao_subfuncao VALUES ('05.153', '05', 'Defesa Nacional', '153', 'Defesa Terrestre');
INSERT INTO public.seed_funcao_subfuncao VALUES ('06.181', '06', 'Segurança Pública', '181', 'Policiamento');
INSERT INTO public.seed_funcao_subfuncao VALUES ('06.182', '06', 'Segurança Pública', '182', 'Defesa Civil');
INSERT INTO public.seed_funcao_subfuncao VALUES ('06.183', '06', 'Segurança Pública', '183', 'Informação e Inteligência');
INSERT INTO public.seed_funcao_subfuncao VALUES ('07.211', '07', 'Relações Exteriores', '211', 'Relações Diplomáticas');
INSERT INTO public.seed_funcao_subfuncao VALUES ('07.212', '07', 'Relações Exteriores', '212', 'Cooperação Internacional');
INSERT INTO public.seed_funcao_subfuncao VALUES ('08.241', '08', 'Assistência Social', '241', 'Assistência ao Idoso');
INSERT INTO public.seed_funcao_subfuncao VALUES ('08.242', '08', 'Assistência Social', '242', 'Assistência ao Portador de Deficiência');
INSERT INTO public.seed_funcao_subfuncao VALUES ('08.243', '08', 'Assistência Social', '243', 'Assistência à Criança e ao Adolescente');
INSERT INTO public.seed_funcao_subfuncao VALUES ('08.244', '08', 'Assistência Social', '244', 'Assistência Comunitária');
INSERT INTO public.seed_funcao_subfuncao VALUES ('09.271', '09', 'Previdência Social', '271', 'Previdência Básica');
INSERT INTO public.seed_funcao_subfuncao VALUES ('09.272', '09', 'Previdência Social', '272', 'Previdência do Regime Estatutário');
INSERT INTO public.seed_funcao_subfuncao VALUES ('09.273', '09', 'Previdência Social', '273', 'Previdência Complementar');
INSERT INTO public.seed_funcao_subfuncao VALUES ('09.274', '09', 'Previdência Social', '274', 'Previdência Especial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('10.301', '10', 'Saúde', '301', 'Atenção Básica');
INSERT INTO public.seed_funcao_subfuncao VALUES ('10.302', '10', 'Saúde', '302', 'Assistência Hospitalar e Ambulatorial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('10.303', '10', 'Saúde', '303', 'Suporte Profilático e Terapêutico');
INSERT INTO public.seed_funcao_subfuncao VALUES ('10.304', '10', 'Saúde', '304', 'Vigilância Sanitária');
INSERT INTO public.seed_funcao_subfuncao VALUES ('10.305', '10', 'Saúde', '305', 'Vigilância Epidemiológica');
INSERT INTO public.seed_funcao_subfuncao VALUES ('10.306', '10', 'Saúde', '306', 'Alimentação e Nutrição');
INSERT INTO public.seed_funcao_subfuncao VALUES ('11.331', '11', 'Trabalho', '331', 'Proteção e Benefícios ao Trabalhador');
INSERT INTO public.seed_funcao_subfuncao VALUES ('11.332', '11', 'Trabalho', '332', 'Relações de Trabalho');
INSERT INTO public.seed_funcao_subfuncao VALUES ('11.333', '11', 'Trabalho', '333', 'Empregabilidade');
INSERT INTO public.seed_funcao_subfuncao VALUES ('11.334', '11', 'Trabalho', '334', 'Fomento ao Trabalho');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.361', '12', 'Educação', '361', 'Ensino Fundamental');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.362', '12', 'Educação', '362', 'Ensino Médio');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.363', '12', 'Educação', '363', 'Ensino Profissional');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.364', '12', 'Educação', '364', 'Ensino Superior');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.365', '12', 'Educação', '365', 'Educação Infantil');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.366', '12', 'Educação', '366', 'Educação de Jovens e Adultos');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.367', '12', 'Educação', '367', 'Educação Especial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('12.368', '12', 'Educação', '368', 'Educação Básica');
INSERT INTO public.seed_funcao_subfuncao VALUES ('13.391', '13', 'Cultura', '391', 'Patrimônio Histórico, Artístico e Arqueológico');
INSERT INTO public.seed_funcao_subfuncao VALUES ('13.392', '13', 'Cultura', '392', 'Difusão Cultural');
INSERT INTO public.seed_funcao_subfuncao VALUES ('14.421', '14', 'Direitos da Cidadania', '421', 'Custódia e Reintegração Social');
INSERT INTO public.seed_funcao_subfuncao VALUES ('14.422', '14', 'Direitos da Cidadania', '422', 'Direitos Individuais, Coletivos e Difusos');
INSERT INTO public.seed_funcao_subfuncao VALUES ('14.423', '14', 'Direitos da Cidadania', '423', 'Assistência Jurídica Integral e Gratuita');
INSERT INTO public.seed_funcao_subfuncao VALUES ('15.451', '15', 'Urbanismo', '451', 'Infra-Estrutura Urbana');
INSERT INTO public.seed_funcao_subfuncao VALUES ('15.452', '15', 'Urbanismo', '452', 'Serviços Urbanos');
INSERT INTO public.seed_funcao_subfuncao VALUES ('15.453', '15', 'Urbanismo', '453', 'Transportes Coletivos Urbanos');
INSERT INTO public.seed_funcao_subfuncao VALUES ('16.481', '16', 'Habitação', '481', 'Habitação Rural');
INSERT INTO public.seed_funcao_subfuncao VALUES ('16.482', '16', 'Habitação', '482', 'Habitação Urbana');
INSERT INTO public.seed_funcao_subfuncao VALUES ('17.511', '17', 'Saneamento', '511', 'Saneamento Básico Rural');
INSERT INTO public.seed_funcao_subfuncao VALUES ('17.512', '17', 'Saneamento', '512', 'Saneamento Básico Urbano');
INSERT INTO public.seed_funcao_subfuncao VALUES ('18.541', '18', 'Gestão Ambiental', '541', 'Preservação e Conservação Ambiental');
INSERT INTO public.seed_funcao_subfuncao VALUES ('18.542', '18', 'Gestão Ambiental', '542', 'Controle Ambiental');
INSERT INTO public.seed_funcao_subfuncao VALUES ('18.543', '18', 'Gestão Ambiental', '543', 'Recuperação de Áreas Degradadas');
INSERT INTO public.seed_funcao_subfuncao VALUES ('18.544', '18', 'Gestão Ambiental', '544', 'Recursos Hídricos');
INSERT INTO public.seed_funcao_subfuncao VALUES ('18.545', '18', 'Gestão Ambiental', '545', 'Meteorologia');
INSERT INTO public.seed_funcao_subfuncao VALUES ('19.571', '19', 'Ciência e Tecnologia', '571', 'Desenvolvimento Científico');
INSERT INTO public.seed_funcao_subfuncao VALUES ('19.572', '19', 'Ciência e Tecnologia', '572', 'Desenvolvimento Tecnológico e Engenharia');
INSERT INTO public.seed_funcao_subfuncao VALUES ('19.573', '19', 'Ciência e Tecnologia', '573', 'Difusão do Conhecimento Científico e Tecnológico');
INSERT INTO public.seed_funcao_subfuncao VALUES ('20.601', '20', 'Agricultura', '601', 'Promoção da Produção Vegetal');
INSERT INTO public.seed_funcao_subfuncao VALUES ('20.602', '20', 'Agricultura', '602', 'Promoção da Produção Animal');
INSERT INTO public.seed_funcao_subfuncao VALUES ('20.603', '20', 'Agricultura', '603', 'Defesa Sanitária Vegetal');
INSERT INTO public.seed_funcao_subfuncao VALUES ('20.604', '20', 'Agricultura', '604', 'Defesa Sanitária Animal');
INSERT INTO public.seed_funcao_subfuncao VALUES ('20.605', '20', 'Agricultura', '605', 'Abastecimento');
INSERT INTO public.seed_funcao_subfuncao VALUES ('20.606', '20', 'Agricultura', '606', 'Extensão Rural');
INSERT INTO public.seed_funcao_subfuncao VALUES ('20.607', '20', 'Agricultura', '607', 'Irrigação');
INSERT INTO public.seed_funcao_subfuncao VALUES ('21.631', '21', 'Organização Agrária', '631', 'Reforma Agrária');
INSERT INTO public.seed_funcao_subfuncao VALUES ('21.632', '21', 'Organização Agrária', '632', 'Colonização');
INSERT INTO public.seed_funcao_subfuncao VALUES ('22.661', '22', 'Indústria', '661', 'Promoção Industrial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('22.662', '22', 'Indústria', '662', 'Produção Industrial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('22.663', '22', 'Indústria', '663', 'Mineração');
INSERT INTO public.seed_funcao_subfuncao VALUES ('22.664', '22', 'Indústria', '664', 'Propriedade Industrial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('22.665', '22', 'Indústria', '665', 'Normalização e Qualidade');
INSERT INTO public.seed_funcao_subfuncao VALUES ('23.691', '23', 'Comércio e Serviços', '691', 'Promoção Comercial');
INSERT INTO public.seed_funcao_subfuncao VALUES ('23.692', '23', 'Comércio e Serviços', '692', 'Comercialização');
INSERT INTO public.seed_funcao_subfuncao VALUES ('23.693', '23', 'Comércio e Serviços', '693', 'Comércio Exterior');
INSERT INTO public.seed_funcao_subfuncao VALUES ('23.694', '23', 'Comércio e Serviços', '694', 'Serviços Financeiros');
INSERT INTO public.seed_funcao_subfuncao VALUES ('23.695', '23', 'Comércio e Serviços', '695', 'Turismo');
INSERT INTO public.seed_funcao_subfuncao VALUES ('24.721', '24', 'Comunicações', '721', 'Telecomunicações');
INSERT INTO public.seed_funcao_subfuncao VALUES ('24.722', '24', 'Comunicações', '722', 'Serviços Postais');
INSERT INTO public.seed_funcao_subfuncao VALUES ('25.751', '25', 'Energia', '751', 'Conservação de Energia');
INSERT INTO public.seed_funcao_subfuncao VALUES ('25.752', '25', 'Energia', '752', 'Energia Elétrica');
INSERT INTO public.seed_funcao_subfuncao VALUES ('25.753', '25', 'Energia', '753', 'Combustíveis Minerais');
INSERT INTO public.seed_funcao_subfuncao VALUES ('25.754', '25', 'Energia', '754', 'Biocombustíveis');
INSERT INTO public.seed_funcao_subfuncao VALUES ('26.781', '26', 'Transporte', '781', 'Transporte Aéreo');
INSERT INTO public.seed_funcao_subfuncao VALUES ('26.782', '26', 'Transporte', '782', 'Transporte Rodoviário');
INSERT INTO public.seed_funcao_subfuncao VALUES ('26.783', '26', 'Transporte', '783', 'Transporte Ferroviário');
INSERT INTO public.seed_funcao_subfuncao VALUES ('26.784', '26', 'Transporte', '784', 'Transporte Hidroviário');
INSERT INTO public.seed_funcao_subfuncao VALUES ('26.785', '26', 'Transporte', '785', 'Transportes Especiais');
INSERT INTO public.seed_funcao_subfuncao VALUES ('27.811', '27', 'Desporto e Lazer', '811', 'Desporto de Rendimento');
INSERT INTO public.seed_funcao_subfuncao VALUES ('27.812', '27', 'Desporto e Lazer', '812', 'Desporto Comunitário');
INSERT INTO public.seed_funcao_subfuncao VALUES ('27.813', '27', 'Desporto e Lazer', '813', 'Lazer');
INSERT INTO public.seed_funcao_subfuncao VALUES ('28.841', '28', 'Encargos Especiais', '841', 'Refinanciamento da Dívida Interna');
INSERT INTO public.seed_funcao_subfuncao VALUES ('28.842', '28', 'Encargos Especiais', '842', 'Refinanciamento da Dívida Externa');
INSERT INTO public.seed_funcao_subfuncao VALUES ('28.843', '28', 'Encargos Especiais', '843', 'Serviço da Dívida Interna');
INSERT INTO public.seed_funcao_subfuncao VALUES ('28.844', '28', 'Encargos Especiais', '844', 'Serviço da Dívida Externa');
INSERT INTO public.seed_funcao_subfuncao VALUES ('28.845', '28', 'Encargos Especiais', '845', 'Outras Transferências');
INSERT INTO public.seed_funcao_subfuncao VALUES ('28.846', '28', 'Encargos Especiais', '846', 'Outros Encargos Especiais');
INSERT INTO public.seed_funcao_subfuncao VALUES ('99.999', '99', 'Reserva de Contingência', '999', 'Reserva de Contingência e A Classificar');


--
-- Data for Name: seed_natureza_despesa; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.seed_natureza_despesa VALUES ('3120', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '20', 'Transferências à União');
INSERT INTO public.seed_natureza_despesa VALUES ('3130', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '30', 'Transferências a Estados e ao DF');
INSERT INTO public.seed_natureza_despesa VALUES ('3140', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '40', 'Transferências a Municípios');
INSERT INTO public.seed_natureza_despesa VALUES ('3150', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO public.seed_natureza_despesa VALUES ('3170', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '70', 'Transferências a Consórcios Públicos');
INSERT INTO public.seed_natureza_despesa VALUES ('3190', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '90', 'Aplicações Diretas');
INSERT INTO public.seed_natureza_despesa VALUES ('3191', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO public.seed_natureza_despesa VALUES ('3220', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '20', 'Transferências à União');
INSERT INTO public.seed_natureza_despesa VALUES ('3230', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '30', 'Transferências a Estados e ao DF');
INSERT INTO public.seed_natureza_despesa VALUES ('3240', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '40', 'Transferências a Municípios');
INSERT INTO public.seed_natureza_despesa VALUES ('3250', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO public.seed_natureza_despesa VALUES ('3270', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '70', 'Transferências a Consórcios Públicos');
INSERT INTO public.seed_natureza_despesa VALUES ('3290', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '90', 'Aplicações Diretas');
INSERT INTO public.seed_natureza_despesa VALUES ('3291', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO public.seed_natureza_despesa VALUES ('3320', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '20', 'Transferências à União');
INSERT INTO public.seed_natureza_despesa VALUES ('3330', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '30', 'Transferências a Estados e ao DF');
INSERT INTO public.seed_natureza_despesa VALUES ('3340', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '40', 'Transferências a Municípios');
INSERT INTO public.seed_natureza_despesa VALUES ('3350', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO public.seed_natureza_despesa VALUES ('3370', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '70', 'Transferências a Consórcios Públicos');
INSERT INTO public.seed_natureza_despesa VALUES ('3390', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '90', 'Aplicações Diretas');
INSERT INTO public.seed_natureza_despesa VALUES ('3391', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO public.seed_natureza_despesa VALUES ('4420', '4', 'Despesas de Capital', '4', 'Investimentos', '20', 'Transferências à União');
INSERT INTO public.seed_natureza_despesa VALUES ('4430', '4', 'Despesas de Capital', '4', 'Investimentos', '30', 'Transferências a Estados e ao DF');
INSERT INTO public.seed_natureza_despesa VALUES ('4440', '4', 'Despesas de Capital', '4', 'Investimentos', '40', 'Transferências a Municípios');
INSERT INTO public.seed_natureza_despesa VALUES ('4450', '4', 'Despesas de Capital', '4', 'Investimentos', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO public.seed_natureza_despesa VALUES ('4470', '4', 'Despesas de Capital', '4', 'Investimentos', '70', 'Transferências a Consórcios Públicos');
INSERT INTO public.seed_natureza_despesa VALUES ('4490', '4', 'Despesas de Capital', '4', 'Investimentos', '90', 'Aplicações Diretas');
INSERT INTO public.seed_natureza_despesa VALUES ('4491', '4', 'Despesas de Capital', '4', 'Investimentos', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO public.seed_natureza_despesa VALUES ('4520', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '20', 'Transferências à União');
INSERT INTO public.seed_natureza_despesa VALUES ('4530', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '30', 'Transferências a Estados e ao DF');
INSERT INTO public.seed_natureza_despesa VALUES ('4540', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '40', 'Transferências a Municípios');
INSERT INTO public.seed_natureza_despesa VALUES ('4550', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO public.seed_natureza_despesa VALUES ('4570', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '70', 'Transferências a Consórcios Públicos');
INSERT INTO public.seed_natureza_despesa VALUES ('4590', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '90', 'Aplicações Diretas');
INSERT INTO public.seed_natureza_despesa VALUES ('4591', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO public.seed_natureza_despesa VALUES ('4620', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '20', 'Transferências à União');
INSERT INTO public.seed_natureza_despesa VALUES ('4630', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '30', 'Transferências a Estados e ao DF');
INSERT INTO public.seed_natureza_despesa VALUES ('4640', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '40', 'Transferências a Municípios');
INSERT INTO public.seed_natureza_despesa VALUES ('4650', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO public.seed_natureza_despesa VALUES ('4670', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '70', 'Transferências a Consórcios Públicos');
INSERT INTO public.seed_natureza_despesa VALUES ('4690', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '90', 'Aplicações Diretas');
INSERT INTO public.seed_natureza_despesa VALUES ('4691', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');


--
-- Data for Name: seed_naturezas_despesa_stn; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.71.70.00', 'Rateio pela Participação em Consórcio Público', '70', 'consorcios_publicos', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.13.00', 'Obrigações Patronais', '13', 'previdencia', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.14.00', 'Diárias - Civil', '14', 'diarias_viagens', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.14.01', 'Diárias no País', '14', 'diarias_viagens', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.30.01', 'Combustíveis e Lubrificantes Automotivos', '30', 'combustivel_frota', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.30.07', 'Gêneros de Alimentação', '30', 'generos_alimenticios', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.30.39', 'Material para Manutenção de Veículos', '30', 'manutencao_veiculos', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.33.00', 'Passagens e Despesas com Locomoção', '33', 'diarias_viagens', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.33.01', 'Passagens no País', '33', 'diarias_viagens', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.35.00', 'Serviços de Consultoria', '35', 'consultoria_tecnica', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.36.02', 'Diárias a Colaboradores Eventuais no País', '36', 'diarias_viagens', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.36.15', 'Locação de Imóveis', '36', 'locacao_imoveis', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.36.16', 'Locação de Bens Móveis', '36', 'locacao_maquinas_veiculos', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.36.19', 'Locação de Máquinas e Equipamentos', '36', 'locacao_maquinas_veiculos', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.37.00', 'Locação de Mão-de-Obra', '37', 'terceirizacao_mao_obra', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.05', 'Serviços Técnicos Profissionais', '39', 'consultoria_tecnica', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.10', 'Locação de Imóveis', '39', 'locacao_imoveis', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.12', 'Locação de Máquinas e Equipamentos', '39', 'locacao_maquinas_veiculos', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.13', 'Locação de Veículos', '39', 'locacao_maquinas_veiculos', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.14', 'Locação de Bens Móveis e Outras Naturezas e Intangíveis', '39', 'locacao_imoveis', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.21', 'Serviços de Áudio Vídeo e Foto', '39', 'eventos_festas', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.22', 'Exposições Congressos e Conferências', '39', 'eventos_festas', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.23', 'Festividades e Homenagens', '39', 'eventos_festas', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.44', 'Serviços de Limpeza Urbana e Manejo de Resíduos Sólidos', '39', 'limpeza_residuos', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.39.50', 'Serviços Médico-Hospitalares Odontológicos e Laboratoriais', '39', 'plantoes_medicos', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('3.3.90.91.00', 'Sentenças Judiciais', '91', 'bloqueios_sentencas', false);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('4.4.90.51.00', 'Obras e Instalações', '51', 'obras_infraestrutura', true);
INSERT INTO public.seed_naturezas_despesa_stn VALUES ('4.4.90.51.91', 'Obras em Andamento', '51', 'obras_infraestrutura', true);


--
-- Data for Name: seed_porciuncula_prefeitura_orgaos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', 7, 'PREFEITURA MUNICIPAL DE PORCIÚNCULA');
INSERT INTO public.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', 2, 'FUNDO MUNICIPAL DE SAUDE');
INSERT INTO public.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', 8, 'FUNDO MUNICIPAL DE EDUCAÇÃO');
INSERT INTO public.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', 3, 'FUNDO MUNICIPAL DE ASSISTENCIA SOCIAL');
INSERT INTO public.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', 9, 'FUNDO MUNICIPAL DE DEFESA AMBIENTAL');
INSERT INTO public.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', 10, 'FUNDO DE SOLIDARIEDADE - FUNDESOL');


--
-- Data for Name: seed_portais; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.seed_portais VALUES ('porciuncula_prefeitura', 'Prefeitura de Porciúncula', 'RJ', 'https://transparencia.porciuncula.rj.gov.br/transparencia/', 'https://transparencia.porciuncula.rj.gov.br', 'PORCIUNCULA', 2021, '7', 'brasao-porciuncula.svg');


--
-- PostgreSQL database dump complete
--

\unrestrict xVVcu98blM36FS3ULbTefDkmrgrYEdfUBWsRIyeuImys8iUZ3KpfNsidtbXfEsE

