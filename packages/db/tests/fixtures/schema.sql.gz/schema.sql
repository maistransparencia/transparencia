--
-- PostgreSQL database dump
--

\restrict zwfm2lmddPfrHwQIUJGFfQizebZZWnLxz2IJwHNlvSxZPkU84C4mxYJ3rg3jLKJ

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_credor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_credor (
    credor_id text NOT NULL,
    portal_slug text NOT NULL,
    fornecedor_cpf_cnpj text,
    fornecedor_nome text,
    fornecedor_cidade text
);


--
-- Name: dim_date; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_date (
    data date NOT NULL,
    ano integer NOT NULL,
    mes_num integer,
    dia integer,
    dia_semana integer,
    mes_nome text,
    inicio_mes date,
    fim_mes date,
    trimestre integer
);


--
-- Name: dim_elemento_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_elemento_despesa (
    elemento_codigo text NOT NULL,
    elemento_descricao text NOT NULL,
    categoria_macro text NOT NULL
);


--
-- Name: dim_funcao_subfuncao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_funcao_subfuncao (
    funcao_subfuncao_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    funcao_nome text NOT NULL,
    subfuncao_codigo text NOT NULL,
    subfuncao_nome text NOT NULL
);


--
-- Name: dim_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_metadata (
    portal_slug text,
    key text,
    value text
);


--
-- Name: dim_natureza_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_natureza_despesa (
    natureza_despesa_codigo text NOT NULL,
    categoria_economica_codigo text NOT NULL,
    categoria_economica_nome text NOT NULL,
    gnd_codigo text NOT NULL,
    gnd_nome text NOT NULL,
    modalidade_codigo text NOT NULL,
    modalidade_nome text NOT NULL
);


--
-- Name: dim_orgao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_orgao (
    orgao_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    orgao_nome text
);


--
-- Name: dim_portais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dim_portais (
    portal_slug text NOT NULL,
    display_name text,
    uf text,
    portal_url text,
    base_host text,
    cidade_clean text,
    ano_inicial integer,
    empresa_padrao text,
    brasao_asset text,
    data_extracao date
);


--
-- Name: fct_analise_despesas_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_analise_despesas_metricas (
    analise_despesas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    orgao_codigo text NOT NULL,
    unidade_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    total_dotacao_atualizada numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL
);


--
-- Name: fct_caprem_cadprev_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_cadprev_metricas (
    caprem_cadprev_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empenho_id text,
    descricao text,
    data_empenho date,
    empenhado numeric NOT NULL,
    pago numeric NOT NULL
);


--
-- Name: fct_caprem_entidades_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_entidades_metricas (
    caprem_entidade_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    entidade text NOT NULL,
    empenhado numeric NOT NULL,
    liquidado numeric NOT NULL,
    pago numeric NOT NULL,
    taxa_execucao numeric NOT NULL
);


--
-- Name: fct_caprem_natureza_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_natureza_metricas (
    caprem_natureza_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empenho_id text,
    elemento text NOT NULL,
    natureza_despesa text NOT NULL,
    destino text NOT NULL,
    descricao text,
    data_empenho date,
    empenhado numeric NOT NULL,
    liquidado numeric NOT NULL,
    pago numeric NOT NULL
);


--
-- Name: fct_caprem_tendencia_atuarial_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_caprem_tendencia_atuarial_metricas (
    caprem_tendencia_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    aporte_exigido numeric NOT NULL,
    aporte_quitado numeric NOT NULL,
    taxa_adimplencia numeric NOT NULL,
    amortizacao_divida numeric NOT NULL
);


--
-- Name: fct_contratos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_contratos (
    contrato_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    contrato_numero text,
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    objeto text,
    valor_contrato numeric,
    valor_aditado numeric,
    licitacao_numero text,
    modalidade text,
    mes text,
    tipo_obra text,
    numero_obra text,
    fundlegal text,
    empenhado numeric,
    objeto_completo text,
    data_inicio date,
    vencimento_atual date,
    saldo_a_empenhar numeric
);


--
-- Name: fct_contratos_servicos_vigentes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_contratos_servicos_vigentes (
    contrato_servico_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    contrato_numero text,
    fornecedor_nome text,
    fornecedor_cnpj text,
    objeto_descricao text,
    data_inicio date,
    vencimento_atual date,
    valor_aditado numeric,
    total_empenhado numeric,
    total_liquidado numeric,
    total_pago numeric,
    status_execucao text NOT NULL
);


--
-- Name: fct_despesas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas (
    despesa_id text NOT NULL,
    portal_slug text NOT NULL,
    fonte text,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    empenho_id text NOT NULL,
    pk_empenho text,
    tipo_empenho text,
    orgao_codigo text,
    unidade_codigo text,
    funcao text,
    funcao_nome text,
    subfuncao text,
    subfuncao_nome text,
    elemento text,
    natureza_despesa text,
    grupo_natureza text,
    modalidade text,
    programa text,
    programa_nome text,
    proj_atividade text,
    projeto_atividade_nome text,
    mes text,
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    licitacao_numero text,
    licitacao_modalidade text,
    fonte_recurso_desc text,
    descricao text,
    natureza_despesa_codigo text,
    natureza_despesa_codigo_sugerido text,
    natureza_despesa_nome_sugerido text,
    categoria_objeto_sugerida text,
    categoria_gasto_sensivel text,
    credor_id text,
    orgao_id text,
    data_empenho date,
    empenhado numeric,
    empenhado_liquido numeric,
    liquidado numeric,
    pago numeric,
    dotacao_inicial numeric,
    alteracao_dotacao numeric,
    dotacao_atualizada numeric,
    reforco numeric,
    valor_anulacoes numeric
);


--
-- Name: fct_despesas_diarias_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_diarias_metricas (
    diarias_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    favorecido text NOT NULL,
    cargo text NOT NULL,
    total_valor numeric NOT NULL,
    qtd_concessoes integer NOT NULL
);


--
-- Name: fct_despesas_fornecedores_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_fornecedores_metricas (
    fornecedores_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    fornecedor_codigo text NOT NULL,
    fornecedor_nome text NOT NULL,
    fornecedor_cidade_clean text NOT NULL,
    total_empenhado numeric NOT NULL,
    total_pago numeric NOT NULL
);


--
-- Name: fct_despesas_por_fornecedor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_por_fornecedor (
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    fornecedor_cpf_cnpj text,
    fornecedor_cidade_clean text,
    fornecedor_cidade text,
    empenhado numeric,
    liquidado numeric,
    pago numeric
);


--
-- Name: fct_despesas_por_orgao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_por_orgao (
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    empenhado numeric,
    liquidado numeric,
    pago numeric,
    dotacao_atualizada numeric
);


--
-- Name: fct_despesas_por_unidade; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_por_unidade (
    portal_slug text,
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    empenhado numeric,
    liquidado numeric,
    pago numeric,
    dotacao_atualizada numeric
);


--
-- Name: fct_despesas_restos_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_despesas_restos_metricas (
    restos_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    restos_inscritos numeric,
    restos_liquidados numeric,
    restos_pagos numeric,
    restos_cancelados numeric,
    saldo_restos numeric,
    divida_mais_antiga_ano integer NOT NULL
);


--
-- Name: fct_diarias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_diarias (
    id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    diaria_id text,
    valor numeric,
    favorecido text,
    cargo text,
    data date,
    unidade text,
    descricao text
);


--
-- Name: fct_emendas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_emendas (
    emenda_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    numero_emenda text,
    resumo text,
    valor_total numeric,
    empenhado numeric,
    autor text,
    tipo_emenda text,
    esfera_origem text,
    ato_normativo text,
    destinacao text
);


--
-- Name: fct_execucao_orcamentaria_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_execucao_orcamentaria_metricas (
    execucao_orcamentaria_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    orgao_codigo text NOT NULL,
    orgao_nome text,
    unidade_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    subfuncao_codigo text NOT NULL,
    total_dotacao_atualizada numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL,
    saldo_orcamentario numeric NOT NULL,
    taxa_execucao numeric NOT NULL,
    alerta_execucao text NOT NULL
);


--
-- Name: fct_fontes_receita_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_fontes_receita_metricas (
    fontes_receita_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    receita_propria_previsto numeric NOT NULL,
    receita_propria_arrecadado numeric NOT NULL,
    transferencias_uniao_previsto numeric NOT NULL,
    transferencias_uniao_arrecadado numeric NOT NULL,
    transferencias_estado_previsto numeric NOT NULL,
    transferencias_estado_arrecadado numeric NOT NULL,
    receita_extra_orcamentaria_arrecadado numeric NOT NULL,
    total_previsto numeric NOT NULL,
    total_arrecadado numeric NOT NULL,
    pct_propria numeric NOT NULL,
    alerta_dependencia boolean NOT NULL,
    fpm_arrecadado numeric NOT NULL,
    icms_arrecadado numeric NOT NULL,
    iss_iptu_arrecadado numeric NOT NULL,
    emendas_pix_arrecadado numeric NOT NULL,
    emendas_individuais_arrecadado numeric NOT NULL,
    emendas_total_arrecadado numeric NOT NULL,
    emendas_total_empenhado numeric NOT NULL
);


--
-- Name: fct_historia_caprem_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_historia_caprem_metricas (
    historia_caprem_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    total_aporte_exigido numeric NOT NULL,
    total_aporte_quitado numeric NOT NULL,
    taxa_adimplencia_aporte numeric NOT NULL,
    total_empenhado_patronal numeric NOT NULL,
    total_liquidado_patronal numeric NOT NULL,
    total_pago_patronal numeric NOT NULL,
    rombo_patronal_nao_repassado numeric NOT NULL,
    total_amortizacao_divida numeric NOT NULL,
    total_casp_plano_saude numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL,
    servidores_efetivos integer NOT NULL,
    servidores_temporarios integer NOT NULL
);


--
-- Name: fct_historia_saude_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_historia_saude_metricas (
    historia_saude_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    dotacao_total numeric NOT NULL,
    total_empenhado numeric NOT NULL,
    total_liquidado numeric NOT NULL,
    total_pago numeric NOT NULL,
    medicamentos_insumos_empenhado numeric NOT NULL,
    medicamentos_insumos_pago numeric NOT NULL,
    judicializacao_empenhado numeric NOT NULL,
    judicializacao_pago numeric NOT NULL,
    emendas_saude_arrecadado numeric NOT NULL,
    hhi_concentracao_fornecedores integer NOT NULL,
    receita_uniao_saude numeric NOT NULL,
    receita_estado_saude numeric NOT NULL,
    repasses_prefeitura_saude numeric NOT NULL,
    uniao_sus_pct integer NOT NULL,
    estado_pct integer NOT NULL,
    propria_pct integer NOT NULL
);


--
-- Name: fct_licitacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_licitacoes (
    licitacao_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    licitacao_numero text,
    modalidade text,
    objeto text,
    discriminacao text,
    valor numeric,
    situacao text,
    data_abertura date,
    carona text
);


--
-- Name: fct_licitacoes_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_licitacoes_metricas (
    licitacao_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    tipo_contratacao text,
    numero text,
    licitacao_numero text,
    contrato_numero text,
    fornecedor_nome text,
    objeto text,
    modalidade text,
    fundlegal text,
    carona text,
    mes integer,
    numero_obra text,
    tipo_obra text,
    quantidade integer,
    licitacao_valor numeric(15,2),
    valor_contrato numeric(15,2),
    empenhado_contrato numeric(15,2),
    pago_contrato numeric(15,2),
    data_referencia date,
    limite_dispensa numeric(15,2),
    isento_legalmente boolean,
    acima_limite boolean
);


--
-- Name: fct_licitacoes_modalidades_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_licitacoes_modalidades_metricas (
    modalidade_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    modalidade text,
    quantidade integer,
    valor_total numeric(15,2)
);


--
-- Name: fct_opacidade_contabil_credores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_opacidade_contabil_credores (
    opacidade_credor_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    credor_codigo text NOT NULL,
    credor_nome text NOT NULL,
    total_empenhos integer NOT NULL,
    total_pago numeric NOT NULL,
    pago_desvio_sensivel numeric NOT NULL,
    categoria_predominante text NOT NULL,
    amostra_objeto text NOT NULL,
    ranking integer NOT NULL
);


--
-- Name: fct_opacidade_contabil_elementos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_opacidade_contabil_elementos (
    opacidade_elemento_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    elemento_codigo text NOT NULL,
    elemento_descricao text NOT NULL,
    categoria_macro text NOT NULL,
    tipo_residual text NOT NULL,
    total_empenhos integer NOT NULL,
    total_pago numeric NOT NULL,
    percentual_do_residual_99 numeric NOT NULL,
    ranking integer NOT NULL
);


--
-- Name: fct_opacidade_contabil_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_opacidade_contabil_metricas (
    opacidade_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    total_empenhos integer NOT NULL,
    empenhos_residual_99 integer NOT NULL,
    empenhos_desvio_sensivel_99 integer NOT NULL,
    taxa_empenhos_opacidade_pct numeric NOT NULL,
    total_pago numeric NOT NULL,
    pago_residual_99 numeric NOT NULL,
    pago_desvio_sensivel_99 numeric NOT NULL,
    taxa_valor_opacidade_pct numeric NOT NULL,
    taxa_desvio_sensivel_pct numeric NOT NULL,
    classificacao_risco text NOT NULL
);


--
-- Name: fct_orcamento_funcional_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_orcamento_funcional_metricas (
    orcamento_funcional_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    funcao_nome text NOT NULL,
    subfuncao_nome text NOT NULL,
    dotacao_atualizada numeric NOT NULL,
    empenhado numeric NOT NULL,
    liquidado numeric NOT NULL,
    pago numeric NOT NULL
);


--
-- Name: fct_pessoal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_pessoal (
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    proventos numeric,
    categoria_funcional text,
    vinculo text,
    cargo text,
    forma_provimento text
);


--
-- Name: fct_pessoal_departamento_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_pessoal_departamento_metricas (
    departamento_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    descricao text,
    total_pago numeric(15,2)
);


--
-- Name: fct_pessoal_folha_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_pessoal_folha_metricas (
    pessoal_folha_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    total_folha numeric(15,2),
    total_pago numeric(15,2),
    empenhado_13 numeric(15,2),
    empenhado_bruto_13 numeric(15,2),
    liquidado_13 numeric(15,2),
    pago_13 numeric(15,2),
    efetivos_confianca integer,
    comissionados_externos integer,
    bin_0_25k integer,
    bin_25k_5k integer,
    bin_5k_75k integer,
    bin_75k_10k integer,
    bin_10k_125k integer,
    bin_125k_15k integer,
    bin_15k_175k integer,
    bin_175k_20k integer,
    bin_acima_20k integer
);


--
-- Name: fct_posicao_fiscal_detalhes_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_posicao_fiscal_detalhes_metricas (
    posicao_fiscal_detalhes_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    administracao text NOT NULL,
    valor_empenhado numeric NOT NULL,
    valor_liquidado numeric NOT NULL,
    valor_pago numeric NOT NULL,
    valor_pendente numeric NOT NULL,
    fornecedor_nome text
);


--
-- Name: fct_posicao_fiscal_metricas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_posicao_fiscal_metricas (
    posicao_fiscal_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    total_arrecadado numeric NOT NULL,
    despesas_pagas numeric NOT NULL,
    restos_liquidados_no_ano numeric NOT NULL,
    restos_pagos_no_ano numeric NOT NULL,
    restos_pendentes_adm_anterior numeric NOT NULL,
    restos_pendentes_adm_atual numeric NOT NULL,
    saldo_estimado numeric NOT NULL
);


--
-- Name: fct_receita_extra_orcamentaria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_receita_extra_orcamentaria (
    receita_extra_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    codigo text,
    descricao text,
    valor_arrecadado numeric NOT NULL
);


--
-- Name: fct_receitas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_receitas (
    receita_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    tipo_receita text,
    codigo text,
    descricao text,
    previsao_atualizada numeric,
    arrecadado numeric
);


--
-- Name: fct_transferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fct_transferencias (
    transferencia_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    mes text,
    entidade_pagadora text,
    entidade_recebedora text,
    repasse numeric,
    devolucao numeric
);


--
-- Name: seed_constantes_fiscais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_constantes_fiscais (
    dominio text,
    chave text,
    ano_inicio integer,
    ano_fim integer,
    valor_num numeric,
    valor_txt text,
    descricao text,
    base_legal text,
    url_base_legal text
);


--
-- Name: seed_elemento_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_elemento_despesa (
    elemento_codigo text,
    elemento_descricao text,
    categoria_macro text
);


--
-- Name: seed_funcao_subfuncao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_funcao_subfuncao (
    funcao_subfuncao_codigo text,
    funcao_codigo text,
    funcao_nome text,
    subfuncao_codigo text,
    subfuncao_nome text
);


--
-- Name: seed_natureza_despesa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_natureza_despesa (
    natureza_despesa_codigo text,
    categoria_economica_codigo text,
    categoria_economica_nome text,
    gnd_codigo text,
    gnd_nome text,
    modalidade_codigo text,
    modalidade_nome text
);


--
-- Name: seed_naturezas_despesa_stn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_naturezas_despesa_stn (
    natureza_codigo text,
    natureza_descricao text,
    elemento_codigo text,
    categoria_macro text,
    is_sensivel boolean
);


--
-- Name: seed_porciuncula_prefeitura_orgaos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_porciuncula_prefeitura_orgaos (
    portal_slug text,
    empresa_id integer,
    nome text
);


--
-- Name: seed_portais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seed_portais (
    portal_slug text,
    display_name text,
    uf text,
    portal_url text,
    base_host text,
    cidade_clean text,
    ano_inicial integer,
    empresa_padrao text,
    brasao_asset text
);


--
-- Name: dim_elemento_despesa dim_elemento_despesa__dbt_tmp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_elemento_despesa
    ADD CONSTRAINT dim_elemento_despesa__dbt_tmp_pkey PRIMARY KEY (elemento_codigo);


--
-- Name: dim_funcao_subfuncao dim_funcao_subfuncao__dbt_tmp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_funcao_subfuncao
    ADD CONSTRAINT dim_funcao_subfuncao__dbt_tmp_pkey PRIMARY KEY (funcao_subfuncao_codigo);


--
-- Name: dim_natureza_despesa dim_natureza_despesa__dbt_tmp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dim_natureza_despesa
    ADD CONSTRAINT dim_natureza_despesa__dbt_tmp_pkey PRIMARY KEY (natureza_despesa_codigo);


--
-- Name: 46db600bff709802f8283e42bd0c5a7e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "46db600bff709802f8283e42bd0c5a7e" ON public.fct_despesas USING btree (fornecedor_cpf_cnpj);


--
-- Name: 896e45a3450a7905f67769201a229a78; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "896e45a3450a7905f67769201a229a78" ON public.fct_despesas USING btree (categoria_gasto_sensivel);


--
-- Name: aa169ac31fad7bead1fc856de19701fd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aa169ac31fad7bead1fc856de19701fd ON public.fct_despesas USING btree (elemento);


--
-- Name: bbe7e1a61a5cb2f7b941a34b14f6ad42; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bbe7e1a61a5cb2f7b941a34b14f6ad42 ON public.fct_despesas USING btree (fonte);


--
-- Name: cef99c24ec0ed10507507016d9ce83e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cef99c24ec0ed10507507016d9ce83e6 ON public.fct_despesas USING btree (portal_slug, ano);


--
-- Name: d923dcabd23fee1c0b276bce44559570; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX d923dcabd23fee1c0b276bce44559570 ON public.fct_despesas USING btree (portal_slug, ano, empresa_id);


--
-- Name: db27ad18e628af433ba41c8a4fb65a21; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX db27ad18e628af433ba41c8a4fb65a21 ON public.fct_despesas USING btree (funcao);


--
-- PostgreSQL database dump complete
--

\unrestrict zwfm2lmddPfrHwQIUJGFfQizebZZWnLxz2IJwHNlvSxZPkU84C4mxYJ3rg3jLKJ

