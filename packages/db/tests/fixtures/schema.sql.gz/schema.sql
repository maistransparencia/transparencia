CREATE SCHEMA IF NOT EXISTS analytics;
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_elemento_despesa; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.dim_elemento_despesa (
    elemento_codigo text NOT NULL,
    elemento_descricao text NOT NULL,
    categoria_macro text NOT NULL
);


--
-- Name: dim_metadata; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.dim_metadata (
    portal_slug text,
    key text,
    value text
);


--
-- Name: dim_orgao; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.dim_orgao (
    orgao_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    orgao_nome text,
    cnpj text
);


--
-- Name: dim_portais; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.dim_portais (
    portal_slug text NOT NULL,
    display_name text,
    uf text,
    portal_url text,
    base_host text,
    cidade_clean text,
    ano_inicial integer,
    empresa_padrao text,
    brasao_asset text,
    previdencia_habilitado boolean,
    previdencia_sigla text,
    previdencia_nome text,
    previdencia_cnpj text,
    plano_saude_habilitado boolean,
    plano_saude_nome text,
    plano_saude_sigla text,
    plano_saude_cnpj text,
    highlights_json text,
    cod_ibge integer,
    data_extracao date
);


--
-- Name: fct_analise_despesas_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_analise_despesas_metricas (
    analise_despesas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    orgao_codigo text NOT NULL,
    unidade_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    total_dotacao_atualizada numeric(15,2) NOT NULL,
    total_empenhado numeric(15,2) NOT NULL,
    total_liquidado numeric(15,2) NOT NULL,
    total_pago numeric(15,2) NOT NULL
);


--
-- Name: fct_anomalias_fiscais_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_anomalias_fiscais_metricas (
    anomalia_id text,
    portal_slug text,
    ano integer,
    tipo_anomalia text,
    dimensao_referencia text,
    grau_severidade text,
    desvio_percentual numeric(15,2),
    valor_observado numeric(18,2),
    valor_esperado numeric(18,2),
    mes_inicial integer,
    mes_final integer,
    licitacao_numero text,
    metodo_deteccao text
);


--
-- Name: fct_contratos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_contratos (
    contrato_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    contrato_numero text,
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    objeto text,
    valor_contrato numeric(15,2),
    valor_aditado numeric(15,2),
    licitacao_numero text,
    modalidade text,
    mes text,
    tipo_obra text,
    numero_obra text,
    fundlegal text,
    empenhado numeric(15,2),
    objeto_completo text,
    data_inicio date,
    vencimento_atual date,
    saldo_a_empenhar numeric(15,2)
);


--
-- Name: fct_contratos_recursos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_contratos_recursos (
    contrato_recurso_id text NOT NULL,
    contrato_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    orgao_id text,
    orgao_nome text,
    contrato_numero text,
    licitacao_numero text,
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    valor_contrato numeric(15,2),
    valor_aditado numeric(15,2),
    total_empenhado numeric(15,2),
    total_liquidado numeric(15,2),
    total_pago numeric(15,2),
    saldo_a_pagar numeric(15,2),
    fonte_principal text,
    fontes_recursos text,
    principal_funcao text,
    principal_programa text,
    principal_acao text
);


--
-- Name: fct_contratos_servicos_vigentes; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_contratos_servicos_vigentes (
    contrato_servico_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    contrato_numero text,
    fornecedor_nome text,
    fornecedor_cnpj text,
    objeto_descricao text,
    data_inicio date,
    vencimento_atual date,
    valor_aditado numeric(15,2),
    total_empenhado numeric(15,2),
    total_liquidado numeric(15,2),
    total_pago numeric(15,2),
    status_execucao text NOT NULL
);


--
-- Name: fct_despesas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_despesas (
    despesa_id text NOT NULL,
    portal_slug text NOT NULL,
    fonte text,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    empenho_id text NOT NULL,
    pk_empenho text,
    tipo_empenho text,
    orgao_codigo text,
    unidade_codigo text,
    funcao text,
    funcao_nome text,
    subfuncao text,
    subfuncao_nome text,
    elemento text,
    natureza_despesa text,
    grupo_natureza text,
    modalidade text,
    programa text,
    programa_nome text,
    proj_atividade text,
    projeto_atividade_nome text,
    mes text,
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    licitacao_numero text,
    licitacao_modalidade text,
    fonte_recurso_desc text,
    descricao text,
    natureza_despesa_codigo text,
    natureza_despesa_codigo_sugerido text,
    natureza_despesa_nome_sugerido text,
    categoria_objeto_sugerida text,
    categoria_gasto_sensivel text,
    credor_id text,
    orgao_id text,
    data_empenho date,
    empenhado numeric(15,2),
    empenhado_liquido numeric(15,2),
    liquidado numeric(15,2),
    pago numeric(15,2),
    dotacao_inicial numeric(15,2),
    alteracao_dotacao numeric(15,2),
    dotacao_atualizada numeric(15,2),
    reforco numeric(15,2),
    valor_anulacoes numeric(15,2)
);


--
-- Name: fct_despesas_diarias_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_despesas_diarias_metricas (
    diarias_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    favorecido text NOT NULL,
    cargo text NOT NULL,
    total_valor numeric(15,2) NOT NULL,
    qtd_concessoes integer NOT NULL
);


--
-- Name: fct_despesas_fornecedores_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_despesas_fornecedores_metricas (
    fornecedores_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    fornecedor_codigo text NOT NULL,
    fornecedor_nome text NOT NULL,
    fornecedor_cidade_clean text NOT NULL,
    total_empenhado numeric(15,2) NOT NULL,
    total_pago numeric(15,2) NOT NULL
);


--
-- Name: fct_despesas_por_fornecedor; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_despesas_por_fornecedor (
    portal_slug text,
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    fornecedor_cpf_cnpj text,
    fornecedor_cidade_clean text,
    fornecedor_cidade text,
    empenhado numeric(15,2),
    liquidado numeric(15,2),
    pago numeric(15,2)
);


--
-- Name: fct_despesas_por_orgao; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_despesas_por_orgao (
    portal_slug text,
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    empenhado numeric(15,2),
    liquidado numeric(15,2),
    pago numeric(15,2),
    dotacao_atualizada numeric(15,2)
);


--
-- Name: fct_despesas_por_unidade; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_despesas_por_unidade (
    portal_slug text,
    empresa text,
    ano integer,
    codigo text,
    descricao text,
    empenhado numeric(15,2),
    liquidado numeric(15,2),
    pago numeric(15,2),
    dotacao_atualizada numeric(15,2)
);


--
-- Name: fct_despesas_restos_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_despesas_restos_metricas (
    restos_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    restos_inscritos numeric(15,2),
    restos_liquidados numeric(15,2),
    restos_pagos numeric(15,2),
    restos_cancelados numeric(15,2),
    saldo_restos numeric(15,2),
    divida_mais_antiga_ano integer NOT NULL
);


--
-- Name: fct_diarias; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_diarias (
    id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    diaria_id text,
    valor numeric(15,2),
    favorecido text,
    cargo text,
    data date,
    unidade text,
    descricao text
);


--
-- Name: fct_educacao_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_educacao_metricas (
    educacao_metrica_id text NOT NULL,
    portal_slug text NOT NULL,
    cod_ibge integer NOT NULL,
    ano integer NOT NULL,
    rede text NOT NULL,
    etapa_ensino text NOT NULL,
    nota_ideb numeric(3,1),
    meta_ideb numeric(3,1),
    atingiu_meta_flag boolean,
    saeb_matematica numeric(5,2),
    saeb_lingua_portuguesa numeric(5,2),
    indicador_fluxo_aprovacao numeric(7,6),
    crescimento_pontos_ideb numeric(3,1),
    variacao_saeb_matematica numeric(5,2),
    variacao_saeb_portugues numeric(5,2),
    despesa_liquidada_educacao numeric(15,2),
    total_matriculas_rede_municipal integer,
    custo_anual_por_aluno numeric(15,2)
);


--
-- Name: fct_emendas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_emendas (
    emenda_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    numero_emenda text,
    resumo text,
    valor_total numeric(15,2),
    empenhado numeric(15,2),
    autor text,
    tipo_emenda text,
    esfera_origem text,
    ato_normativo text,
    destinacao text
);


--
-- Name: fct_execucao_orcamentaria_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_execucao_orcamentaria_metricas (
    execucao_orcamentaria_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    orgao_codigo text NOT NULL,
    orgao_nome text,
    unidade_codigo text NOT NULL,
    funcao_codigo text NOT NULL,
    subfuncao_codigo text NOT NULL,
    total_dotacao_atualizada numeric(15,2) NOT NULL,
    total_empenhado numeric(15,2) NOT NULL,
    total_liquidado numeric(15,2) NOT NULL,
    total_pago numeric(15,2) NOT NULL,
    saldo_orcamentario numeric(15,2) NOT NULL,
    taxa_execucao numeric(15,4) NOT NULL,
    alerta_execucao text NOT NULL
);


--
-- Name: fct_fontes_receita_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_fontes_receita_metricas (
    fontes_receita_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    receita_propria_previsto numeric(15,2) NOT NULL,
    receita_propria_arrecadado numeric(15,2) NOT NULL,
    transferencias_uniao_previsto numeric(15,2) NOT NULL,
    transferencias_uniao_arrecadado numeric(15,2) NOT NULL,
    transferencias_estado_previsto numeric(15,2) NOT NULL,
    transferencias_estado_arrecadado numeric(15,2) NOT NULL,
    receita_extra_orcamentaria_arrecadado numeric(15,2) NOT NULL,
    total_previsto numeric(15,2) NOT NULL,
    total_arrecadado numeric(15,2) NOT NULL,
    receita_corrente_liquida numeric NOT NULL,
    pct_propria numeric(15,4) NOT NULL,
    alerta_dependencia boolean NOT NULL,
    fpm_arrecadado numeric(15,2) NOT NULL,
    icms_arrecadado numeric(15,2) NOT NULL,
    iss_iptu_arrecadado numeric(15,2) NOT NULL,
    emendas_pix_arrecadado numeric(15,2) NOT NULL,
    emendas_individuais_arrecadado numeric(15,2) NOT NULL,
    emendas_total_arrecadado numeric(15,2) NOT NULL,
    emendas_total_empenhado numeric(15,2) NOT NULL
);


--
-- Name: fct_historia_saude_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_historia_saude_metricas (
    historia_saude_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    dotacao_total numeric(15,2) NOT NULL,
    total_empenhado numeric(15,2) NOT NULL,
    total_liquidado numeric(15,2) NOT NULL,
    total_pago numeric(15,2) NOT NULL,
    medicamentos_insumos_empenhado numeric(15,2) NOT NULL,
    medicamentos_insumos_pago numeric(15,2) NOT NULL,
    judicializacao_empenhado numeric(15,2) NOT NULL,
    judicializacao_pago numeric(15,2) NOT NULL,
    emendas_saude_arrecadado numeric(15,2) NOT NULL,
    hhi_concentracao_fornecedores integer NOT NULL,
    receita_uniao_saude numeric(15,2) NOT NULL,
    receita_estado_saude numeric(15,2) NOT NULL,
    repasses_prefeitura_saude numeric(15,2) NOT NULL,
    uniao_sus_pct integer NOT NULL,
    estado_pct integer NOT NULL,
    propria_pct integer NOT NULL
);


--
-- Name: fct_licitacoes; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_licitacoes (
    licitacao_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    licitacao_numero text,
    modalidade text,
    objeto text,
    discriminacao text,
    valor numeric(15,2),
    valor_estimado numeric(15,2),
    valor_homologado numeric(15,2),
    situacao text,
    data_abertura date,
    carona text,
    fonte_objeto text,
    link_sistema_origem text
);


--
-- Name: fct_licitacoes_itens; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_licitacoes_itens (
    item_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    licitacao_numero text NOT NULL,
    numero_item integer NOT NULL,
    descricao text,
    quantidade numeric(15,4),
    unidade_medida text,
    valor_unitario_estimado numeric(15,4),
    valor_total_estimado numeric(15,2),
    valor_unitario_homologado numeric(15,4),
    valor_total_homologado numeric(15,2),
    percentual_desconto numeric(5,2),
    fornecedor_nome text,
    fornecedor_cpf_cnpj text,
    situacao_item text
);


--
-- Name: fct_licitacoes_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_licitacoes_metricas (
    licitacao_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    tipo_contratacao text,
    numero text,
    licitacao_numero text,
    contrato_numero text,
    fornecedor_nome text,
    objeto text,
    modalidade text,
    fundlegal text,
    carona text,
    mes integer,
    numero_obra text,
    tipo_obra text,
    quantidade integer,
    licitacao_valor numeric(15,2),
    valor_contrato numeric(15,2),
    empenhado_contrato numeric(15,2),
    pago_contrato numeric(15,2),
    data_referencia date,
    limite_dispensa numeric(15,2),
    isento_legalmente boolean,
    acima_limite boolean
);


--
-- Name: fct_licitacoes_modalidades_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_licitacoes_modalidades_metricas (
    modalidade_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    modalidade text,
    quantidade integer,
    valor_total numeric(15,2)
);


--
-- Name: fct_obras; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_obras (
    portal_slug text NOT NULL,
    id_projeto text NOT NULL,
    nome_obra text,
    funcao_social text,
    descricao_intervencao text,
    natureza_intervencao text,
    especie_intervencao text,
    executor_nome text,
    executor_cnpj text,
    repassador_nome text,
    repassador_cnpj text,
    situacao text,
    orgao_responsavel text,
    valor_investimento_previsto numeric(15,2),
    valor_total_empenhado_federal numeric(15,2),
    quantidade_empenhos_federais integer,
    percentual_execucao_fisica numeric(5,2),
    data_ultima_medicao date,
    latitude numeric(12,8),
    longitude numeric(12,8),
    motivo_paralisacao text,
    data_inicio_prevista date,
    data_fim_prevista date
);


--
-- Name: fct_obras_empenhos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_obras_empenhos (
    portal_slug text NOT NULL,
    id_projeto text NOT NULL,
    nr_empenho text NOT NULL,
    ug_emitente text,
    ano_empenho integer,
    valor_empenho numeric(14,2),
    data_emissao date,
    sistema_origem_empenho text,
    natureza_despesa text,
    fonte text,
    programa_trabalho text,
    plano_interno text,
    acao_orcamentaria text,
    descricao_empenho text
);


--
-- Name: fct_opacidade_contabil_credores; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_opacidade_contabil_credores (
    opacidade_credor_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    credor_codigo text NOT NULL,
    credor_nome text NOT NULL,
    total_empenhos integer NOT NULL,
    total_pago numeric(15,2) NOT NULL,
    pago_desvio_sensivel numeric(15,2) NOT NULL,
    categoria_predominante text NOT NULL,
    amostra_objeto text NOT NULL,
    ranking integer NOT NULL
);


--
-- Name: fct_opacidade_contabil_elementos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_opacidade_contabil_elementos (
    opacidade_elemento_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    elemento_codigo text NOT NULL,
    elemento_descricao text NOT NULL,
    categoria_macro text NOT NULL,
    tipo_residual text NOT NULL,
    total_empenhos integer NOT NULL,
    total_pago numeric(15,2) NOT NULL,
    percentual_do_residual_99 numeric(5,2) NOT NULL,
    ranking integer NOT NULL
);


--
-- Name: fct_opacidade_contabil_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_opacidade_contabil_metricas (
    opacidade_metricas_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    total_empenhos integer NOT NULL,
    empenhos_residual_99 integer NOT NULL,
    empenhos_desvio_sensivel_99 integer NOT NULL,
    taxa_empenhos_opacidade_pct numeric(5,2) NOT NULL,
    total_pago numeric(15,2) NOT NULL,
    pago_residual_99 numeric(15,2) NOT NULL,
    pago_desvio_sensivel_99 numeric(15,2) NOT NULL,
    taxa_valor_opacidade_pct numeric(5,2) NOT NULL,
    taxa_desvio_sensivel_pct numeric(5,2) NOT NULL,
    classificacao_risco text NOT NULL
);


--
-- Name: fct_orcamento_funcional_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_orcamento_funcional_metricas (
    orcamento_funcional_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    funcao_nome text NOT NULL,
    subfuncao_nome text NOT NULL,
    dotacao_atualizada numeric(15,2) NOT NULL,
    empenhado numeric(15,2) NOT NULL,
    liquidado numeric(15,2) NOT NULL,
    pago numeric(15,2) NOT NULL
);


--
-- Name: fct_pessoal; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_pessoal (
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    mes integer NOT NULL,
    empresa_id text NOT NULL,
    proventos numeric(15,2),
    categoria_funcional text,
    vinculo text,
    cargo text,
    forma_provimento text,
    matricula text,
    categoria_regime text,
    regime_previdenciario text
);


--
-- Name: fct_pessoal_departamento_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_pessoal_departamento_metricas (
    departamento_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    descricao text,
    total_pago numeric(15,2)
);


--
-- Name: fct_pessoal_folha_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_pessoal_folha_metricas (
    pessoal_folha_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    total_folha numeric(15,2),
    despesa_total_pessoal_lrf numeric(15,2),
    total_pago numeric(15,2),
    empenhado_13 numeric(15,2),
    empenhado_bruto_13 numeric(15,2),
    liquidado_13 numeric(15,2),
    pago_13 numeric(15,2),
    efetivos_confianca integer,
    comissionados_externos integer,
    bin_0_25k integer,
    bin_25k_5k integer,
    bin_5k_75k integer,
    bin_75k_10k integer,
    bin_10k_125k integer,
    bin_125k_15k integer,
    bin_15k_175k integer,
    bin_175k_20k integer,
    bin_acima_20k integer
);


--
-- Name: fct_pessoal_regime_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_pessoal_regime_metricas (
    pessoal_regime_metricas_id text,
    portal_slug text,
    ano integer,
    empresa_id text,
    categoria_regime text,
    mes_referencia integer,
    total_profissionais integer,
    total_proventos numeric(15,2),
    provento_medio numeric(15,2),
    percentual_profissionais numeric(5,2),
    percentual_folha numeric(5,2)
);


--
-- Name: fct_posicao_fiscal_detalhes_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_posicao_fiscal_detalhes_metricas (
    posicao_fiscal_detalhes_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    administracao text NOT NULL,
    valor_empenhado numeric(15,2) NOT NULL,
    valor_liquidado numeric(15,2) NOT NULL,
    valor_pago numeric(15,2) NOT NULL,
    valor_pendente numeric(15,2) NOT NULL,
    fornecedor_nome text
);


--
-- Name: fct_posicao_fiscal_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_posicao_fiscal_metricas (
    posicao_fiscal_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    total_arrecadado numeric(15,2) NOT NULL,
    despesas_pagas numeric(15,2) NOT NULL,
    restos_liquidados_no_ano numeric(15,2) NOT NULL,
    restos_pagos_no_ano numeric(15,2) NOT NULL,
    restos_pendentes_adm_anterior numeric(15,2) NOT NULL,
    restos_pendentes_adm_atual numeric(15,2) NOT NULL,
    saldo_estimado numeric(15,2) NOT NULL
);


--
-- Name: fct_previdencia_cadprev_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_previdencia_cadprev_metricas (
    previdencia_cadprev_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empenho_id text,
    descricao text,
    data_empenho date,
    empenhado numeric(15,2) NOT NULL,
    pago numeric(15,2) NOT NULL
);


--
-- Name: fct_previdencia_entidades_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_previdencia_entidades_metricas (
    previdencia_entidade_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    entidade text NOT NULL,
    empenhado numeric(15,2) NOT NULL,
    liquidado numeric(15,2) NOT NULL,
    pago numeric(15,2) NOT NULL,
    taxa_execucao numeric(15,2) NOT NULL
);


--
-- Name: fct_previdencia_historia_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_previdencia_historia_metricas (
    previdencia_historia_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    total_aporte_exigido numeric(15,2) NOT NULL,
    total_aporte_quitado numeric(15,2) NOT NULL,
    taxa_adimplencia_aporte numeric(15,4) NOT NULL,
    total_empenhado_patronal numeric(15,2) NOT NULL,
    total_liquidado_patronal numeric(15,2) NOT NULL,
    total_pago_patronal numeric(15,2) NOT NULL,
    rombo_patronal_nao_repassado numeric(15,2) NOT NULL,
    total_amortizacao_divida numeric(15,2) NOT NULL,
    total_casp_plano_saude numeric(15,2) NOT NULL,
    total_empenhado numeric(15,2) NOT NULL,
    total_liquidado numeric(15,2) NOT NULL,
    total_pago numeric(15,2) NOT NULL,
    servidores_efetivos integer NOT NULL,
    servidores_temporarios integer NOT NULL
);


--
-- Name: fct_previdencia_natureza_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_previdencia_natureza_metricas (
    previdencia_natureza_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empenho_id text,
    elemento text NOT NULL,
    natureza_despesa text NOT NULL,
    destino text NOT NULL,
    descricao text,
    data_empenho date,
    empenhado numeric(15,2) NOT NULL,
    liquidado numeric(15,2) NOT NULL,
    pago numeric(15,2) NOT NULL
);


--
-- Name: fct_previdencia_patrimonio_historico_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_previdencia_patrimonio_historico_metricas (
    previdencia_patrimonio_historico_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    mes_referencia integer NOT NULL,
    saldo_caixa numeric(15,2) NOT NULL,
    saldo_aplicacoes numeric(15,2) NOT NULL,
    patrimonio_total numeric(15,2) NOT NULL,
    inconsistencia_declaracao_flag boolean NOT NULL,
    variacao_abs numeric(15,2),
    variacao_pct numeric(15,2)
);


--
-- Name: fct_previdencia_tendencia_atuarial_metricas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_previdencia_tendencia_atuarial_metricas (
    previdencia_tendencia_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    aporte_exigido numeric(15,2) NOT NULL,
    aporte_quitado numeric(15,2) NOT NULL,
    taxa_adimplencia numeric(15,2) NOT NULL,
    amortizacao_divida numeric(15,2) NOT NULL
);


--
-- Name: fct_receita_extra_orcamentaria; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_receita_extra_orcamentaria (
    receita_extra_id text NOT NULL,
    portal_slug text NOT NULL,
    empresa_id text NOT NULL,
    ano integer NOT NULL,
    codigo text,
    descricao text,
    valor_arrecadado numeric(15,2) NOT NULL
);


--
-- Name: fct_receitas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_receitas (
    receita_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    tipo_receita text,
    codigo text,
    descricao text,
    previsao_atualizada numeric(15,2),
    arrecadado numeric(15,2)
);


--
-- Name: fct_saldo_caixa_siconfi; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_saldo_caixa_siconfi (
    saldo_caixa_id text,
    portal_slug text,
    cod_ibge integer,
    ano integer,
    mes_referencia integer,
    poder_orgao text,
    grupo_destinacao text,
    empresa_id text,
    orgao_id text,
    orgao_nome text,
    entidade_nome text,
    cnpj text,
    data_referencia text,
    saldo_caixa_bancos numeric(18,2),
    saldo_recursos_livres numeric(18,2),
    saldo_recursos_vinculados numeric(18,2),
    ultima_competencia_flag boolean
);


--
-- Name: fct_transferencias; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.fct_transferencias (
    transferencia_id text NOT NULL,
    portal_slug text NOT NULL,
    ano integer NOT NULL,
    empresa_id text NOT NULL,
    mes text,
    entidade_pagadora text,
    entidade_recebedora text,
    repasse numeric(15,2),
    devolucao numeric(15,2)
);


--
-- Name: seed_censo_escolar_matriculas; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_censo_escolar_matriculas (
    portal_slug text,
    cod_ibge integer,
    ano integer,
    total_matriculas_rede_municipal integer
);


--
-- Name: seed_constantes_fiscais; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_constantes_fiscais (
    dominio text,
    chave text,
    ano_inicio integer,
    ano_fim integer,
    valor_num numeric,
    valor_txt text,
    descricao text,
    base_legal text,
    url_base_legal text
);


--
-- Name: seed_elemento_despesa; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_elemento_despesa (
    elemento_codigo text,
    elemento_descricao text,
    categoria_macro text
);


--
-- Name: seed_fontes_recursos_stn; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_fontes_recursos_stn (
    codigo_fonte text,
    descricao text,
    grupo_destinacao text,
    recurso_vinculado_flag boolean
);


--
-- Name: seed_funcao_subfuncao; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_funcao_subfuncao (
    funcao_subfuncao_codigo text,
    funcao_codigo text,
    funcao_nome text,
    subfuncao_codigo text,
    subfuncao_nome text
);


--
-- Name: seed_inep_ideb; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_inep_ideb (
    cod_ibge integer,
    ano integer,
    rede text,
    etapa_ensino text,
    nota_ideb numeric,
    meta_ideb numeric,
    saeb_matematica numeric,
    saeb_lingua_portuguesa numeric,
    taxa_aprovacao numeric
);


--
-- Name: seed_inep_ideb_estados; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_inep_ideb_estados (
    cod_uf integer,
    sigla_uf text,
    ano integer,
    rede text,
    etapa_ensino text,
    nota_ideb numeric
);


--
-- Name: seed_natividade_prefeitura_orgaos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_natividade_prefeitura_orgaos (
    portal_slug text,
    empresa_id text,
    nome text,
    cnpj text
);


--
-- Name: seed_natividade_prefeitura_siconfi_orgaos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_natividade_prefeitura_siconfi_orgaos (
    portal_slug text,
    poder_orgao text,
    grupo_destinacao text,
    empresa_id text,
    descricao text
);


--
-- Name: seed_natureza_despesa; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_natureza_despesa (
    natureza_despesa_codigo text,
    categoria_economica_codigo text,
    categoria_economica_nome text,
    gnd_codigo text,
    gnd_nome text,
    modalidade_codigo text,
    modalidade_nome text
);


--
-- Name: seed_naturezas_despesa_stn; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_naturezas_despesa_stn (
    natureza_codigo text,
    natureza_descricao text,
    elemento_codigo text,
    categoria_macro text,
    is_sensivel boolean
);


--
-- Name: seed_pncp_licitacoes_mapeamento; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_pncp_licitacoes_mapeamento (
    portal_slug text,
    ano integer,
    licitacao_numero text,
    ano_compra integer,
    sequencial_compra integer,
    confianca text
);


--
-- Name: seed_porciuncula_prefeitura_orgaos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_porciuncula_prefeitura_orgaos (
    portal_slug text,
    empresa_id text,
    nome text,
    cnpj text
);


--
-- Name: seed_porciuncula_prefeitura_siconfi_orgaos; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_porciuncula_prefeitura_siconfi_orgaos (
    portal_slug text,
    poder_orgao text,
    grupo_destinacao text,
    empresa_id text,
    descricao text
);


--
-- Name: seed_portais; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.seed_portais (
    portal_slug text,
    display_name text,
    uf text,
    portal_url text,
    base_host text,
    cidade_clean text,
    ano_inicial integer,
    empresa_padrao text,
    brasao_asset text,
    previdencia_habilitado boolean,
    previdencia_sigla text,
    previdencia_nome text,
    previdencia_cnpj text,
    highlights_json text,
    cod_ibge integer,
    plano_saude_habilitado boolean,
    plano_saude_nome text,
    plano_saude_sigla text,
    plano_saude_cnpj text
);


--
-- Name: dim_elemento_despesa dim_elemento_despesa__dbt_tmp_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.dim_elemento_despesa
    ADD CONSTRAINT dim_elemento_despesa__dbt_tmp_pkey PRIMARY KEY (elemento_codigo);


--
-- Name: 12237baf26fc051c06042e7d5f158c0f; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX "12237baf26fc051c06042e7d5f158c0f" ON analytics.fct_despesas USING btree (fornecedor_cpf_cnpj);


--
-- Name: 442f04b271d43e73721d2d88c9cf1fd2; Type: INDEX; Schema: analytics; Owner: -
--

CREATE UNIQUE INDEX "442f04b271d43e73721d2d88c9cf1fd2" ON analytics.fct_educacao_metricas USING btree (portal_slug, ano, etapa_ensino);


--
-- Name: 9a952f43337f8c009e9b7ce3095f7318; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX "9a952f43337f8c009e9b7ce3095f7318" ON analytics.fct_educacao_metricas USING btree (portal_slug);


--
-- Name: a6124ed979e49aced133488fa4b08131; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX a6124ed979e49aced133488fa4b08131 ON analytics.fct_despesas USING btree (categoria_gasto_sensivel);


--
-- Name: ac18ff26ef3760c288fa7734dcaa7b0c; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX ac18ff26ef3760c288fa7734dcaa7b0c ON analytics.fct_despesas USING btree (portal_slug, ano);


--
-- Name: c93e4c9a5fe969b86e3438ff7696c20d; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX c93e4c9a5fe969b86e3438ff7696c20d ON analytics.fct_despesas USING btree (fonte);


--
-- Name: d2786647cc5a6ffda934c24a946a37b4; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX d2786647cc5a6ffda934c24a946a37b4 ON analytics.fct_educacao_metricas USING btree (portal_slug, ano);


--
-- Name: e3deb713de4efa1f74b87ab7c9cc4902; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX e3deb713de4efa1f74b87ab7c9cc4902 ON analytics.fct_despesas USING btree (portal_slug, ano, empresa_id);


--
-- Name: ef4700c67984c311308ec29e7cf8fbe3; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX ef4700c67984c311308ec29e7cf8fbe3 ON analytics.fct_despesas USING btree (funcao);


--
-- Name: f583e6b46f35f3aab89744ab1b7a1ffa; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX f583e6b46f35f3aab89744ab1b7a1ffa ON analytics.fct_despesas USING btree (elemento);


--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: dim_orgao; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.dim_orgao VALUES ('4dc5ca8a91c6267561a106b45c6dc292', 'porciuncula_prefeitura', '7', 'PREFEITURA MUNICIPAL DE PORCIÚNCULA', '28920999000106');
INSERT INTO analytics.dim_orgao VALUES ('a72abc1e709fc9bd22585fb3830c052d', 'porciuncula_prefeitura', '2', 'FUNDO MUNICIPAL DE SAUDE', '12097798000110');
INSERT INTO analytics.dim_orgao VALUES ('d1cfef29021e7bf09440d659d2319e19', 'porciuncula_prefeitura', '8', 'FUNDO MUNICIPAL DE EDUCAÇÃO', '32169444000141');
INSERT INTO analytics.dim_orgao VALUES ('8ef80964ed6ab734c36ca938e988f00d', 'porciuncula_prefeitura', '3', 'FUNDO MUNICIPAL DE ASSISTENCIA SOCIAL', '12124826000141');
INSERT INTO analytics.dim_orgao VALUES ('cb7af33ed4b6f62b668472887b2d6a24', 'porciuncula_prefeitura', '9', 'FUNDO MUNICIPAL DE DEFESA AMBIENTAL', '43472312000100');
INSERT INTO analytics.dim_orgao VALUES ('11c85737ad84adf034515418ffe6171d', 'porciuncula_prefeitura', '10', 'FUNDO DE SOLIDARIEDADE - FUNDESOL', '43849391000126');
INSERT INTO analytics.dim_orgao VALUES ('a8651811c70fdae4842ea925a319ae28', 'natividade_prefeitura', '1', 'PREFEITURA MUNICIPAL DE NATIVIDADE', '28920304000196');
INSERT INTO analytics.dim_orgao VALUES ('455cff84d88cb89dfc477b64567438f5', 'natividade_prefeitura', '3', 'FUNDO MUNICIPAL DE SAÚDE', '12396542000104');
INSERT INTO analytics.dim_orgao VALUES ('8fba593eb790bd99beccae5504cdae5a', 'natividade_prefeitura', '5', 'FUNDO MUNICIPAL DE EDUCAÇÃO E CULTURA', '23570466000128');
INSERT INTO analytics.dim_orgao VALUES ('86ab3508c9b86008168aa1878bd01ca3', 'natividade_prefeitura', '4', 'FUNDO MUNICIPAL DE ASSISTÊNCIA SOCIAL', '14789074000163');
INSERT INTO analytics.dim_orgao VALUES ('4616869786e179d937f5336a70882658', 'natividade_prefeitura', '9', 'FUNDO MUNICIPAL DE MEIO AMBIENTE', '63642426000169');
INSERT INTO analytics.dim_orgao VALUES ('4f34e8ce6e316fe819cd0d47e8768908', 'natividade_prefeitura', '7', 'FUNDO MUNICIPAL DO IDOSO', '43889802000107');
INSERT INTO analytics.dim_orgao VALUES ('b356039041fffa4c2cf36c7f39e9674a', 'natividade_prefeitura', '6', 'NATPREVI', '01709035000167');


--
-- Data for Name: dim_portais; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.dim_portais VALUES ('porciuncula_prefeitura', 'Prefeitura de Porciúncula', 'RJ', 'https://transparencia.porciuncula.rj.gov.br/transparencia/', 'https://transparencia.porciuncula.rj.gov.br', 'PORCIUNCULA', 2021, '7', 'brasao-porciuncula.png', true, 'CAPREM', 'Caixa de Aposentadoria e Pensões dos Servidores Públicos de Porciúncula', '01180031000134', true, 'Caixa de Assistência a Saúde dos Servidores Municipais de Porciúncula', 'CASP', '07573075000100', '[{"slug":"saude","titulo":"Saúde","descricao":"Execução orçamentária e fornecedores da saúde","icone":"HeartPulse"},{"slug":"previdencia","titulo":"CAPREM","descricao":"Previdência municipal e sustentabilidade atuarial","icone":"Landmark"}]', 3304102, '2026-10-16');
INSERT INTO analytics.dim_portais VALUES ('natividade_prefeitura', 'Prefeitura de Natividade', 'RJ', 'https://portal-pm-natividade.transpgp.com.br/transparencia/', 'https://transparencia.natividade.rj.gov.br', 'NATIVIDADE', 2021, '1', 'brasao-natividade.png', true, 'NATPREVI', 'Instituto de Previdência dos Servidores Públicos do Município de Natividade - NATPREVI', '01709035000167', false, NULL, NULL, NULL, '[{"slug":"saude","titulo":"Saúde","descricao":"Execução orçamentária e fornecedores da saúde","icone":"HeartPulse"},{"slug":"previdencia","titulo":"NATPREVI","descricao":"Previdência municipal e sustentabilidade atuarial","icone":"Landmark"}]', 3303104, '2026-10-16');


--
-- Data for Name: seed_censo_escolar_matriculas; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('porciuncula_prefeitura', 3304102, 2021, 2210);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('porciuncula_prefeitura', 3304102, 2022, 2235);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('porciuncula_prefeitura', 3304102, 2023, 2250);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('porciuncula_prefeitura', 3304102, 2024, 2275);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('porciuncula_prefeitura', 3304102, 2025, 2290);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('porciuncula_prefeitura', 3304102, 2026, 2310);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('natividade_prefeitura', 3303104, 2021, 1720);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('natividade_prefeitura', 3303104, 2022, 1740);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('natividade_prefeitura', 3303104, 2023, 1765);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('natividade_prefeitura', 3303104, 2024, 1780);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('natividade_prefeitura', 3303104, 2025, 1790);
INSERT INTO analytics.seed_censo_escolar_matriculas VALUES ('natividade_prefeitura', 3303104, 2026, 1805);


--
-- Data for Name: seed_constantes_fiscais; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2000, 2020, 33000.00, NULL, 'Limite dispensa obras e engenharia histórico', 'Decreto 9.412/2018', 'http://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/decreto/d9412.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2000, 2020, 17600.00, NULL, 'Limite dispensa compras e serviços histórico', 'Decreto 9.412/2018', 'http://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/decreto/d9412.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2000, 2020, 8000.00, NULL, 'Limite dispensa manutenção de veículos histórico', 'Decreto 9.412/2018', 'http://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/decreto/d9412.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2021, 2021, 100000.00, NULL, 'Limite dispensa obras e engenharia', 'Lei 14.133/2021 Art. 75 I', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2021, 2021, 50000.00, NULL, 'Limite dispensa compras e serviços', 'Lei 14.133/2021 Art. 75 II', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2021, 2021, 8000.00, NULL, 'Limite dispensa manutenção de veículos', 'Lei 14.133/2021 Art. 75 § 7º', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2022, 2022, 108040.82, NULL, 'Limite dispensa obras e engenharia', 'Decreto 10.922/2021', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/decreto/d10922.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2022, 2022, 54020.41, NULL, 'Limite dispensa compras e serviços', 'Decreto 10.922/2021', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/decreto/d10922.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2022, 2022, 8643.27, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 10.922/2021', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/decreto/d10922.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2023, 2023, 114416.65, NULL, 'Limite dispensa obras e engenharia', 'Decreto 11.317/2022', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2022/decreto/d11317.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2023, 2023, 57208.33, NULL, 'Limite dispensa compras e serviços', 'Decreto 11.317/2022', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2022/decreto/d11317.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2023, 2023, 9153.33, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 11.317/2022', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2022/decreto/d11317.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2024, 2024, 119812.02, NULL, 'Limite dispensa obras e engenharia', 'Decreto 11.871/2023', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/decreto/d11871.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2024, 2024, 59906.02, NULL, 'Limite dispensa compras e serviços', 'Decreto 11.871/2023', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/decreto/d11871.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2024, 2024, 9584.96, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 11.871/2023', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/decreto/d11871.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2025, 2025, 125451.15, NULL, 'Limite dispensa obras e engenharia', 'Decreto 12.343/2024', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/decreto/d12343.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2025, 2025, 62725.59, NULL, 'Limite dispensa compras e serviços', 'Decreto 12.343/2024', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/decreto/d12343.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2025, 2025, 10036.10, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 12.343/2024', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2024/decreto/d12343.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_obras_engenharia', 2026, 2099, 130984.20, NULL, 'Limite dispensa obras e engenharia', 'Decreto 12.807/2025', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/d12807.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_compras_servicos', 2026, 2099, 65492.11, NULL, 'Limite dispensa compras e serviços', 'Decreto 12.807/2025', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/d12807.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('licitacoes', 'limite_dispensa_veiculos', 2026, 2099, 10478.74, NULL, 'Limite dispensa manutenção de veículos', 'Decreto 12.807/2025', 'http://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/d12807.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('pessoal', 'lrf_limite_maximo_executivo', 2000, 2099, 54.00, NULL, 'Limite máximo LRF Pessoal Executivo', 'LC 101/2000 Art. 20 III b', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('pessoal', 'lrf_limite_prudencial_executivo', 2000, 2099, 51.30, NULL, 'Limite prudencial LRF Pessoal Executivo', 'LC 101/2000 Art. 22', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('pessoal', 'lrf_limite_alerta_executivo', 2000, 2099, 48.60, NULL, 'Limite de alerta LRF Pessoal Executivo', 'LC 101/2000 Art. 59 § 1º I', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('despesas', 'elemento_folha_pessoal', 2000, 2099, NULL, '11', 'Código do elemento de despesa de folha de pagamento', 'Portaria STN/SOF', 'https://www.gov.br/tesouronacional/pt-br');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('despesas', 'elemento_subvencoes_sociais', 2000, 2099, NULL, '43', 'Código do elemento de despesa de subvenções sociais', 'Portaria STN/SOF', 'https://www.gov.br/tesouronacional/pt-br');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('opacidade', 'opacidade_limite_atencao_pct', 2000, 2099, 15.00, NULL, 'Limite de atenção para taxa de subitens residuais .99', 'Lei 4.320/64 Arts. 5º e 15', 'http://www.planalto.gov.br/ccivil_03/leis/l4320.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('opacidade', 'opacidade_limite_critico_pct', 2000, 2099, 30.00, NULL, 'Limite de concentração elevada para subitens residuais .99', 'Acórdão TCU 1540/2014 e Lei 4.320/64', 'http://www.planalto.gov.br/ccivil_03/leis/l4320.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_especificacao_orcamentaria', 2000, 2099, NULL, NULL, 'Princípio da Especificação Orçamentária', 'Lei 4.320/1964 Arts. 5º e 15', 'http://www.planalto.gov.br/ccivil_03/leis/l4320.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_transparencia_lrf', 2000, 2099, NULL, NULL, 'Transparência da Gestão Fiscal e Acesso Público', 'LC 101/2000 Art. 48', 'http://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_fracionamento_despesa', 2000, 2099, NULL, NULL, 'Vedação ao Fracionamento de Despesas e Crime de Burla a Licitação', 'Lei 14.133/2021 Art. 75 e CP Art. 337-E', 'http://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm');
INSERT INTO analytics.seed_constantes_fiscais VALUES ('opacidade', 'base_legal_carater_residual_tcu', 2000, 2099, NULL, NULL, 'Caráter Residual Excepcional do Subitem 99', 'Acórdão TCU nº 1.540/2014 - Plenário', 'https://pesquisa.apps.tcu.gov.br/');


--
-- Data for Name: seed_elemento_despesa; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_elemento_despesa VALUES ('00', 'A Classificar / Sem Elemento', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('01', 'Aposentadorias do RPPS, Reserva Remunerada e Reformas dos Militares', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('02', 'Pensões Militares', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('03', 'Pensões do RPPS e do Militar', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('04', 'Contratação por Tempo Determinado', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('05', 'Outros Benefícios Previdenciários do Servidor ou do Militar', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('06', 'Benefício Mensal ao Deficiente e ao Idoso', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('07', 'Contribuição a Entidades Fechadas de Previdência', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('08', 'Outros Benefícios Assistenciais do Servidor e do Militar', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('09', 'Salário-Família', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('10', 'Outros Benefícios de Natureza Social', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('11', 'Vencimentos e Vantagens Fixas - Pessoal Civil', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('12', 'Vencimentos e Vantagens Fixas - Pessoal Militar', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('13', 'Contribuições Patronais', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('14', 'Diárias - Civil', 'Diárias');
INSERT INTO analytics.seed_elemento_despesa VALUES ('15', 'Diárias - Militar', 'Diárias');
INSERT INTO analytics.seed_elemento_despesa VALUES ('16', 'Outras Despesas Variáveis - Pessoal Civil', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('17', 'Outras Despesas Variáveis - Pessoal Militar', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('18', 'Auxílio-Financeiro a Estudantes', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('19', 'Auxílio-Fardamento', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('20', 'Auxílio-Financeiro a Pesquisadores', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('21', 'Juros sobre a Dívida por Contrato', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('22', 'Outros Encargos sobre a Dívida por Contrato', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('23', 'Juros, Deságios e Descontos da Dívida Mobiliária', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('24', 'Outros Encargos sobre a Dívida Mobiliária', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('25', 'Encargos sobre Operações de Crédito por Antecipação da Receita', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('26', 'Arrendamento Mercantil', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('27', 'Encargos pela Honra de Avais, Garantias, Fianças e Referendos', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('28', 'Remuneração de Cotas de Fundos Autárquicos', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('29', 'Distribuição de Resultado de Empresas Estatais Dependentes', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('30', 'Material de Consumo', 'Material');
INSERT INTO analytics.seed_elemento_despesa VALUES ('31', 'Premiações Culturais, Artísticas, Científicas, Desportivas e Outras', 'Material');
INSERT INTO analytics.seed_elemento_despesa VALUES ('32', 'Material, Bem ou Serviço para Distribuição Gratuita', 'Material');
INSERT INTO analytics.seed_elemento_despesa VALUES ('33', 'Passagens e Despesas com Locomoção', 'Material');
INSERT INTO analytics.seed_elemento_despesa VALUES ('34', 'Outras Despesas de Pessoal decorrentes de Contratos de Terceirização', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('35', 'Serviços de Consultoria', 'Serviços de Terceiros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('36', 'Outros Serviços de Terceiros - Pessoa Física', 'Serviços de Terceiros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('37', 'Locação de Mão-de-Obra', 'Serviços de Terceiros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('38', 'Arrendamento Mercantil', 'Serviços de Terceiros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('39', 'Outros Serviços de Terceiros - Pessoa Jurídica', 'Serviços de Terceiros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('40', 'Serviços de Tecnologia da Informação e Comunicação - PJ', 'Serviços de Terceiros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('41', 'Contribuições', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('42', 'Auxílios', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('43', 'Subvenções Sociais', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('44', 'Obras e Instalações', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('45', 'Subvenções Econômicas', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('46', 'Auxílio-Alimentação', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('47', 'Obrigações Tributárias e Contributivas', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('48', 'Outros Auxílios Financeiros a Pessoas Físicas', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('49', 'Auxílio-Transporte', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('50', 'Sede de Direitos Orçamentários', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('51', 'Obras e Instalações', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('52', 'Equipamentos e Material Permanente', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('53', 'Elemento Reservado 53', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('54', 'Elemento Reservado 54', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('55', 'Elemento Reservado 55', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('56', 'Elemento Reservado 56', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('57', 'Elemento Reservado 57', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('58', 'Elemento Reservado 58', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('59', 'Elemento Reservado 59', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('60', 'Elemento Reservado 60', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('61', 'Aquisição de Imóveis', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('62', 'Aquisição de Bens para Revenda', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('63', 'Aquisição de Títulos de Crédito', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('64', 'Aquisição de Títulos Representativos de Capital já Constituído', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('65', 'Constituição ou Aumento de Capital de Empresas', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('66', 'Concessão de Empréstimos e Financiamentos', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('67', 'Depósitos Compulsórios', 'Investimentos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('68', 'Elemento Reservado 68', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('69', 'Elemento Reservado 69', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('70', 'Rateio pela Participação em Consórcio Público', 'Transferências');
INSERT INTO analytics.seed_elemento_despesa VALUES ('71', 'Principal da Dívida Contratual Resgatado', 'Amortização da Dívida');
INSERT INTO analytics.seed_elemento_despesa VALUES ('72', 'Principal da Dívida Mobiliária Resgatado', 'Amortização da Dívida');
INSERT INTO analytics.seed_elemento_despesa VALUES ('73', 'Correção Monetária ou Câmbio da Dívida Contratual Resgatada', 'Amortização da Dívida');
INSERT INTO analytics.seed_elemento_despesa VALUES ('74', 'Correção Monetária ou Câmbio da Dívida Mobiliária Resgatada', 'Amortização da Dívida');
INSERT INTO analytics.seed_elemento_despesa VALUES ('75', 'Amortização da Dívida de Operações de Crédito por ARO', 'Amortização da Dívida');
INSERT INTO analytics.seed_elemento_despesa VALUES ('76', 'Principal Operações de Crédito por Antecipação da Receita', 'Amortização da Dívida');
INSERT INTO analytics.seed_elemento_despesa VALUES ('77', 'Atuação em Outros Encargos de Amortização', 'Amortização da Dívida');
INSERT INTO analytics.seed_elemento_despesa VALUES ('78', 'Elemento Reservado 78', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('79', 'Elemento Reservado 79', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('80', 'Elemento Reservado 80', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('81', 'Correção Monetária de Outras Dívidas', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('82', 'Elemento Reservado 82', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('83', 'Elemento Reservado 83', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('84', 'Elemento Reservado 84', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('85', 'Elemento Reservado 85', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('86', 'Elemento Reservado 86', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('87', 'Elemento Reservado 87', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('88', 'Elemento Reservado 88', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('89', 'Elemento Reservado 89', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('90', 'Elemento Reservado 90', 'Outros');
INSERT INTO analytics.seed_elemento_despesa VALUES ('91', 'Sentenças Judiciais', 'Sentenças');
INSERT INTO analytics.seed_elemento_despesa VALUES ('92', 'Despesas de Exercícios Anteriores', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('93', 'Indenizações e Restituições', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('94', 'Indenizações e Restituições Trabalhistas', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('95', 'Indenização pela Execução de Trabalhos de Campo', 'Outras Despesas Correntes');
INSERT INTO analytics.seed_elemento_despesa VALUES ('96', 'Ressarcimento de Despesas de Pessoal Requisitado', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('97', 'Aporte para Cobertura do Déficit Atuarial do RPPS', 'Aporte Atuarial');
INSERT INTO analytics.seed_elemento_despesa VALUES ('98', 'Compensação Financeira entre Regimes de Previdência', 'Pessoal e Encargos');
INSERT INTO analytics.seed_elemento_despesa VALUES ('99', 'A Classificar', 'Outros');


--
-- Data for Name: seed_fontes_recursos_stn; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('10010000', 'Recursos Ordinários Livres (Legado SOF/STN)', 'livre', false);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('10900000', 'Outros Recursos Ordinários Livres (Legado SOF/STN)', 'livre', false);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11110000', 'Receitas de Impostos vinculadas à Educação (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11160000', 'Outras Receitas vinculadas à Educação (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11200000', 'Transferências do FUNDEB (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11210000', 'FUNDEB - Complementação da União (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11220000', 'Salário-Educação (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11230000', 'PNAE - Merenda Escolar (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11240000', 'PNATE - Transporte Escolar (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('11250000', 'Outros Recursos do FNDE (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('12110000', 'Recursos Próprios vinculados à Saúde (Legado SOF/STN)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('12120000', 'Receitas de Impostos vinculadas à Saúde (Legado SOF/STN)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('12130000', 'Transferências Fundo a Fundo do SUS (Legado SOF/STN)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('12140000', 'Transferências de Convênios da Saúde (Legado SOF/STN)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('12142100', 'Convênios Específicos da Saúde (Legado SOF/STN)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('12150000', 'Outros Recursos vinculados à Saúde (Legado SOF/STN)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('12400000', 'Transferências da Saúde - Vigilância Sanitária (Legado)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('13110000', 'Transferências de Convênios e Outros Repasses (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('14100000', 'Operações de Crédito (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('14200000', 'Alienação de Bens (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('14300000', 'Outras Receitas de Capital (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1500', 'Recursos não Vinculados de Impostos', 'livre', false);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1501', 'Outros Recursos não Vinculados / Ações e Serviços Públicos de Saúde (ASPS)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1502', 'Recursos Próprios / Outros Recursos Não Vinculados', 'livre', false);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('15100000', 'Recursos Vinculados Diversos (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('15200000', 'Outras Destinações Vinculadas (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('15300000', 'Compensações Financeiras / Royalties Gerais (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1540', 'Transferências do FUNDEB - Impostos e Transferências de Impostos', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('15400000', 'Transferências do FUNDEB (Legado)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1541', 'Transferências do FUNDEB - Complementação da União - VAAF', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1542', 'Transferências do FUNDEB - Complementação da União - VAAT', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1543', 'Transferências do FUNDEB - Complementação da União - VAAR', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1550', 'Transferência do Salário-Educação', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1551', 'Transferências de Recursos do FNDE - PNAE (Merenda Escolar)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1552', 'Transferências de Recursos do FNDE - PNATE (Transporte Escolar)', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1553', 'Transferências de Recursos do FNDE - Outras Transferências Legais', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1569', 'Outras Transferências de Recursos do FNDE', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1572', 'Transferências de Convênios Vinculados à Educação', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1573', 'Royalties e Compensações Financeiras vinculadas à Educação', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1600', 'Transferências Fundo a Fundo de Recursos do SUS - Bloco de Manutenção', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1601', 'Transferências Fundo a Fundo de Recursos do SUS - Bloco de Estruturação', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1602', 'Transferências do SUS destinadas ao Enfrentamento da COVID-19', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1603', 'Transferências Fundo a Fundo do SUS - Outros Repasses', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1604', 'Transferências de Convênios do SUS', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1605', 'Assistência Financeira Complementar da União - Piso da Enfermagem', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('16100000', 'Outras Transferências Obrigatórias (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('16200000', 'Transferências do SUS (Legado SOF/STN)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1621', 'Transferências de Convênios / Contratos de Repasse vinculados à Saúde', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1622', 'Outras Transferências de Recursos vinculados à Saúde', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1635', 'Transferências do FNS / Compensação Financeira da Saúde', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1660', 'Transferência de Recursos do Fundo Nacional de Assistência Social - FNAS', 'assistencia_social', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1661', 'Transferência de Recursos do FNAS - Bloco de Gestão do SUAS', 'assistencia_social', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1665', 'Transferências de Convênios Vinculados à Assistência Social', 'assistencia_social', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1669', 'Outras Transferências de Recursos Vinculados à Assistência Social', 'assistencia_social', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1700', 'Outras Transferências de Convênios ou Instrumentos Congêneres da União', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1701', 'Transferências de Convênios do Estado', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1704', 'Transferências da União destinadas ao Setor Cultural (Lei Paulo Gustavo / Aldir Blanc)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1705', 'Transferências Decorrentes de Decisões Judiciais', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1708', 'Transferências de Emendas Parlamentares Individuais da União', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1710', 'Transferências de Emendas de Bancada da União', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1715', 'Transferências Especiais da União (Emendas PIX)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1719', 'Outras Transferências de Emendas Parlamentares', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1720', 'Transferências de Emendas Parlamentares Estaduais', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1721', 'Transferências Especiais dos Estados (Emendas PIX Estaduais)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1749', 'Outras Transferências de Convênios', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1750', 'Recursos de Fundos Especiais de Despesa', 'meio_ambiente', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1751', 'Recursos de Fundos de Defesa dos Direitos da Criança e do Adolescente', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1755', 'Recursos de Fundos Municipais de Meio Ambiente', 'meio_ambiente', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1800', 'Recursos do RPPS - Fundo em Capitalização (Plano Previdenciário)', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1801', 'Recursos do RPPS - Fundo em Repartição (Plano Financeiro)', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1802', 'Recursos do RPPS - Taxa de Administração', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1860', 'Outros Recursos Vinculados ao Regime Próprio de Previdência', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('1869', 'Recursos do RPPS - Outras Vinculações', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('19400000', 'Outros Recursos não Aplicados (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('22130000', 'Transferências do SUS - Exercícios Anteriores (Legado)', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('24100000', 'Operações de Crédito - Exercícios Anteriores (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('24200000', 'Alienação de Bens - Exercícios Anteriores (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('24300000', 'Outras Receitas de Capital - Exercícios Anteriores (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2500', 'Recursos não Vinculados de Impostos - Exercícios Anteriores', 'livre', false);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2501', 'Ações e Serviços Públicos de Saúde - Exercícios Anteriores', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('25300000', 'Royalties Gerais - Exercícios Anteriores (Legado)', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2540', 'Transferências do FUNDEB - Exercícios Anteriores', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2550', 'Salário-Educação - Exercícios Anteriores', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2573', 'Royalties da Educação - Exercícios Anteriores', 'educacao', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2600', 'Transferências do SUS - Bloco de Manutenção - Exercícios Anteriores', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2605', 'Piso da Enfermagem - Exercícios Anteriores', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2621', 'Convênios da Saúde - Exercícios Anteriores', 'saude', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2700', 'Convênios da União - Exercícios Anteriores', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2701', 'Convênios do Estado - Exercícios Anteriores', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2704', 'Setor Cultural - Exercícios Anteriores', 'outros_vinculados', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2800', 'Recursos do RPPS - Exercícios Anteriores', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2801', 'Recursos do RPPS - Taxa de Administração - Exercícios Anteriores', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('2802', 'Recursos do RPPS - Outros - Exercícios Anteriores', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('9800', 'Compensação Previdenciária RPPS / RGPS', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('9801', 'Compensação Previdenciária - Regime Geral', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('9802', 'Outras Compensações Previdenciárias', 'previdencia', true);
INSERT INTO analytics.seed_fontes_recursos_stn VALUES ('sem_fonte', 'Sem desdobramento de fonte de recursos na MSC', 'sem_fonte', false);


--
-- Data for Name: seed_funcao_subfuncao; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_funcao_subfuncao VALUES ('01.031', '01', 'Legislativa', '031', 'Ação Legislativa');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('01.032', '01', 'Legislativa', '032', 'Controle Externo');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('02.061', '02', 'Judiciária', '061', 'Ação Judiciária');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('02.062', '02', 'Judiciária', '062', 'Defesa do Interesse Público no Processo Judiciário');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('03.091', '03', 'Essencial à Justiça', '091', 'Defesa da Ordem Jurídica');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('03.092', '03', 'Essencial à Justiça', '092', 'Representação Judicial e Extrajudicial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.121', '04', 'Administração', '121', 'Planejamento e Orçamento');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.122', '04', 'Administração', '122', 'Administração Geral');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.123', '04', 'Administração', '123', 'Administração Financeira');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.124', '04', 'Administração', '124', 'Controle Interno');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.125', '04', 'Administração', '125', 'Normatização e Fiscalização');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.126', '04', 'Administração', '126', 'Tecnologia da Informação');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.127', '04', 'Administração', '127', 'Ordenamento Territorial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.128', '04', 'Administração', '128', 'Formação de Recursos Humanos');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.129', '04', 'Administração', '129', 'Administração de Receitas');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.130', '04', 'Administração', '130', 'Administração de Concessões');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('04.131', '04', 'Administração', '131', 'Comunicação Social');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('05.151', '05', 'Defesa Nacional', '151', 'Defesa Aérea');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('05.152', '05', 'Defesa Nacional', '152', 'Defesa Naval');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('05.153', '05', 'Defesa Nacional', '153', 'Defesa Terrestre');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('06.181', '06', 'Segurança Pública', '181', 'Policiamento');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('06.182', '06', 'Segurança Pública', '182', 'Defesa Civil');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('06.183', '06', 'Segurança Pública', '183', 'Informação e Inteligência');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('07.211', '07', 'Relações Exteriores', '211', 'Relações Diplomáticas');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('07.212', '07', 'Relações Exteriores', '212', 'Cooperação Internacional');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('08.241', '08', 'Assistência Social', '241', 'Assistência ao Idoso');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('08.242', '08', 'Assistência Social', '242', 'Assistência ao Portador de Deficiência');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('08.243', '08', 'Assistência Social', '243', 'Assistência à Criança e ao Adolescente');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('08.244', '08', 'Assistência Social', '244', 'Assistência Comunitária');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('09.271', '09', 'Previdência Social', '271', 'Previdência Básica');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('09.272', '09', 'Previdência Social', '272', 'Previdência do Regime Estatutário');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('09.273', '09', 'Previdência Social', '273', 'Previdência Complementar');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('09.274', '09', 'Previdência Social', '274', 'Previdência Especial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('10.301', '10', 'Saúde', '301', 'Atenção Básica');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('10.302', '10', 'Saúde', '302', 'Assistência Hospitalar e Ambulatorial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('10.303', '10', 'Saúde', '303', 'Suporte Profilático e Terapêutico');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('10.304', '10', 'Saúde', '304', 'Vigilância Sanitária');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('10.305', '10', 'Saúde', '305', 'Vigilância Epidemiológica');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('10.306', '10', 'Saúde', '306', 'Alimentação e Nutrição');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('11.331', '11', 'Trabalho', '331', 'Proteção e Benefícios ao Trabalhador');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('11.332', '11', 'Trabalho', '332', 'Relações de Trabalho');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('11.333', '11', 'Trabalho', '333', 'Empregabilidade');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('11.334', '11', 'Trabalho', '334', 'Fomento ao Trabalho');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.361', '12', 'Educação', '361', 'Ensino Fundamental');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.362', '12', 'Educação', '362', 'Ensino Médio');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.363', '12', 'Educação', '363', 'Ensino Profissional');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.364', '12', 'Educação', '364', 'Ensino Superior');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.365', '12', 'Educação', '365', 'Educação Infantil');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.366', '12', 'Educação', '366', 'Educação de Jovens e Adultos');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.367', '12', 'Educação', '367', 'Educação Especial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('12.368', '12', 'Educação', '368', 'Educação Básica');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('13.391', '13', 'Cultura', '391', 'Patrimônio Histórico, Artístico e Arqueológico');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('13.392', '13', 'Cultura', '392', 'Difusão Cultural');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('14.421', '14', 'Direitos da Cidadania', '421', 'Custódia e Reintegração Social');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('14.422', '14', 'Direitos da Cidadania', '422', 'Direitos Individuais, Coletivos e Difusos');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('14.423', '14', 'Direitos da Cidadania', '423', 'Assistência Jurídica Integral e Gratuita');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('15.451', '15', 'Urbanismo', '451', 'Infra-Estrutura Urbana');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('15.452', '15', 'Urbanismo', '452', 'Serviços Urbanos');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('15.453', '15', 'Urbanismo', '453', 'Transportes Coletivos Urbanos');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('16.481', '16', 'Habitação', '481', 'Habitação Rural');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('16.482', '16', 'Habitação', '482', 'Habitação Urbana');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('17.511', '17', 'Saneamento', '511', 'Saneamento Básico Rural');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('17.512', '17', 'Saneamento', '512', 'Saneamento Básico Urbano');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('18.541', '18', 'Gestão Ambiental', '541', 'Preservação e Conservação Ambiental');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('18.542', '18', 'Gestão Ambiental', '542', 'Controle Ambiental');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('18.543', '18', 'Gestão Ambiental', '543', 'Recuperação de Áreas Degradadas');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('18.544', '18', 'Gestão Ambiental', '544', 'Recursos Hídricos');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('18.545', '18', 'Gestão Ambiental', '545', 'Meteorologia');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('19.571', '19', 'Ciência e Tecnologia', '571', 'Desenvolvimento Científico');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('19.572', '19', 'Ciência e Tecnologia', '572', 'Desenvolvimento Tecnológico e Engenharia');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('19.573', '19', 'Ciência e Tecnologia', '573', 'Difusão do Conhecimento Científico e Tecnológico');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('20.601', '20', 'Agricultura', '601', 'Promoção da Produção Vegetal');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('20.602', '20', 'Agricultura', '602', 'Promoção da Produção Animal');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('20.603', '20', 'Agricultura', '603', 'Defesa Sanitária Vegetal');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('20.604', '20', 'Agricultura', '604', 'Defesa Sanitária Animal');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('20.605', '20', 'Agricultura', '605', 'Abastecimento');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('20.606', '20', 'Agricultura', '606', 'Extensão Rural');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('20.607', '20', 'Agricultura', '607', 'Irrigação');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('21.631', '21', 'Organização Agrária', '631', 'Reforma Agrária');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('21.632', '21', 'Organização Agrária', '632', 'Colonização');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('22.661', '22', 'Indústria', '661', 'Promoção Industrial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('22.662', '22', 'Indústria', '662', 'Produção Industrial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('22.663', '22', 'Indústria', '663', 'Mineração');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('22.664', '22', 'Indústria', '664', 'Propriedade Industrial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('22.665', '22', 'Indústria', '665', 'Normalização e Qualidade');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('23.691', '23', 'Comércio e Serviços', '691', 'Promoção Comercial');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('23.692', '23', 'Comércio e Serviços', '692', 'Comercialização');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('23.693', '23', 'Comércio e Serviços', '693', 'Comércio Exterior');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('23.694', '23', 'Comércio e Serviços', '694', 'Serviços Financeiros');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('23.695', '23', 'Comércio e Serviços', '695', 'Turismo');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('24.721', '24', 'Comunicações', '721', 'Telecomunicações');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('24.722', '24', 'Comunicações', '722', 'Serviços Postais');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('25.751', '25', 'Energia', '751', 'Conservação de Energia');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('25.752', '25', 'Energia', '752', 'Energia Elétrica');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('25.753', '25', 'Energia', '753', 'Combustíveis Minerais');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('25.754', '25', 'Energia', '754', 'Biocombustíveis');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('26.781', '26', 'Transporte', '781', 'Transporte Aéreo');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('26.782', '26', 'Transporte', '782', 'Transporte Rodoviário');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('26.783', '26', 'Transporte', '783', 'Transporte Ferroviário');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('26.784', '26', 'Transporte', '784', 'Transporte Hidroviário');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('26.785', '26', 'Transporte', '785', 'Transportes Especiais');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('27.811', '27', 'Desporto e Lazer', '811', 'Desporto de Rendimento');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('27.812', '27', 'Desporto e Lazer', '812', 'Desporto Comunitário');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('27.813', '27', 'Desporto e Lazer', '813', 'Lazer');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('28.841', '28', 'Encargos Especiais', '841', 'Refinanciamento da Dívida Interna');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('28.842', '28', 'Encargos Especiais', '842', 'Refinanciamento da Dívida Externa');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('28.843', '28', 'Encargos Especiais', '843', 'Serviço da Dívida Interna');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('28.844', '28', 'Encargos Especiais', '844', 'Serviço da Dívida Externa');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('28.845', '28', 'Encargos Especiais', '845', 'Outras Transferências');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('28.846', '28', 'Encargos Especiais', '846', 'Outros Encargos Especiais');
INSERT INTO analytics.seed_funcao_subfuncao VALUES ('99.999', '99', 'Reserva de Contingência', '999', 'Reserva de Contingência e A Classificar');


--
-- Data for Name: seed_inep_ideb; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2021, 'estadual', 'anos_finais', 4.6, 5.2, 240.94, 244.74, 0.966911);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2021, 'municipal', 'anos_finais', 4.5, 5.3, 238.01, 243.87, 0.966929);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2021, 'publica', 'anos_finais', 4.6, 5.2, 239.07, 244.19, 0.96721);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2021, 'estadual', 'anos_iniciais', NULL, 5.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2021, 'municipal', 'anos_iniciais', 5.5, 5.9, 208.09, 197.49, 0.992788);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2021, 'publica', 'anos_iniciais', 5.5, 5.8, 208.09, 197.49, 0.992788);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2023, 'estadual', 'anos_finais', 4.1, NULL, 237.73, 245.75, 0.857324);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2023, 'municipal', 'anos_finais', 4.5, NULL, 239.56, 250.28, 0.92873);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2023, 'publica', 'anos_finais', 4.4, NULL, 238.85, 248.52, 0.911374);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2023, 'municipal', 'anos_iniciais', 5.7, NULL, 217.17, 203.57, 0.974448);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2023, 'publica', 'anos_iniciais', 5.7, NULL, 217.17, 203.57, 0.974655);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2025, 'estadual', 'anos_finais', 4.7, NULL, 243.18, 251.77, 0.949902);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2025, 'municipal', 'anos_finais', 4.7, NULL, 245.2, 251.91, 0.959125);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2025, 'publica', 'anos_finais', 4.7, NULL, 244.73, 251.88, 0.957871);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2025, 'municipal', 'anos_iniciais', 6.1, NULL, 229.11, 213.43, 0.980738);
INSERT INTO analytics.seed_inep_ideb VALUES (3300100, 2025, 'publica', 'anos_iniciais', 6.1, NULL, 229.11, 213.43, 0.980138);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2021, 'estadual', 'anos_finais', 5.5, 5.5, 265.79, 265.31, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2021, 'municipal', 'anos_finais', 5.1, 5.7, 254.55, 254.69, 0.997227);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2021, 'publica', 'anos_finais', 5.3, 5.4, 259.18, 259.07, 0.997481);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2021, 'estadual', 'anos_iniciais', NULL, 6.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2021, 'municipal', 'anos_iniciais', 5.9, 7.0, 211.3, 214.22, 0.997577);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2021, 'publica', 'anos_iniciais', 5.9, 7.0, 211.3, 214.22, 0.997577);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2023, 'estadual', 'anos_finais', 5.5, NULL, 272.99, 275.87, 0.953162);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2023, 'municipal', 'anos_finais', 4.6, NULL, 251.65, 237.57, 0.96092);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2023, 'publica', 'anos_finais', 5.3, NULL, 268.22, 267.31, 0.95562);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2023, 'municipal', 'anos_iniciais', 5.8, NULL, 225.68, 214.01, 0.947033);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2023, 'publica', 'anos_iniciais', 5.8, NULL, 225.68, 214.01, 0.947033);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2025, 'estadual', 'anos_finais', 5.6, NULL, 265.95, 267.51, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2025, 'municipal', 'anos_finais', 4.6, NULL, 243.74, 235.19, 0.986685);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2025, 'publica', 'anos_finais', 5.3, NULL, 261.6, 261.18, 0.993234);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2025, 'municipal', 'anos_iniciais', 6.3, NULL, 234.14, 217.62, 0.989146);
INSERT INTO analytics.seed_inep_ideb VALUES (3300159, 2025, 'publica', 'anos_iniciais', 6.3, NULL, 234.14, 217.62, 0.989146);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2021, 'estadual', 'anos_finais', NULL, 5.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2021, 'municipal', 'anos_finais', 4.7, 5.7, 250.37, 255.13, 0.9192);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2021, 'publica', 'anos_finais', 4.7, 5.6, 250.37, 255.13, 0.9192);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2021, 'estadual', 'anos_iniciais', NULL, 5.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2021, 'municipal', 'anos_iniciais', 5.4, 6.1, 208.01, 201.73, 0.957926);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2021, 'publica', 'anos_iniciais', 5.4, 6.1, 208.01, 201.73, 0.957926);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2023, 'municipal', 'anos_finais', 4.3, NULL, 254.9, 259.87, 0.816151);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2023, 'publica', 'anos_finais', 4.3, NULL, 254.9, 259.87, 0.816151);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2023, 'municipal', 'anos_iniciais', 5.5, NULL, 219.42, 211.45, 0.90983);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2023, 'publica', 'anos_iniciais', 5.5, NULL, 219.42, 211.45, 0.90983);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2025, 'municipal', 'anos_finais', 4.7, NULL, 258.35, 262.56, 0.886732);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2025, 'publica', 'anos_finais', 4.7, NULL, 258.35, 262.56, 0.886732);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2025, 'municipal', 'anos_iniciais', 5.8, NULL, 225.75, 216.28, 0.938239);
INSERT INTO analytics.seed_inep_ideb VALUES (3300209, 2025, 'publica', 'anos_iniciais', 5.8, NULL, 225.75, 216.28, 0.938239);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2021, 'estadual', 'anos_finais', NULL, 5.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2021, 'municipal', 'anos_finais', NULL, 5.0, NULL, NULL, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2021, 'publica', 'anos_finais', NULL, 5.5, NULL, NULL, 0.996718);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2021, 'municipal', 'anos_iniciais', 5.8, 5.9, 208.18, 212.32, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2021, 'publica', 'anos_iniciais', 5.8, 5.9, 208.18, 212.32, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2023, 'estadual', 'anos_finais', 5.1, NULL, 257.04, 261.08, 0.959617);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2023, 'publica', 'anos_finais', 4.1, NULL, 257.04, 261.08, 0.775492);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2023, 'municipal', 'anos_iniciais', 6.0, NULL, 221.38, 216.7, 0.976115);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2023, 'publica', 'anos_iniciais', 6.0, NULL, 221.38, 216.7, 0.976115);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2025, 'estadual', 'anos_finais', 5.2, NULL, 256.61, 254.91, 0.997227);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2025, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2025, 'publica', 'anos_finais', 4.8, NULL, 256.61, 254.91, 0.927528);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2025, 'municipal', 'anos_iniciais', 6.1, NULL, 221.89, 216.45, 0.992181);
INSERT INTO analytics.seed_inep_ideb VALUES (3300225, 2025, 'publica', 'anos_iniciais', 6.1, NULL, 221.89, 216.45, 0.992181);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2021, 'municipal', 'anos_finais', NULL, 5.3, NULL, NULL, 0.932683);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2021, 'publica', 'anos_finais', NULL, 5.3, NULL, NULL, 0.932683);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2021, 'municipal', 'anos_iniciais', 5.5, 6.1, 215.66, 218.11, 0.913647);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2021, 'publica', 'anos_iniciais', 5.5, 6.1, 215.66, 218.11, 0.913647);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2023, 'municipal', 'anos_finais', 4.0, NULL, 241.91, 253.06, 0.823112);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2023, 'publica', 'anos_finais', 4.0, NULL, 241.91, 253.06, 0.823112);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2023, 'municipal', 'anos_iniciais', 5.5, NULL, 226.62, 219.68, 0.882984);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2023, 'publica', 'anos_iniciais', 5.5, NULL, 226.62, 219.68, 0.882984);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2025, 'municipal', 'anos_finais', 4.2, NULL, 244.21, 247.48, 0.867416);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2025, 'publica', 'anos_finais', 4.2, NULL, 244.21, 247.48, 0.867416);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2025, 'municipal', 'anos_iniciais', 5.8, NULL, 222.58, 219.06, 0.929329);
INSERT INTO analytics.seed_inep_ideb VALUES (3300233, 2025, 'publica', 'anos_iniciais', 5.8, NULL, 222.58, 219.06, 0.929329);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2021, 'estadual', 'anos_finais', NULL, 5.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2021, 'municipal', 'anos_finais', NULL, 5.1, NULL, NULL, 0.916397);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2021, 'publica', 'anos_finais', NULL, 5.2, NULL, NULL, 0.916397);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2021, 'estadual', 'anos_iniciais', NULL, 6.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2021, 'municipal', 'anos_iniciais', 5.3, 6.1, 203.69, 204.68, 0.949046);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2021, 'publica', 'anos_iniciais', 5.3, 6.2, 203.69, 204.68, 0.949046);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2023, 'municipal', 'anos_finais', 4.8, NULL, 260.34, 258.92, 0.894235);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2023, 'publica', 'anos_finais', 4.8, NULL, 260.34, 258.92, 0.894235);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 219.6, 208.42, 0.839566);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 219.6, 208.42, 0.839566);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2025, 'municipal', 'anos_finais', 4.8, NULL, 249.3, 255.72, 0.945395);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2025, 'publica', 'anos_finais', 4.8, NULL, 249.3, 255.72, 0.945395);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2025, 'municipal', 'anos_iniciais', 5.6, NULL, 223.77, 209.96, 0.926385);
INSERT INTO analytics.seed_inep_ideb VALUES (3300258, 2025, 'publica', 'anos_iniciais', 5.6, NULL, 223.77, 209.96, 0.926385);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2021, 'estadual', 'anos_finais', 5.0, 5.7, 247.8, 256.21, 0.984692);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2021, 'municipal', 'anos_finais', 4.8, 5.8, 246.24, 256.25, 0.953394);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2021, 'publica', 'anos_finais', 4.9, 5.7, 247.51, 256.22, 0.975308);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2021, 'estadual', 'anos_iniciais', NULL, 6.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2021, 'municipal', 'anos_iniciais', 5.5, 6.2, 207.55, 205.04, 0.980109);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2021, 'publica', 'anos_iniciais', 5.5, 6.2, 207.55, 205.04, 0.980109);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2023, 'estadual', 'anos_finais', 4.1, NULL, 240.83, 246.95, 0.860267);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2023, 'municipal', 'anos_finais', 4.2, NULL, 233.45, 246.91, 0.89171);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2023, 'publica', 'anos_finais', 4.1, NULL, 239.62, 246.94, 0.866096);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2023, 'municipal', 'anos_iniciais', 5.1, NULL, 211.14, 205.06, 0.892996);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2023, 'publica', 'anos_iniciais', 5.1, NULL, 211.14, 205.06, 0.892996);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2025, 'estadual', 'anos_finais', 4.6, NULL, 243.57, 250.0, 0.949722);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2025, 'municipal', 'anos_finais', 4.5, NULL, 241.85, 247.23, 0.942758);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2025, 'publica', 'anos_finais', 4.6, NULL, 243.18, 249.37, 0.949073);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2025, 'municipal', 'anos_iniciais', 5.5, NULL, 218.9, 213.86, 0.915062);
INSERT INTO analytics.seed_inep_ideb VALUES (3300308, 2025, 'publica', 'anos_iniciais', 5.5, NULL, 218.9, 213.86, 0.915062);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2021, 'estadual', 'anos_finais', 5.3, 5.6, 257.19, 261.65, 0.988988);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2021, 'municipal', 'anos_finais', 5.3, 6.0, 259.72, 264.04, 0.988989);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2021, 'publica', 'anos_finais', 5.3, 5.8, 259.04, 263.4, 0.98899);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2021, 'estadual', 'anos_iniciais', NULL, 6.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2021, 'municipal', 'anos_iniciais', 5.6, 6.6, 211.13, 201.26, 0.992792);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2021, 'publica', 'anos_iniciais', 5.6, 6.7, 211.13, 201.26, 0.992792);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2023, 'estadual', 'anos_finais', 4.7, NULL, 255.53, 261.11, 0.887209);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2023, 'municipal', 'anos_finais', 4.9, NULL, 261.48, 266.49, 0.894233);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2023, 'publica', 'anos_finais', 4.8, NULL, 259.48, 264.68, 0.891925);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2023, 'municipal', 'anos_iniciais', 5.9, NULL, 228.41, 220.71, 0.926391);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2023, 'publica', 'anos_iniciais', 5.9, NULL, 228.41, 220.71, 0.926391);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2025, 'estadual', 'anos_finais', 4.9, NULL, 250.05, 249.48, 0.973691);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2025, 'municipal', 'anos_finais', 4.6, NULL, 254.29, 257.38, 0.880345);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2025, 'publica', 'anos_finais', 4.7, NULL, 253.0, 254.98, 0.906164);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 233.98, 219.93, 0.933247);
INSERT INTO analytics.seed_inep_ideb VALUES (3300407, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 233.98, 219.93, 0.933247);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2021, 'estadual', 'anos_finais', 4.1, 5.3, 224.98, 229.85, 0.961371);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2021, 'municipal', 'anos_finais', 4.1, 4.7, 231.01, 238.06, 0.923088);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2021, 'publica', 'anos_finais', 4.1, 5.0, 226.88, 232.44, 0.945675);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2021, 'estadual', 'anos_iniciais', NULL, 5.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2021, 'municipal', 'anos_iniciais', 4.8, 5.7, 197.91, 187.7, 0.936859);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2021, 'publica', 'anos_iniciais', 4.8, 5.7, 197.91, 187.7, 0.936859);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2023, 'estadual', 'anos_finais', 3.6, NULL, 223.23, 229.49, 0.860706);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2023, 'municipal', 'anos_finais', 3.9, NULL, 232.67, 238.38, 0.871845);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2023, 'publica', 'anos_finais', 3.7, NULL, 225.67, 231.79, 0.860441);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2023, 'municipal', 'anos_iniciais', 4.8, NULL, 198.35, 191.13, 0.910666);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2023, 'publica', 'anos_iniciais', 4.8, NULL, 198.35, 191.13, 0.910666);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2025, 'estadual', 'anos_finais', 3.9, NULL, 223.02, 224.16, 0.946579);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2025, 'municipal', 'anos_finais', 4.0, NULL, 228.78, 235.39, 0.898957);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2025, 'publica', 'anos_finais', 3.9, NULL, 224.88, 227.79, 0.924405);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2025, 'municipal', 'anos_iniciais', 4.8, NULL, 194.53, 188.7, 0.931892);
INSERT INTO analytics.seed_inep_ideb VALUES (3300456, 2025, 'publica', 'anos_iniciais', 4.8, NULL, 194.53, 188.7, 0.93211);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2021, 'estadual', 'anos_finais', 5.4, 5.7, 265.96, 268.13, 0.968907);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2021, 'municipal', 'anos_finais', 4.2, 5.9, 273.81, 263.93, 0.741429);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2021, 'publica', 'anos_finais', 5.2, 5.7, 267.41, 267.35, 0.927324);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2021, 'estadual', 'anos_iniciais', NULL, 6.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2021, 'municipal', 'anos_iniciais', 5.2, 6.4, 221.4, 216.17, 0.854816);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2021, 'publica', 'anos_iniciais', 5.2, 6.2, 221.4, 216.17, 0.854816);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2023, 'estadual', 'anos_finais', 4.3, NULL, 253.16, 253.3, 0.844321);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, 0.812495);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2023, 'publica', 'anos_finais', 4.4, NULL, 256.77, 255.51, 0.836172);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2023, 'municipal', 'anos_iniciais', 5.7, NULL, 222.17, 217.35, 0.923836);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2023, 'publica', 'anos_iniciais', 5.7, NULL, 222.17, 217.35, 0.923836);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2025, 'estadual', 'anos_finais', 5.1, NULL, 254.05, 258.08, 0.978797);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2025, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, 0.816605);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2025, 'publica', 'anos_finais', 5.0, NULL, 256.02, 260.36, 0.94448);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 234.31, 219.43, 0.911152);
INSERT INTO analytics.seed_inep_ideb VALUES (3300506, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 234.31, 219.43, 0.911152);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2021, 'estadual', 'anos_finais', 5.1, 6.1, 253.11, 254.77, 0.998498);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2021, 'municipal', 'anos_finais', 4.5, 5.6, 236.69, 241.44, 0.98112);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2021, 'publica', 'anos_finais', 5.1, 6.0, 252.31, 254.12, 0.995495);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2021, 'estadual', 'anos_iniciais', NULL, 6.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2021, 'municipal', 'anos_iniciais', 5.4, 6.5, 207.77, 202.91, 0.95935);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2021, 'publica', 'anos_iniciais', 5.4, 6.4, 207.77, 202.91, 0.95935);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2023, 'estadual', 'anos_finais', 4.8, NULL, 254.86, 252.14, 0.941589);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, 0.93168);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2023, 'publica', 'anos_finais', 4.8, NULL, 254.77, 253.28, 0.939379);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2023, 'municipal', 'anos_iniciais', 6.4, NULL, 234.3, 220.31, 0.987974);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2023, 'publica', 'anos_iniciais', 6.4, NULL, 234.3, 220.31, 0.987974);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2025, 'estadual', 'anos_finais', 5.1, NULL, 254.73, 256.28, 0.990473);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2025, 'municipal', 'anos_finais', 4.9, NULL, 244.4, 252.82, 0.984767);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2025, 'publica', 'anos_finais', 5.1, NULL, 254.22, 256.11, 0.988476);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2025, 'municipal', 'anos_iniciais', 6.5, NULL, 238.28, 222.47, 0.99238);
INSERT INTO analytics.seed_inep_ideb VALUES (3300605, 2025, 'publica', 'anos_iniciais', 6.5, NULL, 238.28, 222.47, 0.99238);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2021, 'estadual', 'anos_finais', 4.7, 4.8, 249.95, 257.18, 0.913666);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2021, 'municipal', 'anos_finais', NULL, 5.8, NULL, NULL, 0.931633);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2021, 'publica', 'anos_finais', NULL, 5.5, NULL, NULL, 0.930038);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2021, 'estadual', 'anos_iniciais', NULL, 5.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2021, 'municipal', 'anos_iniciais', 5.4, 6.1, 207.36, 203.98, 0.950717);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2021, 'publica', 'anos_iniciais', 5.4, 6.0, 207.36, 203.98, 0.950717);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2023, 'estadual', 'anos_finais', 3.7, NULL, 233.1, 238.47, 0.807789);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2023, 'municipal', 'anos_finais', 3.8, NULL, 241.68, 246.61, 0.795366);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2023, 'publica', 'anos_finais', 3.8, NULL, 240.83, 245.81, 0.796955);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 214.86, 207.72, 0.855436);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 214.86, 207.72, 0.855436);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2025, 'estadual', 'anos_finais', 3.9, NULL, 228.95, 232.7, 0.892431);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2025, 'municipal', 'anos_finais', 4.0, NULL, 243.77, 250.79, 0.808229);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2025, 'publica', 'anos_finais', 4.0, NULL, 242.07, 248.71, 0.818666);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2025, 'municipal', 'anos_iniciais', 5.3, NULL, 219.59, 209.94, 0.888461);
INSERT INTO analytics.seed_inep_ideb VALUES (3300704, 2025, 'publica', 'anos_iniciais', 5.3, NULL, 219.59, 209.94, 0.888461);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2021, 'estadual', 'anos_finais', 4.9, 5.8, 246.22, 253.08, 0.983673);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2021, 'municipal', 'anos_finais', NULL, 5.8, NULL, NULL, 0.860619);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2021, 'publica', 'anos_finais', 4.8, 5.8, 248.95, 253.45, 0.947115);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2021, 'estadual', 'anos_iniciais', NULL, 6.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2021, 'municipal', 'anos_iniciais', 5.2, 6.1, 208.07, 199.49, 0.935073);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2021, 'publica', 'anos_iniciais', 5.2, 6.2, 208.07, 199.49, 0.935073);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2023, 'estadual', 'anos_finais', 3.9, NULL, 240.02, 244.52, 0.816372);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2023, 'municipal', 'anos_finais', 3.8, NULL, 237.96, 243.64, 0.800961);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2023, 'publica', 'anos_finais', 3.8, NULL, 239.69, 244.38, 0.807062);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2023, 'municipal', 'anos_iniciais', 4.7, NULL, 205.8, 199.62, 0.848845);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2023, 'publica', 'anos_iniciais', 4.7, NULL, 205.8, 199.62, 0.848845);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2025, 'estadual', 'anos_finais', 4.7, NULL, 242.13, 244.18, 0.976495);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2025, 'municipal', 'anos_finais', 4.1, NULL, 237.05, 245.93, 0.867085);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2025, 'publica', 'anos_finais', 4.4, NULL, 240.35, 244.79, 0.928476);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2025, 'municipal', 'anos_iniciais', 5.2, NULL, 213.99, 204.14, 0.901675);
INSERT INTO analytics.seed_inep_ideb VALUES (3300803, 2025, 'publica', 'anos_iniciais', 5.2, NULL, 213.99, 204.14, 0.901675);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2021, 'estadual', 'anos_finais', NULL, 6.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2021, 'municipal', 'anos_finais', 5.1, 5.6, 253.71, 254.31, 0.994721);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2021, 'publica', 'anos_finais', 5.1, 6.6, 253.71, 254.31, 0.989431);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2021, 'estadual', 'anos_iniciais', NULL, 6.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2021, 'municipal', 'anos_iniciais', 6.4, 6.4, 225.75, 224.43, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2021, 'publica', 'anos_iniciais', 6.4, 6.4, 225.75, 224.43, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2023, 'publica', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2023, 'municipal', 'anos_iniciais', 6.5, NULL, 237.01, 225.83, 0.978912);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2023, 'publica', 'anos_iniciais', 6.5, NULL, 237.01, 225.83, 0.978912);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2025, 'estadual', 'anos_finais', 6.0, NULL, 281.17, 280.99, 0.986743);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2025, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2025, 'publica', 'anos_finais', 6.0, NULL, 281.17, 280.99, 0.989425);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 221.57, 210.57, 0.995155);
INSERT INTO analytics.seed_inep_ideb VALUES (3300902, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 221.57, 210.57, 0.995155);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2021, 'estadual', 'anos_finais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2021, 'municipal', 'anos_finais', 4.8, 5.2, 241.11, 248.04, 0.99285);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2021, 'publica', 'anos_finais', 4.8, 5.6, 241.11, 248.04, 0.99285);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2021, 'municipal', 'anos_iniciais', 5.3, 5.6, 204.67, 195.18, 0.97737);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2021, 'publica', 'anos_iniciais', 5.3, 5.6, 204.67, 195.18, 0.97737);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2023, 'municipal', 'anos_finais', 4.6, NULL, 245.8, 253.92, 0.921657);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2023, 'publica', 'anos_finais', 4.6, NULL, 245.8, 253.92, 0.921657);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2023, 'municipal', 'anos_iniciais', 5.2, NULL, 214.18, 204.25, 0.910364);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2023, 'publica', 'anos_iniciais', 5.2, NULL, 214.18, 204.25, 0.910364);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2025, 'municipal', 'anos_finais', 4.5, NULL, 254.79, 252.26, 0.872059);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2025, 'publica', 'anos_finais', 4.5, NULL, 254.79, 252.26, 0.872059);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2025, 'municipal', 'anos_iniciais', 5.6, NULL, 216.96, 204.41, 0.955063);
INSERT INTO analytics.seed_inep_ideb VALUES (3300936, 2025, 'publica', 'anos_iniciais', 5.6, NULL, 216.96, 204.41, 0.955063);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2021, 'estadual', 'anos_finais', NULL, 5.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2021, 'municipal', 'anos_finais', 5.2, 5.8, 259.95, 250.47, 0.996207);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2021, 'publica', 'anos_finais', 5.2, 5.9, 259.95, 250.47, 0.996207);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2021, 'estadual', 'anos_iniciais', NULL, 5.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2021, 'municipal', 'anos_iniciais', 6.3, 6.2, 231.32, 217.52, 0.994379);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2021, 'publica', 'anos_iniciais', 6.3, 6.3, 231.32, 217.52, 0.994379);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2023, 'municipal', 'anos_finais', 5.8, NULL, 281.6, 280.18, 0.956978);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2023, 'publica', 'anos_finais', 5.8, NULL, 281.6, 280.18, 0.956978);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2023, 'municipal', 'anos_iniciais', 7.0, NULL, 258.19, 229.68, 0.993518);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2023, 'publica', 'anos_iniciais', 7.0, NULL, 258.19, 229.68, 0.993518);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2025, 'municipal', 'anos_finais', 5.7, NULL, 272.44, 271.8, 0.986055);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2025, 'publica', 'anos_finais', 5.7, NULL, 272.44, 271.8, 0.986055);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2025, 'municipal', 'anos_iniciais', 6.9, NULL, 251.34, 232.98, 0.98965);
INSERT INTO analytics.seed_inep_ideb VALUES (3300951, 2025, 'publica', 'anos_iniciais', 6.9, NULL, 251.34, 232.98, 0.98965);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2021, 'estadual', 'anos_finais', 4.5, 4.9, 240.08, 243.26, 0.948327);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2021, 'municipal', 'anos_finais', 4.0, 4.7, 231.39, 243.69, 0.87951);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2021, 'publica', 'anos_finais', 4.3, 4.9, 238.12, 243.35, 0.919221);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2021, 'estadual', 'anos_iniciais', NULL, 5.7, NULL, NULL, 0.812273);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2021, 'municipal', 'anos_iniciais', 4.7, 5.2, 194.86, 189.7, 0.913584);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2021, 'publica', 'anos_iniciais', 4.7, 5.4, 194.96, 189.77, 0.912172);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2023, 'estadual', 'anos_finais', 3.3, NULL, 223.94, 227.4, 0.787544);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2023, 'municipal', 'anos_finais', 4.2, NULL, 235.38, 247.72, 0.895918);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2023, 'publica', 'anos_finais', 3.6, NULL, 226.07, 231.19, 0.831065);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2023, 'estadual', 'anos_iniciais', 5.2, NULL, 202.81, 201.53, 0.946126);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2023, 'municipal', 'anos_iniciais', 5.4, NULL, 212.26, 204.76, 0.945834);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2023, 'publica', 'anos_iniciais', 5.4, NULL, 212.05, 204.69, 0.945834);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2025, 'estadual', 'anos_finais', 4.2, NULL, 233.57, 236.61, 0.928241);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2025, 'municipal', 'anos_finais', 4.2, NULL, 238.13, 242.74, 0.903861);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2025, 'publica', 'anos_finais', 4.2, NULL, 234.72, 238.16, 0.917819);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2025, 'estadual', 'anos_iniciais', 5.4, NULL, 213.79, 204.77, 0.931093);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2025, 'municipal', 'anos_iniciais', 5.7, NULL, 219.35, 207.89, 0.968737);
INSERT INTO analytics.seed_inep_ideb VALUES (3301009, 2025, 'publica', 'anos_iniciais', 5.7, NULL, 219.16, 207.78, 0.968113);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2021, 'estadual', 'anos_finais', 5.4, 5.6, 261.74, 264.67, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2021, 'municipal', 'anos_finais', 5.2, 6.0, 259.09, 263.28, 0.961377);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2021, 'publica', 'anos_finais', 5.3, 5.6, 260.36, 263.94, 0.975305);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2021, 'estadual', 'anos_iniciais', NULL, 6.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2021, 'municipal', 'anos_iniciais', 5.3, 5.6, 210.13, 198.05, 0.954222);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2021, 'publica', 'anos_iniciais', 5.3, 6.0, 210.13, 198.05, 0.954222);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2023, 'estadual', 'anos_finais', 4.6, NULL, 257.11, 256.95, 0.883596);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2023, 'municipal', 'anos_finais', 3.8, NULL, 235.81, 236.22, 0.841105);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2023, 'publica', 'anos_finais', 4.3, NULL, 248.91, 248.98, 0.861313);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2023, 'municipal', 'anos_iniciais', 5.4, NULL, 228.59, 220.8, 0.847777);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2023, 'publica', 'anos_iniciais', 5.4, NULL, 228.59, 220.8, 0.847777);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2025, 'estadual', 'anos_finais', 4.7, NULL, 245.45, 244.33, 0.978956);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2025, 'municipal', 'anos_finais', 4.4, NULL, 246.47, 244.36, 0.912058);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2025, 'publica', 'anos_finais', 4.6, NULL, 245.81, 244.34, 0.951166);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2025, 'municipal', 'anos_iniciais', 5.5, NULL, 219.96, 207.12, 0.929381);
INSERT INTO analytics.seed_inep_ideb VALUES (3301108, 2025, 'publica', 'anos_iniciais', 5.5, NULL, 219.96, 207.12, 0.929381);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2021, 'estadual', 'anos_finais', 5.9, 6.2, 273.37, 284.47, 0.985404);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2021, 'municipal', 'anos_finais', NULL, 6.0, NULL, NULL, 0.962722);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2021, 'publica', 'anos_finais', 5.7, 6.1, 274.53, 279.25, 0.971548);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2021, 'estadual', 'anos_iniciais', NULL, 5.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2021, 'municipal', 'anos_iniciais', 5.4, 5.7, 212.38, 208.24, 0.934743);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2021, 'publica', 'anos_iniciais', 5.4, 5.8, 212.38, 208.24, 0.934743);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2023, 'estadual', 'anos_finais', 5.4, NULL, 279.61, 274.41, 0.913682);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2023, 'municipal', 'anos_finais', 4.1, NULL, 245.63, 239.45, 0.873188);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2023, 'publica', 'anos_finais', 4.9, NULL, 268.01, 262.47, 0.884002);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2023, 'municipal', 'anos_iniciais', 4.9, NULL, 210.69, 199.05, 0.867349);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2023, 'publica', 'anos_iniciais', 4.9, NULL, 210.69, 199.05, 0.867349);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2025, 'estadual', 'anos_finais', 5.7, NULL, 271.39, 276.65, 0.990221);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2025, 'municipal', 'anos_finais', 5.9, NULL, 278.48, 277.1, 0.987644);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2025, 'publica', 'anos_finais', 5.8, NULL, 276.26, 276.96, 0.988372);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 231.17, 203.81, 0.994365);
INSERT INTO analytics.seed_inep_ideb VALUES (3301157, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 231.17, 203.81, 0.994365);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2021, 'estadual', 'anos_finais', 5.6, 5.7, 269.62, 269.45, 0.983974);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2021, 'municipal', 'anos_finais', 6.0, 6.2, 279.19, 280.37, 0.994408);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2021, 'publica', 'anos_finais', 5.7, 5.7, 272.05, 272.22, 0.986213);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2021, 'estadual', 'anos_iniciais', NULL, 6.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2021, 'municipal', 'anos_iniciais', 5.7, 5.9, 210.43, 208.34, 0.994992);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2021, 'publica', 'anos_iniciais', 5.7, 6.2, 210.43, 208.34, 0.994992);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2023, 'estadual', 'anos_finais', 5.0, NULL, 264.74, 266.62, 0.909057);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2023, 'municipal', 'anos_finais', 4.4, NULL, 272.76, 273.25, 0.770605);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2023, 'publica', 'anos_finais', 5.0, NULL, 266.06, 267.71, 0.892454);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2023, 'municipal', 'anos_iniciais', 5.1, NULL, 220.37, 210.08, 0.858133);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2023, 'publica', 'anos_iniciais', 5.1, NULL, 220.37, 210.08, 0.858133);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2025, 'estadual', 'anos_finais', 4.8, NULL, 247.07, 251.22, 0.968825);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2025, 'municipal', 'anos_finais', 5.0, NULL, 272.82, 253.55, 0.923325);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2025, 'publica', 'anos_finais', 4.9, NULL, 252.95, 251.76, 0.958554);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2025, 'municipal', 'anos_iniciais', 6.2, NULL, 244.88, 226.74, 0.918141);
INSERT INTO analytics.seed_inep_ideb VALUES (3301207, 2025, 'publica', 'anos_iniciais', 6.2, NULL, 244.88, 226.74, 0.918141);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2021, 'estadual', 'anos_finais', NULL, 5.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2021, 'municipal', 'anos_finais', 5.3, 5.4, 259.94, 260.35, 0.991479);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2021, 'publica', 'anos_finais', 5.3, 5.5, 259.94, 260.35, 0.991479);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2021, 'estadual', 'anos_iniciais', NULL, 6.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2021, 'municipal', 'anos_iniciais', 6.1, 6.4, 222.06, 215.01, 0.998599);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2021, 'publica', 'anos_iniciais', 6.1, 6.4, 222.06, 215.01, 0.998599);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2023, 'municipal', 'anos_finais', 4.8, NULL, 255.35, 258.03, 0.927257);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2023, 'publica', 'anos_finais', 4.8, NULL, 255.35, 258.03, 0.927257);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2023, 'municipal', 'anos_iniciais', 6.1, NULL, 226.15, 221.58, 0.960885);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2023, 'publica', 'anos_iniciais', 6.1, NULL, 226.15, 221.58, 0.960885);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2025, 'municipal', 'anos_finais', 4.8, NULL, 262.11, 266.38, 0.87931);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2025, 'publica', 'anos_finais', 4.8, NULL, 262.11, 266.38, 0.87931);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2025, 'municipal', 'anos_iniciais', 6.2, NULL, 230.55, 218.43, 0.978499);
INSERT INTO analytics.seed_inep_ideb VALUES (3301306, 2025, 'publica', 'anos_iniciais', 6.2, NULL, 230.55, 218.43, 0.978499);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2021, 'estadual', 'anos_finais', 4.7, 6.1, 237.02, 247.54, 0.982395);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2021, 'municipal', 'anos_finais', 4.2, 5.4, 238.91, 239.0, 0.897779);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2021, 'publica', 'anos_finais', 4.5, 5.9, 237.54, 245.2, 0.955504);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2021, 'estadual', 'anos_iniciais', NULL, 6.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2021, 'municipal', 'anos_iniciais', 5.6, 5.9, 206.87, 204.11, 0.998597);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2021, 'publica', 'anos_iniciais', 5.6, 6.0, 206.87, 204.11, 0.998597);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2023, 'estadual', 'anos_finais', 4.7, NULL, 243.43, 250.87, 0.950577);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2023, 'municipal', 'anos_finais', 4.0, NULL, 230.24, 239.84, 0.883609);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2023, 'publica', 'anos_finais', 4.4, NULL, 239.01, 247.17, 0.925874);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2023, 'municipal', 'anos_iniciais', 5.3, NULL, 210.75, 201.63, 0.931533);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2023, 'publica', 'anos_iniciais', 5.3, NULL, 210.75, 201.63, 0.931533);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2025, 'estadual', 'anos_finais', 4.3, NULL, 229.17, 237.19, 0.979152);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2025, 'municipal', 'anos_finais', 4.0, NULL, 228.51, 238.58, 0.89362);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2025, 'publica', 'anos_finais', 4.2, NULL, 228.94, 237.68, 0.946243);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2025, 'municipal', 'anos_iniciais', 5.3, NULL, 216.74, 204.83, 0.918453);
INSERT INTO analytics.seed_inep_ideb VALUES (3301405, 2025, 'publica', 'anos_iniciais', 5.3, NULL, 216.74, 204.83, 0.918453);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2021, 'estadual', 'anos_finais', 4.9, 5.8, 250.05, 245.83, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2021, 'municipal', 'anos_finais', 5.6, 5.7, 267.74, 271.05, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2021, 'publica', 'anos_finais', 5.3, 5.6, 258.56, 257.96, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2021, 'estadual', 'anos_iniciais', NULL, 6.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2021, 'municipal', 'anos_iniciais', 5.6, 6.3, 205.85, 205.41, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2021, 'publica', 'anos_iniciais', 5.6, 6.5, 205.85, 205.41, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2023, 'estadual', 'anos_finais', 4.8, NULL, 247.52, 259.67, 0.94293);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2023, 'municipal', 'anos_finais', 5.0, NULL, 252.2, 260.35, 0.963713);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2023, 'publica', 'anos_finais', 4.9, NULL, 249.91, 260.02, 0.953972);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2023, 'municipal', 'anos_iniciais', 5.8, NULL, 218.41, 212.39, 0.973843);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2023, 'publica', 'anos_iniciais', 5.8, NULL, 218.41, 212.39, 0.973843);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2025, 'estadual', 'anos_finais', 5.2, NULL, 256.42, 256.9, 0.997481);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2025, 'municipal', 'anos_finais', 5.6, NULL, 273.16, 270.64, 0.977227);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2025, 'publica', 'anos_finais', 5.4, NULL, 264.97, 263.92, 0.986368);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2025, 'municipal', 'anos_iniciais', 6.5, NULL, 237.77, 222.18, 0.989751);
INSERT INTO analytics.seed_inep_ideb VALUES (3301504, 2025, 'publica', 'anos_iniciais', 6.5, NULL, 237.77, 222.18, 0.989751);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2021, 'estadual', 'anos_finais', 5.4, 6.0, 263.6, 268.65, 0.983835);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2021, 'municipal', 'anos_finais', 5.1, 5.3, 265.45, 266.78, 0.916465);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2021, 'publica', 'anos_finais', 5.2, 5.9, 264.39, 267.86, 0.941721);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2021, 'estadual', 'anos_iniciais', NULL, 6.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2021, 'municipal', 'anos_iniciais', 5.5, 6.1, 207.62, 203.95, 0.977655);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2021, 'publica', 'anos_iniciais', 5.5, 6.2, 207.62, 203.95, 0.977655);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2023, 'estadual', 'anos_finais', 4.5, NULL, 244.61, 242.43, 0.947112);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2023, 'municipal', 'anos_finais', 4.2, NULL, 235.56, 249.37, 0.875122);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2023, 'publica', 'anos_finais', 4.3, NULL, 241.01, 245.19, 0.907934);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2023, 'municipal', 'anos_iniciais', 4.7, NULL, 210.19, 192.23, 0.866502);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2023, 'publica', 'anos_iniciais', 4.7, NULL, 210.19, 192.23, 0.866502);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2025, 'estadual', 'anos_finais', 5.2, NULL, 252.8, 262.09, 0.99389);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2025, 'municipal', 'anos_finais', 3.9, NULL, 232.54, 237.14, 0.866638);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2025, 'publica', 'anos_finais', 4.5, NULL, 243.37, 250.48, 0.928765);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2025, 'municipal', 'anos_iniciais', 5.5, NULL, 216.53, 210.49, 0.92181);
INSERT INTO analytics.seed_inep_ideb VALUES (3301603, 2025, 'publica', 'anos_iniciais', 5.5, NULL, 216.53, 210.49, 0.92181);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2021, 'estadual', 'anos_finais', 4.4, 5.0, 233.29, 239.12, 0.961423);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2021, 'municipal', 'anos_finais', 3.8, 4.6, 229.66, 235.06, 0.870473);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2021, 'publica', 'anos_finais', 4.1, 4.8, 232.0, 237.67, 0.922911);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2021, 'estadual', 'anos_iniciais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2021, 'municipal', 'anos_iniciais', 4.3, 5.6, 195.04, 187.52, 0.844139);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2021, 'publica', 'anos_iniciais', 4.3, 5.6, 195.04, 187.52, 0.844139);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2023, 'estadual', 'anos_finais', 3.7, NULL, 226.45, 231.93, 0.849503);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2023, 'municipal', 'anos_finais', 3.7, NULL, 228.69, 236.31, 0.838513);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2023, 'publica', 'anos_finais', 3.7, NULL, 227.13, 233.26, 0.842475);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2023, 'municipal', 'anos_iniciais', 4.5, NULL, 196.74, 190.69, 0.876521);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2023, 'publica', 'anos_iniciais', 4.5, NULL, 196.74, 190.69, 0.876521);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2025, 'estadual', 'anos_finais', 4.3, NULL, 232.27, 235.88, 0.958993);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2025, 'municipal', 'anos_finais', 4.0, NULL, 234.54, 240.99, 0.880041);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2025, 'publica', 'anos_finais', 4.2, NULL, 233.11, 237.76, 0.923937);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2025, 'municipal', 'anos_iniciais', 4.9, NULL, 203.58, 194.31, 0.915477);
INSERT INTO analytics.seed_inep_ideb VALUES (3301702, 2025, 'publica', 'anos_iniciais', 4.9, NULL, 203.58, 194.31, 0.915477);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2021, 'estadual', 'anos_finais', NULL, 6.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2021, 'municipal', 'anos_finais', 5.0, 5.7, 244.19, 253.49, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2021, 'publica', 'anos_finais', 5.0, 6.1, 244.19, 253.49, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2021, 'estadual', 'anos_iniciais', NULL, 6.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2021, 'municipal', 'anos_iniciais', 5.5, 6.4, 203.31, 198.59, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2021, 'publica', 'anos_iniciais', 5.5, 6.4, 203.31, 198.59, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2023, 'municipal', 'anos_finais', 4.7, NULL, 251.05, 251.12, 0.924957);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2023, 'publica', 'anos_finais', 4.7, NULL, 251.05, 251.12, 0.924957);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2023, 'municipal', 'anos_iniciais', 5.6, NULL, 218.64, 207.5, 0.946193);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2023, 'publica', 'anos_iniciais', 5.6, NULL, 218.64, 207.5, 0.946193);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2025, 'municipal', 'anos_finais', 4.9, NULL, 242.42, 257.67, 0.972969);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2025, 'publica', 'anos_finais', 4.9, NULL, 242.42, 257.67, 0.972969);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2025, 'municipal', 'anos_iniciais', 5.5, NULL, 214.95, 203.04, 0.958095);
INSERT INTO analytics.seed_inep_ideb VALUES (3301801, 2025, 'publica', 'anos_iniciais', 5.5, NULL, 214.95, 203.04, 0.958095);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2021, 'estadual', 'anos_finais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2021, 'municipal', 'anos_finais', 4.8, 5.0, 244.46, 249.87, 0.985236);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2021, 'publica', 'anos_finais', 4.8, 5.2, 244.46, 249.87, 0.985236);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2021, 'municipal', 'anos_iniciais', 5.4, 5.3, 202.1, 199.4, 0.991777);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2021, 'publica', 'anos_iniciais', 5.4, 5.3, 202.1, 199.4, 0.991777);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2023, 'municipal', 'anos_finais', 4.4, NULL, 246.03, 256.13, 0.870832);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2023, 'publica', 'anos_finais', 4.4, NULL, 246.03, 256.13, 0.870832);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2023, 'municipal', 'anos_iniciais', 5.1, NULL, 208.11, 202.47, 0.908376);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2023, 'publica', 'anos_iniciais', 5.1, NULL, 208.11, 202.47, 0.908376);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2025, 'municipal', 'anos_finais', 5.0, NULL, 253.45, 261.65, 0.950902);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2025, 'publica', 'anos_finais', 5.0, NULL, 253.45, 261.65, 0.950902);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2025, 'municipal', 'anos_iniciais', 5.7, NULL, 225.3, 213.01, 0.928365);
INSERT INTO analytics.seed_inep_ideb VALUES (3301850, 2025, 'publica', 'anos_iniciais', 5.7, NULL, 225.3, 213.01, 0.928365);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2021, 'estadual', 'anos_finais', NULL, 5.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2021, 'municipal', 'anos_finais', NULL, 5.5, NULL, NULL, 0.997748);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2021, 'publica', 'anos_finais', NULL, 5.4, NULL, NULL, 0.997748);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2021, 'estadual', 'anos_iniciais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2021, 'municipal', 'anos_iniciais', 5.8, 5.9, 209.83, 210.74, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2021, 'publica', 'anos_iniciais', 5.8, 5.7, 209.83, 210.74, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2023, 'municipal', 'anos_finais', 5.5, NULL, 274.64, 269.35, 0.961038);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2023, 'publica', 'anos_finais', 5.5, NULL, 274.64, 269.35, 0.961038);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2023, 'municipal', 'anos_iniciais', 6.5, NULL, 240.91, 227.03, 0.972038);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2023, 'publica', 'anos_iniciais', 6.5, NULL, 240.91, 227.03, 0.972038);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2025, 'municipal', 'anos_finais', 5.3, NULL, 276.55, 275.88, 0.907294);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2025, 'publica', 'anos_finais', 5.3, NULL, 276.55, 275.88, 0.907294);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2025, 'municipal', 'anos_iniciais', 6.8, NULL, 246.83, 233.47, 0.983738);
INSERT INTO analytics.seed_inep_ideb VALUES (3301876, 2025, 'publica', 'anos_iniciais', 6.8, NULL, 246.83, 233.47, 0.983738);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2021, 'estadual', 'anos_finais', 4.4, 5.0, 236.41, 236.75, 0.959599);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2021, 'municipal', 'anos_finais', 4.5, 5.6, 241.56, 245.84, 0.939202);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2021, 'publica', 'anos_finais', 4.5, 5.3, 240.6, 244.14, 0.941957);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2021, 'estadual', 'anos_iniciais', NULL, 5.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2021, 'municipal', 'anos_iniciais', 5.2, 5.8, 202.74, 200.41, 0.952934);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2021, 'publica', 'anos_iniciais', 5.2, 5.8, 202.74, 200.41, 0.952934);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2023, 'estadual', 'anos_finais', 3.5, NULL, 229.58, 240.48, 0.786798);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2023, 'municipal', 'anos_finais', 3.9, NULL, 233.86, 243.01, 0.836011);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2023, 'publica', 'anos_finais', 3.8, NULL, 232.93, 242.46, 0.825982);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 204.8, 201.77, 0.893381);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 204.8, 201.77, 0.893381);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2025, 'estadual', 'anos_finais', 4.0, NULL, 228.67, 239.07, 0.898317);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2025, 'municipal', 'anos_finais', 4.2, NULL, 239.38, 244.33, 0.88444);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2025, 'publica', 'anos_finais', 4.1, NULL, 237.63, 243.47, 0.885556);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2025, 'municipal', 'anos_iniciais', 5.2, NULL, 207.49, 203.54, 0.920459);
INSERT INTO analytics.seed_inep_ideb VALUES (3301900, 2025, 'publica', 'anos_iniciais', 5.2, NULL, 207.49, 203.54, 0.920459);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2021, 'estadual', 'anos_finais', NULL, 5.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2021, 'municipal', 'anos_finais', 4.6, 5.0, 237.25, 247.62, 0.973447);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2021, 'publica', 'anos_finais', 4.6, 5.0, 237.25, 247.62, 0.973693);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2021, 'estadual', 'anos_iniciais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2021, 'municipal', 'anos_iniciais', 5.2, 5.6, 196.6, 193.45, 0.985774);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2021, 'publica', 'anos_iniciais', 5.2, 5.6, 196.6, 193.45, 0.985774);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2023, 'municipal', 'anos_finais', 3.9, NULL, 233.77, 236.93, 0.863291);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2023, 'publica', 'anos_finais', 3.9, NULL, 233.77, 236.93, 0.863291);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2023, 'municipal', 'anos_iniciais', 4.6, NULL, 194.78, 185.34, 0.919917);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2023, 'publica', 'anos_iniciais', 4.6, NULL, 194.78, 185.34, 0.919917);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2025, 'municipal', 'anos_finais', 3.9, NULL, 233.08, 238.18, 0.862052);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2025, 'publica', 'anos_finais', 3.9, NULL, 233.08, 238.18, 0.862899);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2025, 'municipal', 'anos_iniciais', 5.1, NULL, 209.37, 200.21, 0.913599);
INSERT INTO analytics.seed_inep_ideb VALUES (3302007, 2025, 'publica', 'anos_iniciais', 5.1, NULL, 209.37, 200.21, 0.913599);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2021, 'estadual', 'anos_finais', 5.3, 6.8, 264.07, 265.61, 0.963357);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2021, 'municipal', 'anos_finais', 5.3, 5.3, 268.6, 277.29, 0.927916);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2021, 'publica', 'anos_finais', 5.2, 6.0, 265.75, 269.94, 0.937542);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2021, 'estadual', 'anos_iniciais', NULL, 6.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2021, 'municipal', 'anos_iniciais', 5.6, 6.8, 214.95, 211.36, 0.941118);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2021, 'publica', 'anos_iniciais', 5.6, 6.7, 214.95, 211.36, 0.941118);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2023, 'estadual', 'anos_finais', 5.7, NULL, 275.29, 279.07, 0.962482);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2023, 'municipal', 'anos_finais', 5.9, NULL, 282.57, 293.72, 0.943354);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2023, 'publica', 'anos_finais', 5.6, NULL, 276.7, 281.91, 0.945056);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2023, 'municipal', 'anos_iniciais', 6.2, NULL, 236.17, 220.26, 0.950283);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2023, 'publica', 'anos_iniciais', 6.2, NULL, 236.17, 220.26, 0.950283);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2025, 'estadual', 'anos_finais', 6.4, NULL, 288.95, 298.46, 0.992589);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2025, 'municipal', 'anos_finais', 6.0, NULL, 281.04, 283.63, 0.986571);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2025, 'publica', 'anos_finais', 6.2, NULL, 284.99, 291.05, 0.988361);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2025, 'municipal', 'anos_iniciais', 6.5, NULL, 239.98, 218.42, 0.99318);
INSERT INTO analytics.seed_inep_ideb VALUES (3302056, 2025, 'publica', 'anos_iniciais', 6.5, NULL, 239.98, 218.42, 0.99318);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2021, 'estadual', 'anos_finais', 5.8, 6.7, 271.37, 275.71, 0.994722);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2021, 'municipal', 'anos_finais', NULL, 5.5, NULL, NULL, 0.880696);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2021, 'publica', 'anos_finais', 5.6, 6.4, 269.41, 274.13, 0.977694);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2021, 'estadual', 'anos_iniciais', NULL, 7.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2021, 'municipal', 'anos_iniciais', 5.7, 5.8, 234.28, 219.96, 0.891298);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2021, 'publica', 'anos_iniciais', 5.7, 6.8, 234.28, 219.96, 0.891298);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2023, 'estadual', 'anos_finais', 5.9, NULL, 285.17, 284.21, 0.954487);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2023, 'publica', 'anos_finais', 5.8, NULL, 285.17, 284.21, 0.94757);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2023, 'municipal', 'anos_iniciais', 6.1, NULL, 250.0, 233.24, 0.86731);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2023, 'publica', 'anos_iniciais', 6.1, NULL, 250.0, 233.24, 0.86731);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2025, 'estadual', 'anos_finais', 6.2, NULL, 285.8, 285.79, 0.997242);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2025, 'municipal', 'anos_finais', 4.6, NULL, 251.69, 253.76, 0.896196);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2025, 'publica', 'anos_finais', 6.0, NULL, 283.82, 283.92, 0.985906);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2025, 'municipal', 'anos_iniciais', 6.8, NULL, 251.69, 233.98, 0.961455);
INSERT INTO analytics.seed_inep_ideb VALUES (3302106, 2025, 'publica', 'anos_iniciais', 6.8, NULL, 251.69, 233.98, 0.961455);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2021, 'estadual', 'anos_finais', 5.3, 5.8, 258.38, 258.8, 0.997747);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2021, 'municipal', 'anos_finais', 5.6, 6.4, 270.34, 272.98, 0.979935);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2021, 'publica', 'anos_finais', 5.5, 6.0, 264.89, 266.52, 0.986973);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2021, 'estadual', 'anos_iniciais', NULL, 6.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2021, 'municipal', 'anos_iniciais', 5.8, 6.7, 216.0, 214.12, 0.966432);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2021, 'publica', 'anos_iniciais', 5.8, 6.7, 216.0, 214.12, 0.966432);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2023, 'estadual', 'anos_finais', 5.0, NULL, 255.45, 263.58, 0.941387);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2023, 'municipal', 'anos_finais', 5.8, NULL, 277.92, 280.14, 0.964593);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2023, 'publica', 'anos_finais', 5.4, NULL, 266.74, 271.9, 0.954146);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2023, 'municipal', 'anos_iniciais', 6.7, NULL, 244.58, 234.85, 0.970173);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2023, 'publica', 'anos_iniciais', 6.7, NULL, 244.58, 234.85, 0.970173);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2025, 'estadual', 'anos_finais', 5.3, NULL, 257.9, 262.04, 0.987424);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2025, 'municipal', 'anos_finais', 6.3, NULL, 291.07, 291.14, 0.984193);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2025, 'publica', 'anos_finais', 5.8, NULL, 275.12, 277.14, 0.985465);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2025, 'municipal', 'anos_iniciais', 7.4, NULL, 262.65, 248.41, 0.98969);
INSERT INTO analytics.seed_inep_ideb VALUES (3302205, 2025, 'publica', 'anos_iniciais', 7.4, NULL, 262.65, 248.41, 0.98969);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2021, 'estadual', 'anos_finais', NULL, 5.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2021, 'municipal', 'anos_finais', 5.1, 4.9, 258.7, 264.27, 0.944572);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2021, 'publica', 'anos_finais', 5.1, 5.0, 258.7, 264.27, 0.944572);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2021, 'municipal', 'anos_iniciais', 6.0, 5.7, 222.42, 218.39, 0.977479);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2021, 'publica', 'anos_iniciais', 6.0, 5.7, 222.42, 218.39, 0.977479);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2023, 'municipal', 'anos_finais', 3.9, NULL, 242.53, 244.0, 0.821735);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2023, 'publica', 'anos_finais', 3.9, NULL, 242.53, 244.0, 0.821735);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2023, 'municipal', 'anos_iniciais', 5.2, NULL, 214.82, 205.82, 0.894698);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2023, 'publica', 'anos_iniciais', 5.2, NULL, 214.82, 205.82, 0.894698);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2025, 'municipal', 'anos_finais', 4.7, NULL, 255.97, 257.66, 0.907209);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2025, 'publica', 'anos_finais', 4.7, NULL, 255.97, 257.66, 0.907209);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2025, 'municipal', 'anos_iniciais', 5.2, NULL, 215.21, 200.18, 0.912924);
INSERT INTO analytics.seed_inep_ideb VALUES (3302254, 2025, 'publica', 'anos_iniciais', 5.2, NULL, 215.21, 200.18, 0.912924);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2021, 'estadual', 'anos_finais', NULL, 4.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2021, 'municipal', 'anos_finais', 4.1, 5.1, 226.49, 235.6, 0.938135);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2021, 'publica', 'anos_finais', 4.1, 5.0, 226.49, 235.6, 0.938135);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2021, 'estadual', 'anos_iniciais', NULL, 5.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2021, 'municipal', 'anos_iniciais', 4.5, 5.4, 183.1, 177.08, 0.964364);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2021, 'publica', 'anos_iniciais', 4.5, 5.4, 183.1, 177.08, 0.964364);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2023, 'municipal', 'anos_finais', 3.6, NULL, 219.46, 226.21, 0.876564);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2023, 'publica', 'anos_finais', 3.6, NULL, 219.46, 226.21, 0.876564);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2023, 'municipal', 'anos_iniciais', 4.3, NULL, 189.69, 182.69, 0.878667);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2023, 'publica', 'anos_iniciais', 4.3, NULL, 189.69, 182.69, 0.878667);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2025, 'municipal', 'anos_finais', 3.6, NULL, 220.1, 220.06, 0.894374);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2025, 'publica', 'anos_finais', 3.6, NULL, 220.1, 220.06, 0.901733);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2025, 'municipal', 'anos_iniciais', 4.7, NULL, 195.68, 188.82, 0.906463);
INSERT INTO analytics.seed_inep_ideb VALUES (3302270, 2025, 'publica', 'anos_iniciais', 4.7, NULL, 195.68, 188.82, 0.906463);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2021, 'estadual', 'anos_finais', 4.7, 5.7, 245.12, 243.31, 0.98593);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2021, 'municipal', 'anos_finais', 5.0, 6.2, 247.61, 251.44, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2021, 'publica', 'anos_finais', 4.9, 5.8, 246.38, 247.42, 0.993631);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2021, 'estadual', 'anos_iniciais', NULL, 6.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2021, 'municipal', 'anos_iniciais', 5.3, 6.3, 199.72, 192.03, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2021, 'publica', 'anos_iniciais', 5.3, 6.3, 199.72, 192.03, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2023, 'estadual', 'anos_finais', 5.4, NULL, 264.42, 266.57, 0.972774);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2023, 'municipal', 'anos_finais', 4.8, NULL, 233.61, 253.84, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2023, 'publica', 'anos_finais', 5.1, NULL, 249.44, 260.38, 0.986315);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2023, 'municipal', 'anos_iniciais', 6.2, NULL, 226.58, 216.31, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2023, 'publica', 'anos_iniciais', 6.2, NULL, 226.58, 216.31, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2025, 'estadual', 'anos_finais', 5.2, NULL, 266.47, 252.56, 0.977873);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2025, 'municipal', 'anos_finais', 5.0, NULL, 252.11, 245.28, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2025, 'publica', 'anos_finais', 5.1, NULL, 257.26, 247.89, 0.996207);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 225.5, 203.2, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302304, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 225.5, 203.2, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2021, 'estadual', 'anos_finais', NULL, 4.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2021, 'municipal', 'anos_finais', 5.2, 5.6, 258.19, 264.9, 0.957333);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2021, 'publica', 'anos_finais', 5.2, 5.4, 258.19, 264.9, 0.957333);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2021, 'estadual', 'anos_iniciais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2021, 'municipal', 'anos_iniciais', 5.9, 6.5, 220.86, 218.76, 0.962679);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2021, 'publica', 'anos_iniciais', 5.9, 6.4, 220.86, 218.76, 0.962679);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2023, 'municipal', 'anos_finais', 4.6, NULL, 256.41, 261.38, 0.874313);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2023, 'publica', 'anos_finais', 4.6, NULL, 256.41, 261.38, 0.874313);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2023, 'municipal', 'anos_iniciais', 5.8, NULL, 228.8, 217.35, 0.927023);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2023, 'publica', 'anos_iniciais', 5.8, NULL, 228.8, 217.35, 0.927023);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2025, 'municipal', 'anos_finais', 4.5, NULL, 247.45, 253.85, 0.891797);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2025, 'publica', 'anos_finais', 4.5, NULL, 247.45, 253.85, 0.891797);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 229.13, 220.69, 0.935046);
INSERT INTO analytics.seed_inep_ideb VALUES (3302403, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 229.13, 220.69, 0.935046);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2021, 'estadual', 'anos_finais', 4.8, 5.8, 244.44, 246.09, 0.987592);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2021, 'publica', 'anos_finais', 4.8, 5.8, 244.44, 246.09, 0.987592);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2021, 'estadual', 'anos_iniciais', NULL, 6.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2021, 'municipal', 'anos_iniciais', 5.7, 6.4, 219.86, 212.64, 0.951367);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2021, 'publica', 'anos_iniciais', 5.7, 6.4, 219.86, 212.64, 0.951367);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2023, 'estadual', 'anos_finais', 4.1, NULL, 247.53, 245.63, 0.841674);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2023, 'publica', 'anos_finais', 4.1, NULL, 247.53, 245.63, 0.841674);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2023, 'municipal', 'anos_iniciais', 5.3, NULL, 222.12, 206.81, 0.890084);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2023, 'publica', 'anos_iniciais', 5.3, NULL, 222.12, 206.81, 0.890084);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2025, 'estadual', 'anos_finais', 5.0, NULL, 257.54, 248.95, 0.974215);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2025, 'publica', 'anos_finais', 5.0, NULL, 257.54, 248.95, 0.974215);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2025, 'municipal', 'anos_iniciais', 6.4, NULL, 241.26, 223.94, 0.966636);
INSERT INTO analytics.seed_inep_ideb VALUES (3302452, 2025, 'publica', 'anos_iniciais', 6.4, NULL, 241.26, 223.94, 0.966636);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2021, 'estadual', 'anos_finais', 4.9, 5.3, 243.92, 249.05, 0.997988);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2021, 'municipal', 'anos_finais', 4.4, 5.0, 233.19, 239.7, 0.972226);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2021, 'publica', 'anos_finais', 4.4, 5.2, 233.59, 240.05, 0.972726);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2021, 'estadual', 'anos_iniciais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2021, 'municipal', 'anos_iniciais', 5.2, 5.5, 201.71, 194.72, 0.962372);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2021, 'publica', 'anos_iniciais', 5.2, 5.6, 201.71, 194.72, 0.962372);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2023, 'estadual', 'anos_finais', 4.6, NULL, 242.75, 252.52, 0.943751);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2023, 'municipal', 'anos_finais', 4.1, NULL, 235.16, 244.22, 0.889366);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2023, 'publica', 'anos_finais', 4.2, NULL, 235.42, 244.51, 0.890665);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2023, 'municipal', 'anos_iniciais', 4.8, NULL, 202.42, 193.78, 0.90257);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2023, 'publica', 'anos_iniciais', 4.8, NULL, 202.42, 193.78, 0.90257);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2025, 'estadual', 'anos_finais', 5.1, NULL, 254.67, 258.92, 0.98033);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2025, 'municipal', 'anos_finais', 4.2, NULL, 235.49, 241.31, 0.908108);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2025, 'publica', 'anos_finais', 4.2, NULL, 236.19, 241.95, 0.909905);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2025, 'municipal', 'anos_iniciais', 5.0, NULL, 207.2, 199.68, 0.905724);
INSERT INTO analytics.seed_inep_ideb VALUES (3302502, 2025, 'publica', 'anos_iniciais', 5.0, NULL, 207.2, 199.68, 0.905724);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2021, 'estadual', 'anos_finais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2021, 'municipal', 'anos_finais', 4.9, 5.7, 246.75, 253.75, 0.971466);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2021, 'publica', 'anos_finais', 4.9, 5.6, 246.75, 253.75, 0.971466);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2021, 'estadual', 'anos_iniciais', NULL, 6.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2021, 'municipal', 'anos_iniciais', 5.4, 6.3, 205.02, 198.73, 0.991788);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2021, 'publica', 'anos_iniciais', 5.4, 6.3, 205.02, 198.73, 0.991788);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2023, 'municipal', 'anos_finais', 3.9, NULL, 240.67, 251.92, 0.806316);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2023, 'publica', 'anos_finais', 3.9, NULL, 240.67, 251.92, 0.806316);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 201.93, 194.98, 0.938372);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 201.93, 194.98, 0.938372);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2025, 'municipal', 'anos_finais', 4.7, NULL, 257.11, 261.56, 0.880492);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2025, 'publica', 'anos_finais', 4.7, NULL, 257.11, 261.56, 0.880492);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2025, 'municipal', 'anos_iniciais', 5.3, NULL, 216.35, 200.57, 0.928264);
INSERT INTO analytics.seed_inep_ideb VALUES (3302601, 2025, 'publica', 'anos_iniciais', 5.3, NULL, 216.35, 200.57, 0.928264);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2021, 'estadual', 'anos_finais', NULL, 5.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2021, 'municipal', 'anos_finais', 5.4, 6.1, 257.85, 263.48, 0.999249);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2021, 'publica', 'anos_finais', 5.4, 5.7, 257.85, 263.48, 0.999249);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2021, 'estadual', 'anos_iniciais', NULL, 6.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2021, 'municipal', 'anos_iniciais', 5.6, 6.1, 208.82, 201.31, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2021, 'publica', 'anos_iniciais', 5.6, 6.1, 208.82, 201.31, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2023, 'municipal', 'anos_finais', 4.6, NULL, 245.34, 249.69, 0.932852);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2023, 'publica', 'anos_finais', 4.6, NULL, 245.34, 249.69, 0.932852);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2023, 'municipal', 'anos_iniciais', 5.7, NULL, 215.38, 203.76, 0.978334);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2023, 'publica', 'anos_iniciais', 5.7, NULL, 215.38, 203.76, 0.978334);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2025, 'municipal', 'anos_finais', 5.0, NULL, 253.22, 257.8, 0.971856);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2025, 'publica', 'anos_finais', 5.0, NULL, 253.22, 257.8, 0.969107);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2025, 'municipal', 'anos_iniciais', 6.4, NULL, 235.24, 220.41, 0.994584);
INSERT INTO analytics.seed_inep_ideb VALUES (3302700, 2025, 'publica', 'anos_iniciais', 6.4, NULL, 235.24, 220.41, 0.994584);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2021, 'estadual', 'anos_finais', 5.0, 5.7, 254.11, 250.81, 0.985874);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2021, 'municipal', 'anos_finais', 5.3, 5.2, 251.6, 267.48, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2021, 'publica', 'anos_finais', 5.2, 5.7, 252.74, 259.9, 0.993725);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2021, 'estadual', 'anos_iniciais', NULL, 7.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2021, 'municipal', 'anos_iniciais', 5.6, 6.7, 207.65, 204.44, 0.998996);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2021, 'publica', 'anos_iniciais', 5.6, 6.9, 207.65, 204.44, 0.998996);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2023, 'estadual', 'anos_finais', 3.8, NULL, 251.16, 244.43, 0.768328);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2023, 'municipal', 'anos_finais', 4.1, NULL, 246.79, 245.03, 0.840965);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2023, 'publica', 'anos_finais', 4.0, NULL, 249.35, 244.68, 0.80943);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2023, 'municipal', 'anos_iniciais', 5.8, NULL, 215.8, 212.1, 0.983411);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2023, 'publica', 'anos_iniciais', 5.8, NULL, 215.8, 212.1, 0.983411);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2025, 'estadual', 'anos_finais', 4.6, NULL, 242.21, 247.12, 0.958155);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2025, 'municipal', 'anos_finais', 4.4, NULL, 249.52, 242.27, 0.906443);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2025, 'publica', 'anos_finais', 4.5, NULL, 244.06, 245.89, 0.937174);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2025, 'municipal', 'anos_iniciais', 6.1, NULL, 226.1, 215.74, 0.981518);
INSERT INTO analytics.seed_inep_ideb VALUES (3302809, 2025, 'publica', 'anos_iniciais', 6.1, NULL, 226.1, 215.74, 0.981518);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2021, 'estadual', 'anos_finais', 4.1, 4.9, 228.48, 234.1, 0.929948);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2021, 'municipal', 'anos_finais', 4.3, 5.4, 231.46, 238.46, 0.962936);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2021, 'publica', 'anos_finais', 4.2, 5.0, 229.83, 236.08, 0.946693);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2021, 'estadual', 'anos_iniciais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2021, 'municipal', 'anos_iniciais', 5.2, 5.9, 199.28, 195.29, 0.97478);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2021, 'publica', 'anos_iniciais', 5.2, 5.8, 199.28, 195.29, 0.97478);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2023, 'estadual', 'anos_finais', 3.5, NULL, 221.68, 227.17, 0.832945);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2023, 'municipal', 'anos_finais', 3.9, NULL, 228.12, 235.51, 0.890441);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2023, 'publica', 'anos_finais', 3.7, NULL, 224.44, 230.74, 0.861988);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2023, 'municipal', 'anos_iniciais', 4.9, NULL, 203.3, 195.52, 0.904348);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2023, 'publica', 'anos_iniciais', 4.9, NULL, 203.3, 195.52, 0.904348);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2025, 'estadual', 'anos_finais', 3.8, NULL, 223.94, 227.9, 0.90778);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2025, 'municipal', 'anos_finais', 4.3, NULL, 234.12, 240.76, 0.929111);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2025, 'publica', 'anos_finais', 4.0, NULL, 228.99, 234.28, 0.918886);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2025, 'municipal', 'anos_iniciais', 5.5, NULL, 213.53, 204.08, 0.956301);
INSERT INTO analytics.seed_inep_ideb VALUES (3302858, 2025, 'publica', 'anos_iniciais', 5.5, NULL, 213.53, 204.08, 0.956301);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2021, 'estadual', 'anos_finais', 5.1, 5.8, 247.02, 256.78, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2021, 'municipal', 'anos_finais', 5.8, 6.8, 278.07, 280.86, 0.96864);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2021, 'publica', 'anos_finais', 5.7, 6.1, 273.26, 277.13, 0.973739);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2021, 'estadual', 'anos_iniciais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2021, 'municipal', 'anos_iniciais', 6.0, 6.8, 233.59, 222.27, 0.929358);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2021, 'publica', 'anos_iniciais', 6.0, 6.8, 233.59, 222.27, 0.929358);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2023, 'estadual', 'anos_finais', 3.4, NULL, 217.17, 215.07, 0.876962);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2023, 'municipal', 'anos_finais', 5.1, NULL, 273.72, 275.64, 0.874917);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2023, 'publica', 'anos_finais', 4.8, NULL, 265.12, 266.43, 0.876217);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2023, 'municipal', 'anos_iniciais', 5.6, NULL, 218.08, 213.64, 0.936648);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2023, 'publica', 'anos_iniciais', 5.6, NULL, 218.08, 213.64, 0.936648);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2025, 'estadual', 'anos_finais', 4.6, NULL, 240.03, 235.36, 0.99311);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2025, 'municipal', 'anos_finais', 5.3, NULL, 270.31, 273.72, 0.920472);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2025, 'publica', 'anos_finais', 5.2, NULL, 266.13, 268.43, 0.930503);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2025, 'municipal', 'anos_iniciais', 6.2, NULL, 231.79, 220.37, 0.964569);
INSERT INTO analytics.seed_inep_ideb VALUES (3302908, 2025, 'publica', 'anos_iniciais', 6.2, NULL, 231.79, 220.37, 0.964569);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2021, 'estadual', 'anos_finais', 4.7, 6.0, 238.78, 243.91, 0.995695);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2021, 'municipal', 'anos_finais', 6.4, 5.9, 291.41, 295.42, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2021, 'publica', 'anos_finais', 6.0, 6.0, 277.31, 281.62, 0.998997);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2021, 'estadual', 'anos_iniciais', NULL, 6.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2021, 'municipal', 'anos_iniciais', 7.2, 6.8, 255.59, 239.52, 0.997588);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2021, 'publica', 'anos_iniciais', 7.2, 6.7, 255.59, 239.52, 0.997588);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2023, 'estadual', 'anos_finais', 4.5, NULL, 251.95, 242.76, 0.915521);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2023, 'municipal', 'anos_finais', 6.5, NULL, 302.86, 295.89, 0.973683);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2023, 'publica', 'anos_finais', 5.5, NULL, 276.71, 268.6, 0.953377);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2023, 'municipal', 'anos_iniciais', 7.9, NULL, 279.42, 256.47, 0.998187);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2023, 'publica', 'anos_iniciais', 7.9, NULL, 279.42, 256.47, 0.998187);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2025, 'estadual', 'anos_finais', 5.6, NULL, 267.7, 266.84, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2025, 'municipal', 'anos_finais', 5.5, NULL, 276.54, 276.9, 0.93842);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2025, 'publica', 'anos_finais', 5.5, NULL, 274.46, 274.54, 0.953288);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2025, 'municipal', 'anos_iniciais', 7.2, NULL, 256.79, 240.3, 0.989575);
INSERT INTO analytics.seed_inep_ideb VALUES (3303005, 2025, 'publica', 'anos_iniciais', 7.2, NULL, 256.79, 240.3, 0.989575);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2021, 'estadual', 'anos_finais', 4.5, 6.5, 234.58, 236.7, 0.997227);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2021, 'municipal', 'anos_finais', NULL, 5.2, NULL, NULL, 0.966804);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2021, 'publica', 'anos_finais', 4.4, 6.5, 232.95, 235.35, 0.988389);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2021, 'estadual', 'anos_iniciais', NULL, 6.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2021, 'municipal', 'anos_iniciais', 5.2, 5.7, 202.85, 186.66, 0.99294);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2021, 'publica', 'anos_iniciais', 5.2, 7.0, 202.85, 186.66, 0.99294);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2023, 'estadual', 'anos_finais', 4.8, NULL, 251.42, 250.39, 0.947807);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2023, 'municipal', 'anos_finais', 5.0, NULL, 256.33, 247.09, 0.980081);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2023, 'publica', 'anos_finais', 4.8, NULL, 252.38, 249.75, 0.956374);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2023, 'municipal', 'anos_iniciais', 5.7, NULL, 213.46, 204.69, 0.984724);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2023, 'publica', 'anos_iniciais', 5.7, NULL, 213.46, 204.69, 0.984724);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2025, 'estadual', 'anos_finais', 4.8, NULL, 245.85, 243.74, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2025, 'municipal', 'anos_finais', 5.2, NULL, 260.13, 257.7, 0.988625);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2025, 'publica', 'anos_finais', 4.9, NULL, 249.15, 246.97, 0.996718);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 224.82, 207.18, 0.994983);
INSERT INTO analytics.seed_inep_ideb VALUES (3303104, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 224.82, 207.18, 0.994983);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2021, 'estadual', 'anos_finais', 4.3, 4.8, 229.95, 235.68, 0.970373);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2021, 'municipal', 'anos_finais', 4.6, 4.7, 232.6, 241.34, 0.999249);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2021, 'publica', 'anos_finais', 4.4, 4.7, 231.28, 238.51, 0.987726);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2021, 'estadual', 'anos_iniciais', NULL, 5.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2021, 'municipal', 'anos_iniciais', 5.2, 5.3, 196.95, 191.21, 0.998193);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2021, 'publica', 'anos_iniciais', 5.2, 5.5, 196.95, 191.21, 0.998193);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2023, 'estadual', 'anos_finais', 3.5, NULL, 219.27, 226.1, 0.843777);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2023, 'municipal', 'anos_finais', 4.4, NULL, 233.75, 243.84, 0.945989);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2023, 'publica', 'anos_finais', 3.9, NULL, 226.99, 235.56, 0.900613);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2023, 'municipal', 'anos_iniciais', 5.6, NULL, 212.36, 205.79, 0.970473);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2023, 'publica', 'anos_iniciais', 5.6, NULL, 212.36, 205.79, 0.970473);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2025, 'estadual', 'anos_finais', 4.0, NULL, 225.56, 232.16, 0.935685);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2025, 'municipal', 'anos_finais', 4.5, NULL, 231.92, 241.59, 0.990216);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2025, 'publica', 'anos_finais', 4.2, NULL, 228.26, 236.16, 0.961734);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 218.08, 211.1, 0.981338);
INSERT INTO analytics.seed_inep_ideb VALUES (3303203, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 218.08, 211.1, 0.981338);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2021, 'estadual', 'anos_finais', 4.5, 5.3, 241.6, 247.74, 0.939426);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2021, 'municipal', 'anos_finais', 5.0, 5.8, 250.75, 256.91, 0.972737);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2021, 'publica', 'anos_finais', 4.7, 5.4, 244.68, 251.0, 0.951856);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2021, 'estadual', 'anos_iniciais', NULL, 6.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2021, 'municipal', 'anos_iniciais', 5.6, 6.1, 208.23, 206.17, 0.987797);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2021, 'publica', 'anos_iniciais', 5.6, 6.1, 208.25, 206.29, 0.987597);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2023, 'estadual', 'anos_finais', 3.6, NULL, 232.25, 237.87, 0.805723);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2023, 'municipal', 'anos_finais', 3.9, NULL, 232.46, 236.74, 0.860241);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2023, 'publica', 'anos_finais', 3.7, NULL, 232.76, 237.95, 0.826439);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 202.86, 196.55, 0.927841);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 203.15, 196.86, 0.928249);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2025, 'estadual', 'anos_finais', 4.2, NULL, 236.65, 242.86, 0.894443);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2025, 'municipal', 'anos_finais', 4.3, NULL, 241.55, 247.85, 0.887692);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2025, 'publica', 'anos_finais', 4.2, NULL, 238.31, 244.33, 0.891301);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2025, 'municipal', 'anos_iniciais', 5.5, NULL, 214.85, 205.68, 0.949101);
INSERT INTO analytics.seed_inep_ideb VALUES (3303302, 2025, 'publica', 'anos_iniciais', 5.5, NULL, 215.12, 205.91, 0.949487);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2021, 'estadual', 'anos_finais', 5.3, 5.8, 264.34, 265.85, 0.971471);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2021, 'municipal', 'anos_finais', 5.0, 6.1, 265.85, 274.36, 0.876776);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2021, 'publica', 'anos_finais', 5.2, 5.9, 264.7, 267.9, 0.939455);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2021, 'estadual', 'anos_iniciais', NULL, 6.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2021, 'municipal', 'anos_iniciais', 5.2, 6.7, 221.71, 218.03, 0.839137);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2021, 'publica', 'anos_iniciais', 5.2, 6.7, 221.71, 218.03, 0.839381);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2023, 'estadual', 'anos_finais', 4.5, NULL, 257.02, 261.75, 0.839634);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2023, 'municipal', 'anos_finais', 4.6, NULL, 257.86, 266.83, 0.852753);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2023, 'publica', 'anos_finais', 4.5, NULL, 257.16, 262.59, 0.841801);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2023, 'municipal', 'anos_iniciais', 6.0, NULL, 239.04, 230.76, 0.899122);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2023, 'publica', 'anos_iniciais', 6.0, NULL, 239.04, 230.76, 0.89933);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2025, 'estadual', 'anos_finais', 5.0, NULL, 256.54, 259.84, 0.940364);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2025, 'municipal', 'anos_finais', 5.4, NULL, 271.48, 281.04, 0.921873);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2025, 'publica', 'anos_finais', 5.0, NULL, 259.31, 263.77, 0.93334);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2025, 'municipal', 'anos_iniciais', 6.6, NULL, 251.42, 239.7, 0.933927);
INSERT INTO analytics.seed_inep_ideb VALUES (3303401, 2025, 'publica', 'anos_iniciais', 6.6, NULL, 251.42, 239.7, 0.933927);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2021, 'estadual', 'anos_finais', 4.3, 5.1, 229.9, 233.3, 0.96994);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2021, 'municipal', 'anos_finais', 4.6, 5.5, 235.71, 246.03, 0.975986);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2021, 'publica', 'anos_finais', 4.4, 5.2, 232.17, 238.29, 0.971986);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2021, 'estadual', 'anos_iniciais', NULL, 5.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2021, 'municipal', 'anos_iniciais', 4.7, 5.8, 188.25, 180.11, 0.979993);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2021, 'publica', 'anos_iniciais', 4.7, 5.8, 188.25, 180.11, 0.979993);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2023, 'estadual', 'anos_finais', 3.7, NULL, 224.12, 228.19, 0.888128);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2023, 'municipal', 'anos_finais', 4.1, NULL, 237.47, 245.88, 0.868768);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2023, 'publica', 'anos_finais', 3.8, NULL, 228.44, 233.91, 0.879217);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2023, 'municipal', 'anos_iniciais', 4.6, NULL, 193.92, 187.19, 0.905114);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2023, 'publica', 'anos_iniciais', 4.6, NULL, 193.92, 187.19, 0.905114);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2025, 'estadual', 'anos_finais', 4.0, NULL, 223.17, 226.63, 0.954455);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2025, 'municipal', 'anos_finais', 4.1, NULL, 231.83, 237.84, 0.912099);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2025, 'publica', 'anos_finais', 4.0, NULL, 226.19, 230.55, 0.935665);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2025, 'municipal', 'anos_iniciais', 5.0, NULL, 202.57, 192.8, 0.940539);
INSERT INTO analytics.seed_inep_ideb VALUES (3303500, 2025, 'publica', 'anos_iniciais', 5.0, NULL, 202.57, 192.8, 0.940539);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2021, 'estadual', 'anos_finais', NULL, 5.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2021, 'municipal', 'anos_finais', 4.8, 5.5, 250.43, 258.32, 0.941015);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2021, 'publica', 'anos_finais', 4.9, 5.4, 250.43, 258.32, 0.943273);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2021, 'estadual', 'anos_iniciais', NULL, 5.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2021, 'municipal', 'anos_iniciais', 5.2, 5.7, 221.26, 213.19, 0.858168);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2021, 'publica', 'anos_iniciais', 5.2, 5.6, 221.26, 213.19, 0.858168);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2023, 'estadual', 'anos_finais', 3.9, NULL, 233.4, 239.63, 0.851996);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2023, 'municipal', 'anos_finais', 5.1, NULL, 256.0, 266.13, 0.941927);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2023, 'publica', 'anos_finais', 4.9, NULL, 252.19, 261.67, 0.930088);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2023, 'municipal', 'anos_iniciais', 5.7, NULL, 229.21, 219.23, 0.904654);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2023, 'publica', 'anos_iniciais', 5.7, NULL, 229.21, 219.23, 0.904654);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2025, 'estadual', 'anos_finais', 4.9, NULL, 252.1, 252.62, 0.96204);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2025, 'municipal', 'anos_finais', 5.0, NULL, 255.13, 254.45, 0.961919);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2025, 'publica', 'anos_finais', 5.0, NULL, 254.81, 254.26, 0.961757);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 229.58, 219.52, 0.934311);
INSERT INTO analytics.seed_inep_ideb VALUES (3303609, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 229.58, 219.52, 0.934311);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2021, 'estadual', 'anos_finais', 4.5, 5.8, 238.26, 233.56, 0.994722);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2021, 'municipal', 'anos_finais', 4.9, 5.8, 244.43, 251.81, 0.995978);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2021, 'publica', 'anos_finais', 4.7, 5.8, 241.79, 244.01, 0.994993);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2021, 'estadual', 'anos_iniciais', NULL, 6.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2021, 'municipal', 'anos_iniciais', 5.2, 6.1, 197.63, 193.34, 0.995981);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2021, 'publica', 'anos_iniciais', 5.2, 6.2, 197.63, 193.34, 0.995981);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2023, 'estadual', 'anos_finais', 4.4, NULL, 249.54, 251.25, 0.868699);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2023, 'municipal', 'anos_finais', 4.5, NULL, 247.71, 253.99, 0.88925);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2023, 'publica', 'anos_finais', 4.4, NULL, 248.45, 252.89, 0.881543);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2023, 'municipal', 'anos_iniciais', 5.4, NULL, 207.72, 201.64, 0.960112);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2023, 'publica', 'anos_iniciais', 5.4, NULL, 207.72, 201.64, 0.960112);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2025, 'estadual', 'anos_finais', 4.1, NULL, 225.88, 229.85, 0.968028);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2025, 'municipal', 'anos_finais', 4.5, NULL, 248.08, 251.03, 0.90486);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2025, 'publica', 'anos_finais', 4.3, NULL, 239.2, 242.56, 0.923156);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2025, 'municipal', 'anos_iniciais', 5.6, NULL, 220.06, 212.4, 0.933015);
INSERT INTO analytics.seed_inep_ideb VALUES (3303708, 2025, 'publica', 'anos_iniciais', 5.6, NULL, 220.06, 212.4, 0.933015);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2021, 'estadual', 'anos_finais', 5.1, 5.9, 257.06, 263.39, 0.957574);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2021, 'municipal', 'anos_finais', NULL, 6.0, NULL, NULL, 0.83832);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2021, 'publica', 'anos_finais', 4.5, 5.9, 248.24, 257.05, 0.884136);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2021, 'estadual', 'anos_iniciais', NULL, 6.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2021, 'municipal', 'anos_iniciais', NULL, 6.0, NULL, NULL, 0.939083);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2021, 'publica', 'anos_iniciais', NULL, 6.3, NULL, NULL, 0.939083);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2023, 'estadual', 'anos_finais', 4.3, NULL, 248.6, 257.42, 0.835259);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, 0.811036);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2023, 'publica', 'anos_finais', 4.1, NULL, 244.6, 252.67, 0.817563);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 203.63, 198.84, 0.915496);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 203.63, 198.84, 0.915496);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2025, 'estadual', 'anos_finais', 4.8, NULL, 250.91, 259.93, 0.928615);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2025, 'municipal', 'anos_finais', 4.5, NULL, 237.53, 250.97, 0.931548);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2025, 'publica', 'anos_finais', 4.7, NULL, 244.57, 255.68, 0.931301);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 224.67, 210.61, 0.975804);
INSERT INTO analytics.seed_inep_ideb VALUES (3303807, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 224.67, 210.61, 0.975804);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2021, 'estadual', 'anos_finais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2021, 'municipal', 'anos_finais', 5.1, 6.1, 256.04, 261.8, 0.957395);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2021, 'publica', 'anos_finais', 5.1, 5.4, 256.04, 261.8, 0.957395);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2021, 'estadual', 'anos_iniciais', NULL, 6.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2021, 'municipal', 'anos_iniciais', 5.6, 5.2, 216.76, 210.58, 0.938919);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2021, 'publica', 'anos_iniciais', 5.6, 5.2, 216.76, 210.58, 0.938919);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2023, 'municipal', 'anos_finais', 5.2, NULL, 272.49, 269.08, 0.9221);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2023, 'publica', 'anos_finais', 5.2, NULL, 272.49, 269.08, 0.9221);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2023, 'municipal', 'anos_iniciais', 6.0, NULL, 235.32, 220.62, 0.931745);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2023, 'publica', 'anos_iniciais', 6.0, NULL, 235.32, 220.62, 0.931745);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2025, 'municipal', 'anos_finais', 5.3, NULL, 260.78, 263.22, 0.979556);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2025, 'publica', 'anos_finais', 5.3, NULL, 260.78, 263.22, 0.979556);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2025, 'municipal', 'anos_iniciais', 6.3, NULL, 236.34, 225.09, 0.956971);
INSERT INTO analytics.seed_inep_ideb VALUES (3303856, 2025, 'publica', 'anos_iniciais', 6.3, NULL, 236.34, 225.09, 0.956971);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2021, 'estadual', 'anos_finais', NULL, 5.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2021, 'municipal', 'anos_finais', 4.6, 5.5, 255.84, 259.5, 0.872933);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2021, 'publica', 'anos_finais', 4.6, 5.5, 255.84, 259.5, 0.872933);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2021, 'estadual', 'anos_iniciais', NULL, 6.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2021, 'municipal', 'anos_iniciais', 5.2, 6.2, 211.21, 207.86, 0.90809);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2021, 'publica', 'anos_iniciais', 5.2, 6.2, 211.21, 207.86, 0.90809);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2023, 'municipal', 'anos_finais', 4.8, NULL, 251.36, 261.6, 0.916508);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2023, 'publica', 'anos_finais', 4.8, NULL, 251.36, 261.6, 0.916508);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2023, 'municipal', 'anos_iniciais', 5.7, NULL, 219.37, 210.6, 0.959835);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2023, 'publica', 'anos_iniciais', 5.7, NULL, 219.37, 210.6, 0.959835);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2025, 'municipal', 'anos_finais', 4.6, NULL, 251.22, 258.86, 0.897691);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2025, 'publica', 'anos_finais', 4.6, NULL, 251.22, 258.86, 0.897958);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2025, 'municipal', 'anos_iniciais', 5.6, NULL, 217.75, 209.95, 0.94989);
INSERT INTO analytics.seed_inep_ideb VALUES (3303906, 2025, 'publica', 'anos_iniciais', 5.6, NULL, 217.75, 209.95, 0.94989);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2021, 'estadual', 'anos_finais', NULL, 4.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2021, 'municipal', 'anos_finais', 4.4, 5.5, 251.13, 256.43, 0.850555);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2021, 'publica', 'anos_finais', 4.4, 5.0, 251.13, 256.43, 0.850555);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2021, 'municipal', 'anos_iniciais', 5.5, 6.1, 207.7, 208.34, 0.958278);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2021, 'publica', 'anos_iniciais', 5.5, 6.1, 207.7, 208.34, 0.958278);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2023, 'municipal', 'anos_finais', 3.8, NULL, 245.82, 249.04, 0.777994);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2023, 'publica', 'anos_finais', 3.8, NULL, 245.82, 249.04, 0.777994);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2023, 'municipal', 'anos_iniciais', 5.4, NULL, 223.76, 212.72, 0.877589);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2023, 'publica', 'anos_iniciais', 5.4, NULL, 223.76, 212.72, 0.877589);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2025, 'municipal', 'anos_finais', 4.0, NULL, 252.62, 255.13, 0.772205);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2025, 'publica', 'anos_finais', 4.0, NULL, 252.62, 255.13, 0.772205);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2025, 'municipal', 'anos_iniciais', 5.7, NULL, 224.06, 214.63, 0.927947);
INSERT INTO analytics.seed_inep_ideb VALUES (3303955, 2025, 'publica', 'anos_iniciais', 5.7, NULL, 224.06, 214.63, 0.927947);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2021, 'estadual', 'anos_finais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2021, 'municipal', 'anos_finais', 5.5, 6.0, 262.41, 266.21, 0.997988);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2021, 'publica', 'anos_finais', 5.5, 5.9, 262.41, 266.21, 0.997988);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2021, 'estadual', 'anos_iniciais', NULL, 5.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2021, 'municipal', 'anos_iniciais', 5.7, 6.3, 209.48, 205.54, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2021, 'publica', 'anos_iniciais', 5.7, 6.3, 209.48, 205.54, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2023, 'municipal', 'anos_finais', 4.9, NULL, 258.62, 260.17, 0.914731);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2023, 'publica', 'anos_finais', 4.9, NULL, 258.62, 260.17, 0.914731);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2023, 'municipal', 'anos_iniciais', 5.6, NULL, 216.6, 209.53, 0.949745);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2023, 'publica', 'anos_iniciais', 5.6, NULL, 216.6, 209.53, 0.949745);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2025, 'municipal', 'anos_finais', 5.1, NULL, 256.44, 263.89, 0.950624);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2025, 'publica', 'anos_finais', 5.1, NULL, 256.44, 263.89, 0.950624);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2025, 'municipal', 'anos_iniciais', 5.8, NULL, 220.56, 213.73, 0.960522);
INSERT INTO analytics.seed_inep_ideb VALUES (3304003, 2025, 'publica', 'anos_iniciais', 5.8, NULL, 220.56, 213.73, 0.960522);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2021, 'estadual', 'anos_finais', 4.5, 6.2, 238.82, 236.5, 0.986158);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2021, 'municipal', 'anos_finais', 5.3, 6.4, 262.25, 269.2, 0.963339);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2021, 'publica', 'anos_finais', 4.9, 6.2, 250.54, 252.85, 0.97423);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2021, 'estadual', 'anos_iniciais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2021, 'municipal', 'anos_iniciais', 5.2, 6.4, 210.79, 198.28, 0.92546);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2021, 'publica', 'anos_iniciais', 5.2, 6.4, 210.79, 198.28, 0.92546);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2023, 'estadual', 'anos_finais', 3.8, NULL, 230.54, 223.91, 0.892216);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2023, 'municipal', 'anos_finais', 4.9, NULL, 246.82, 248.5, 0.99285);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2023, 'publica', 'anos_finais', 4.3, NULL, 237.96, 235.13, 0.939102);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2023, 'municipal', 'anos_iniciais', 4.5, NULL, 190.18, 175.6, 0.942453);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2023, 'publica', 'anos_iniciais', 4.5, NULL, 190.18, 175.6, 0.942453);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2025, 'estadual', 'anos_finais', 4.9, NULL, 249.8, 248.39, 0.992179);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2025, 'municipal', 'anos_finais', 5.3, NULL, 259.98, 261.34, 0.991902);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2025, 'publica', 'anos_finais', 5.1, NULL, 254.22, 254.01, 0.991977);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 218.39, 210.91, 0.984589);
INSERT INTO analytics.seed_inep_ideb VALUES (3304102, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 218.39, 210.91, 0.984589);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2021, 'estadual', 'anos_finais', NULL, 5.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2021, 'municipal', 'anos_finais', 5.5, 5.1, 264.83, 269.45, 0.991727);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2021, 'publica', 'anos_finais', 5.5, 5.6, 264.83, 269.45, 0.991727);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2021, 'estadual', 'anos_iniciais', NULL, 6.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2021, 'municipal', 'anos_iniciais', 5.4, 5.9, 204.43, 194.91, 0.997387);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2021, 'publica', 'anos_iniciais', 5.4, 6.0, 204.43, 194.91, 0.997387);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2023, 'municipal', 'anos_finais', 4.9, NULL, 255.22, 250.8, 0.951587);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2023, 'publica', 'anos_finais', 4.9, NULL, 255.22, 250.8, 0.951587);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2023, 'municipal', 'anos_iniciais', 6.3, NULL, 232.51, 219.24, 0.982042);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2023, 'publica', 'anos_iniciais', 6.3, NULL, 232.51, 219.24, 0.982042);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2025, 'municipal', 'anos_finais', 5.3, NULL, 263.9, 262.71, 0.977631);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2025, 'publica', 'anos_finais', 5.3, NULL, 263.9, 262.71, 0.977631);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2025, 'municipal', 'anos_iniciais', 6.9, NULL, 250.19, 230.31, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304110, 2025, 'publica', 'anos_iniciais', 6.9, NULL, 250.19, 230.31, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2021, 'estadual', 'anos_finais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2021, 'municipal', 'anos_finais', 5.3, 5.5, 255.7, 263.38, 0.996991);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2021, 'publica', 'anos_finais', 5.3, 5.7, 255.7, 263.38, 0.996991);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2021, 'municipal', 'anos_iniciais', 5.6, 6.2, 207.65, 201.91, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2021, 'publica', 'anos_iniciais', 5.6, 6.2, 207.65, 201.91, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2023, 'municipal', 'anos_finais', 4.8, NULL, 252.07, 256.03, 0.935328);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2023, 'publica', 'anos_finais', 4.8, NULL, 252.07, 256.03, 0.935328);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2023, 'municipal', 'anos_iniciais', 5.6, NULL, 217.42, 202.58, 0.961407);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2023, 'publica', 'anos_iniciais', 5.6, NULL, 217.42, 202.58, 0.961407);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2025, 'municipal', 'anos_finais', 5.1, NULL, 260.15, 254.1, 0.978341);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2025, 'publica', 'anos_finais', 5.1, NULL, 260.15, 254.1, 0.978341);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 228.5, 210.73, 0.980474);
INSERT INTO analytics.seed_inep_ideb VALUES (3304128, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 228.5, 210.73, 0.980474);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2021, 'estadual', 'anos_finais', 4.2, 5.0, 226.6, 232.37, 0.97841);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2021, 'municipal', 'anos_finais', 4.6, 5.3, 238.41, 246.65, 0.974698);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2021, 'publica', 'anos_finais', 4.4, 5.0, 231.51, 238.31, 0.976216);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2021, 'estadual', 'anos_iniciais', NULL, 5.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2021, 'municipal', 'anos_iniciais', 4.7, 5.9, 185.56, 177.35, 0.989175);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2021, 'publica', 'anos_iniciais', 4.7, 5.8, 185.56, 177.35, 0.989175);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2023, 'estadual', 'anos_finais', 3.8, NULL, 223.17, 229.57, 0.901069);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2023, 'municipal', 'anos_finais', 3.9, NULL, 235.5, 239.01, 0.854624);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2023, 'publica', 'anos_finais', 3.8, NULL, 228.4, 233.57, 0.880485);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2023, 'municipal', 'anos_iniciais', 4.9, NULL, 200.58, 192.73, 0.931158);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2023, 'publica', 'anos_iniciais', 4.9, NULL, 200.58, 192.73, 0.931158);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2025, 'estadual', 'anos_finais', 3.8, NULL, 220.58, 221.51, 0.952056);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2025, 'municipal', 'anos_finais', 4.1, NULL, 227.13, 234.23, 0.930546);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2025, 'publica', 'anos_finais', 3.9, NULL, 223.44, 227.07, 0.941986);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2025, 'municipal', 'anos_iniciais', 5.1, NULL, 198.06, 191.75, 0.969099);
INSERT INTO analytics.seed_inep_ideb VALUES (3304144, 2025, 'publica', 'anos_iniciais', 5.1, NULL, 198.06, 191.75, 0.969099);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2021, 'estadual', 'anos_finais', NULL, 5.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2021, 'municipal', 'anos_finais', 5.2, 5.5, 258.91, 265.62, 0.965332);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2021, 'publica', 'anos_finais', 5.2, 5.4, 258.91, 265.62, 0.965332);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2021, 'municipal', 'anos_iniciais', 5.2, 5.5, 215.53, 204.67, 0.901676);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2021, 'publica', 'anos_iniciais', 5.2, 5.5, 215.53, 204.67, 0.901676);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2023, 'municipal', 'anos_finais', 4.8, NULL, 250.91, 253.63, 0.941968);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2023, 'publica', 'anos_finais', 4.8, NULL, 250.91, 253.63, 0.941968);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2023, 'municipal', 'anos_iniciais', 6.0, NULL, 226.85, 213.91, 0.965353);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2023, 'publica', 'anos_iniciais', 6.0, NULL, 226.85, 213.91, 0.965353);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2025, 'municipal', 'anos_finais', 5.0, NULL, 258.55, 259.55, 0.951563);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2025, 'publica', 'anos_finais', 5.0, NULL, 258.55, 259.55, 0.951563);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2025, 'municipal', 'anos_iniciais', 6.4, NULL, 236.39, 223.64, 0.980695);
INSERT INTO analytics.seed_inep_ideb VALUES (3304151, 2025, 'publica', 'anos_iniciais', 6.4, NULL, 236.39, 223.64, 0.980695);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2021, 'estadual', 'anos_finais', 4.9, 6.1, 249.11, 251.74, 0.967739);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2021, 'municipal', 'anos_finais', 5.1, 5.4, 262.44, 265.18, 0.935842);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2021, 'publica', 'anos_finais', 5.0, 5.8, 257.38, 260.08, 0.947267);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2021, 'estadual', 'anos_iniciais', NULL, 6.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2021, 'municipal', 'anos_iniciais', 5.6, 6.1, 221.16, 211.72, 0.924866);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2021, 'publica', 'anos_iniciais', 5.6, 6.3, 221.16, 211.72, 0.924866);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2023, 'estadual', 'anos_finais', 4.1, NULL, 251.45, 251.75, 0.807178);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2023, 'municipal', 'anos_finais', 5.1, NULL, 258.23, 261.08, 0.949469);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2023, 'publica', 'anos_finais', 4.7, NULL, 255.42, 257.21, 0.8936);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2023, 'municipal', 'anos_iniciais', 6.1, NULL, 230.18, 219.17, 0.967749);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2023, 'publica', 'anos_iniciais', 6.1, NULL, 230.18, 219.17, 0.967749);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2025, 'estadual', 'anos_finais', 4.5, NULL, 241.29, 242.4, 0.95379);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2025, 'municipal', 'anos_finais', 5.1, NULL, 256.89, 259.22, 0.962725);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2025, 'publica', 'anos_finais', 4.9, NULL, 251.04, 252.91, 0.959178);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2025, 'municipal', 'anos_iniciais', 6.3, NULL, 232.77, 219.39, 0.990778);
INSERT INTO analytics.seed_inep_ideb VALUES (3304201, 2025, 'publica', 'anos_iniciais', 6.3, NULL, 232.77, 219.39, 0.990778);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2021, 'estadual', 'anos_finais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2021, 'municipal', 'anos_finais', 4.7, 5.4, 252.5, 256.32, 0.905017);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2021, 'publica', 'anos_finais', 4.7, 5.4, 252.5, 256.32, 0.905017);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2021, 'estadual', 'anos_iniciais', NULL, 6.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2021, 'municipal', 'anos_iniciais', 5.5, 5.8, 213.92, 208.67, 0.942407);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2021, 'publica', 'anos_iniciais', 5.5, 6.0, 213.92, 208.67, 0.942407);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2023, 'municipal', 'anos_finais', 4.3, NULL, 240.78, 251.29, 0.883761);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2023, 'publica', 'anos_finais', 4.3, NULL, 240.78, 251.29, 0.883761);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2023, 'municipal', 'anos_iniciais', 5.3, NULL, 213.09, 206.38, 0.915876);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2023, 'publica', 'anos_iniciais', 5.3, NULL, 213.09, 206.38, 0.915876);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2025, 'municipal', 'anos_finais', 4.2, NULL, 234.82, 237.35, 0.926866);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2025, 'publica', 'anos_finais', 4.2, NULL, 234.82, 237.35, 0.926866);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2025, 'municipal', 'anos_iniciais', 5.3, NULL, 211.4, 201.09, 0.931201);
INSERT INTO analytics.seed_inep_ideb VALUES (3304300, 2025, 'publica', 'anos_iniciais', 5.3, NULL, 211.4, 201.09, 0.931201);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2021, 'estadual', 'anos_finais', 5.6, 5.8, 268.89, 271.18, 0.992443);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2021, 'municipal', 'anos_finais', 5.6, 5.3, 266.93, 277.82, 0.967867);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2021, 'publica', 'anos_finais', 5.6, 5.7, 267.96, 274.32, 0.973681);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2021, 'estadual', 'anos_iniciais', NULL, 6.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2021, 'municipal', 'anos_iniciais', 5.5, 6.3, 205.45, 205.43, 0.984781);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2021, 'publica', 'anos_iniciais', 5.5, 6.4, 205.45, 205.43, 0.984781);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2023, 'municipal', 'anos_finais', 4.8, NULL, 249.85, 254.25, 0.938085);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2023, 'publica', 'anos_finais', 4.8, NULL, 249.85, 254.25, 0.938085);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2023, 'municipal', 'anos_iniciais', 5.6, NULL, 212.64, 206.45, 0.964134);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2023, 'publica', 'anos_iniciais', 5.6, NULL, 212.64, 206.45, 0.964134);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2025, 'municipal', 'anos_finais', 4.3, NULL, 243.55, 245.51, 0.90206);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2025, 'publica', 'anos_finais', 4.3, NULL, 243.55, 245.51, 0.90206);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2025, 'municipal', 'anos_iniciais', 5.7, NULL, 221.81, 206.45, 0.959597);
INSERT INTO analytics.seed_inep_ideb VALUES (3304409, 2025, 'publica', 'anos_iniciais', 5.7, NULL, 221.81, 206.45, 0.959597);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2021, 'estadual', 'anos_finais', NULL, 6.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2021, 'municipal', 'anos_finais', 5.3, 5.8, 259.87, 262.17, 0.996718);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2021, 'publica', 'anos_finais', 5.3, 6.0, 259.87, 262.17, 0.996718);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2021, 'estadual', 'anos_iniciais', NULL, 6.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2021, 'municipal', 'anos_iniciais', 5.8, 5.7, 214.04, 209.53, 0.99839);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2021, 'publica', 'anos_iniciais', 5.8, 6.1, 214.04, 209.53, 0.99839);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2023, 'municipal', 'anos_finais', 5.1, NULL, 258.61, 256.98, 0.96442);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2023, 'publica', 'anos_finais', 5.1, NULL, 258.61, 256.98, 0.96442);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2023, 'municipal', 'anos_iniciais', 6.2, NULL, 236.93, 221.42, 0.945196);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2023, 'publica', 'anos_iniciais', 6.2, NULL, 236.93, 221.42, 0.945196);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2025, 'municipal', 'anos_finais', 5.7, NULL, 275.34, 273.71, 0.984095);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2025, 'publica', 'anos_finais', 5.7, NULL, 275.34, 273.71, 0.984095);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2025, 'municipal', 'anos_iniciais', 6.8, NULL, 248.83, 230.07, 0.990165);
INSERT INTO analytics.seed_inep_ideb VALUES (3304508, 2025, 'publica', 'anos_iniciais', 6.8, NULL, 248.83, 230.07, 0.990165);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2021, 'estadual', 'anos_finais', NULL, 5.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2021, 'municipal', 'anos_finais', 5.5, 5.9, 261.51, 267.73, 0.995748);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2021, 'publica', 'anos_finais', 5.5, 5.7, 261.51, 267.73, 0.995748);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2021, 'estadual', 'anos_iniciais', NULL, 6.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2021, 'municipal', 'anos_iniciais', 6.2, 6.3, 223.2, 222.8, 0.995999);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2021, 'publica', 'anos_iniciais', 6.2, 6.3, 223.2, 222.8, 0.995999);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2023, 'municipal', 'anos_finais', 4.9, NULL, 261.72, 270.05, 0.88591);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2023, 'publica', 'anos_finais', 4.9, NULL, 261.72, 270.05, 0.88591);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2023, 'municipal', 'anos_iniciais', 6.1, NULL, 232.8, 225.0, 0.941158);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2023, 'publica', 'anos_iniciais', 6.1, NULL, 232.8, 225.0, 0.941158);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2025, 'municipal', 'anos_finais', 4.7, NULL, 255.84, 259.53, 0.895358);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2025, 'publica', 'anos_finais', 4.7, NULL, 255.84, 259.53, 0.895358);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2025, 'municipal', 'anos_iniciais', 6.2, NULL, 233.76, 222.86, 0.954857);
INSERT INTO analytics.seed_inep_ideb VALUES (3304524, 2025, 'publica', 'anos_iniciais', 6.2, NULL, 233.76, 222.86, 0.954857);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2021, 'estadual', 'anos_finais', 5.4, 4.9, 263.62, 269.99, 0.963883);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2021, 'municipal', 'anos_finais', 5.0, 5.7, 251.15, 255.64, 0.984487);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2021, 'publica', 'anos_finais', 5.1, 5.6, 253.73, 257.62, 0.983987);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2021, 'estadual', 'anos_iniciais', NULL, 6.1, NULL, NULL, 0.965973);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2021, 'municipal', 'anos_iniciais', 5.4, 6.4, 206.32, 193.52, 0.987798);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2021, 'publica', 'anos_iniciais', 5.4, 6.4, 207.19, 194.51, 0.987598);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2023, 'estadual', 'anos_finais', 5.7, NULL, 286.59, 283.8, 0.927971);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2023, 'municipal', 'anos_finais', 5.2, NULL, 258.42, 262.82, 0.968443);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2023, 'publica', 'anos_finais', 5.2, NULL, 260.59, 264.45, 0.96746);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2023, 'estadual', 'anos_iniciais', 6.0, NULL, 223.61, 216.0, 0.979575);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2023, 'municipal', 'anos_iniciais', 6.0, NULL, 223.61, 209.99, 0.984849);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2023, 'publica', 'anos_iniciais', 6.0, NULL, 224.02, 210.41, 0.984654);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2025, 'estadual', 'anos_finais', 5.7, NULL, 278.93, 275.45, 0.960419);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2025, 'municipal', 'anos_finais', 5.2, NULL, 256.88, 258.09, 0.985719);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2025, 'publica', 'anos_finais', 5.2, NULL, 258.43, 259.27, 0.984221);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2025, 'estadual', 'anos_iniciais', 6.1, NULL, 234.38, 211.87, 0.971787);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2025, 'municipal', 'anos_iniciais', 6.2, NULL, 229.7, 213.78, 0.995187);
INSERT INTO analytics.seed_inep_ideb VALUES (3304557, 2025, 'publica', 'anos_iniciais', 6.2, NULL, 230.06, 214.16, 0.994586);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2021, 'municipal', 'anos_finais', 5.0, 6.6, 260.95, 262.86, 0.924753);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2021, 'publica', 'anos_finais', 5.0, 6.6, 260.95, 262.86, 0.924753);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2021, 'municipal', 'anos_iniciais', 4.6, 6.9, 206.77, 215.22, 0.784639);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2021, 'publica', 'anos_iniciais', 4.6, 6.9, 206.77, 215.22, 0.784639);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2023, 'municipal', 'anos_finais', 5.0, NULL, 269.39, 271.33, 0.872373);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2023, 'publica', 'anos_finais', 5.0, NULL, 269.39, 271.33, 0.872373);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2023, 'municipal', 'anos_iniciais', 5.5, NULL, 233.15, 222.41, 0.844411);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2023, 'publica', 'anos_iniciais', 5.5, NULL, 233.15, 222.41, 0.844411);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2025, 'municipal', 'anos_finais', 5.1, NULL, 272.9, 273.29, 0.876733);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2025, 'publica', 'anos_finais', 5.1, NULL, 272.9, 273.29, 0.876733);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2025, 'municipal', 'anos_iniciais', 5.7, NULL, 240.91, 225.78, 0.850006);
INSERT INTO analytics.seed_inep_ideb VALUES (3304607, 2025, 'publica', 'anos_iniciais', 5.7, NULL, 240.91, 225.78, 0.850006);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2021, 'estadual', 'anos_finais', NULL, 6.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2021, 'municipal', 'anos_finais', 5.4, 6.0, 264.03, 261.26, 0.997497);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2021, 'publica', 'anos_finais', 5.4, 6.1, 264.03, 261.26, 0.997747);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2021, 'estadual', 'anos_iniciais', NULL, 7.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2021, 'municipal', 'anos_iniciais', 6.2, 6.6, 223.46, 216.34, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2021, 'publica', 'anos_iniciais', 6.2, 6.7, 223.46, 216.34, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2023, 'estadual', 'anos_finais', 6.0, NULL, 273.58, 286.85, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2023, 'municipal', 'anos_finais', 5.0, NULL, 260.32, 262.03, 0.926134);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2023, 'publica', 'anos_finais', 5.1, NULL, 261.26, 263.8, 0.932512);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2023, 'municipal', 'anos_iniciais', 5.9, NULL, 228.78, 216.52, 0.943135);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2023, 'publica', 'anos_iniciais', 5.9, NULL, 228.78, 216.52, 0.943135);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2025, 'estadual', 'anos_finais', 6.2, NULL, 294.74, 278.47, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2025, 'municipal', 'anos_finais', 5.6, NULL, 273.19, 273.75, 0.961282);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2025, 'publica', 'anos_finais', 5.6, NULL, 275.02, 274.15, 0.965832);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2025, 'municipal', 'anos_iniciais', 6.6, NULL, 242.85, 223.39, 0.985631);
INSERT INTO analytics.seed_inep_ideb VALUES (3304706, 2025, 'publica', 'anos_iniciais', 6.6, NULL, 242.85, 223.39, 0.985631);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2021, 'estadual', 'anos_finais', NULL, 4.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2021, 'municipal', 'anos_finais', 4.7, 5.4, 246.76, 244.82, 0.961103);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2021, 'publica', 'anos_finais', 4.7, 4.9, 246.76, 244.82, 0.961103);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2021, 'estadual', 'anos_iniciais', NULL, 5.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2021, 'municipal', 'anos_iniciais', 5.4, 5.8, 208.85, 199.08, 0.973532);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2021, 'publica', 'anos_iniciais', 5.4, 5.8, 208.85, 199.08, 0.973532);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2023, 'municipal', 'anos_finais', 4.1, NULL, 240.66, 242.04, 0.869016);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2023, 'publica', 'anos_finais', 4.1, NULL, 240.66, 242.04, 0.869016);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2023, 'municipal', 'anos_iniciais', 4.8, NULL, 208.83, 199.81, 0.856512);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2023, 'publica', 'anos_iniciais', 4.8, NULL, 208.83, 199.81, 0.856512);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2025, 'municipal', 'anos_finais', 4.2, NULL, 241.48, 239.52, 0.886257);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2025, 'publica', 'anos_finais', 4.2, NULL, 241.48, 239.52, 0.88727);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2025, 'municipal', 'anos_iniciais', 5.2, NULL, 218.82, 200.89, 0.906009);
INSERT INTO analytics.seed_inep_ideb VALUES (3304755, 2025, 'publica', 'anos_iniciais', 5.2, NULL, 218.82, 200.89, 0.906009);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2021, 'estadual', 'anos_finais', 5.1, 6.7, 254.05, 262.17, 0.971934);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2021, 'municipal', 'anos_finais', 5.2, 6.3, 263.86, 265.85, 0.945174);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2021, 'publica', 'anos_finais', 5.1, 6.6, 257.1, 263.31, 0.951873);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2021, 'estadual', 'anos_iniciais', NULL, 6.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2021, 'municipal', 'anos_iniciais', 5.2, 6.0, 207.37, 198.42, 0.94083);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2021, 'publica', 'anos_iniciais', 5.2, 6.4, 207.37, 198.42, 0.94083);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2023, 'estadual', 'anos_finais', 4.6, NULL, 244.34, 251.98, 0.921375);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2023, 'municipal', 'anos_finais', 4.2, NULL, 251.88, 246.47, 0.836048);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2023, 'publica', 'anos_finais', 4.2, NULL, 246.41, 250.47, 0.853683);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 216.1, 204.29, 0.863978);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 216.1, 204.29, 0.863978);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2025, 'estadual', 'anos_finais', 4.5, NULL, 236.14, 243.44, 0.973457);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2025, 'municipal', 'anos_finais', 4.8, NULL, 270.5, 251.68, 0.894591);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2025, 'publica', 'anos_finais', 4.4, NULL, 247.45, 246.15, 0.900877);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2025, 'municipal', 'anos_iniciais', 5.2, NULL, 213.51, 202.02, 0.915365);
INSERT INTO analytics.seed_inep_ideb VALUES (3304805, 2025, 'publica', 'anos_iniciais', 5.2, NULL, 213.51, 202.02, 0.915365);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2021, 'estadual', 'anos_finais', 4.5, 5.1, 238.45, 245.3, 0.949953);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2021, 'municipal', 'anos_finais', 4.2, 5.0, 243.12, 250.74, 0.864667);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2021, 'publica', 'anos_finais', 4.4, 5.1, 239.24, 246.23, 0.925386);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2021, 'estadual', 'anos_iniciais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2021, 'municipal', 'anos_iniciais', 5.2, 6.0, 202.35, 202.15, 0.936543);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2021, 'publica', 'anos_iniciais', 5.2, 6.0, 202.35, 202.15, 0.936543);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2023, 'estadual', 'anos_finais', 3.4, NULL, 225.66, 233.11, 0.793229);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2023, 'municipal', 'anos_finais', 3.9, NULL, 242.78, 248.07, 0.798837);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2023, 'publica', 'anos_finais', 3.5, NULL, 228.09, 235.23, 0.792123);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2023, 'municipal', 'anos_iniciais', 4.5, NULL, 198.32, 194.83, 0.850918);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2023, 'publica', 'anos_iniciais', 4.5, NULL, 198.32, 194.83, 0.850918);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2025, 'estadual', 'anos_finais', 4.1, NULL, 232.32, 237.77, 0.902223);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2025, 'municipal', 'anos_finais', 4.2, NULL, 245.76, 251.27, 0.854403);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2025, 'publica', 'anos_finais', 4.1, NULL, 234.34, 239.8, 0.888528);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2025, 'municipal', 'anos_iniciais', 4.9, NULL, 206.88, 200.89, 0.876595);
INSERT INTO analytics.seed_inep_ideb VALUES (3304904, 2025, 'publica', 'anos_iniciais', 4.9, NULL, 206.88, 200.89, 0.876595);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2021, 'estadual', 'anos_finais', NULL, 5.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2021, 'municipal', 'anos_finais', 3.8, 5.4, 243.85, 246.08, 0.789405);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2021, 'publica', 'anos_finais', 3.8, 5.2, 243.85, 246.08, 0.789405);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2021, 'estadual', 'anos_iniciais', NULL, 6.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2021, 'municipal', 'anos_iniciais', 5.0, 5.5, 213.18, 205.85, 0.857946);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2021, 'publica', 'anos_iniciais', 5.0, 5.7, 213.18, 205.85, 0.857946);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2023, 'municipal', 'anos_finais', 4.4, NULL, 251.93, 253.37, 0.870673);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2023, 'publica', 'anos_finais', 4.4, NULL, 251.93, 253.37, 0.870673);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2023, 'municipal', 'anos_iniciais', 5.1, NULL, 220.95, 212.73, 0.835265);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2023, 'publica', 'anos_iniciais', 5.1, NULL, 220.95, 212.73, 0.835265);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2025, 'municipal', 'anos_finais', 4.1, NULL, 241.48, 238.76, 0.869669);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2025, 'publica', 'anos_finais', 4.1, NULL, 241.48, 238.76, 0.869669);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 231.16, 219.3, 0.921316);
INSERT INTO analytics.seed_inep_ideb VALUES (3305000, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 231.16, 219.3, 0.921316);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2021, 'estadual', 'anos_finais', 4.4, 5.0, 237.94, 241.58, 0.938113);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2021, 'municipal', 'anos_finais', 4.1, 4.6, 233.17, 235.8, 0.913758);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2021, 'publica', 'anos_finais', 4.3, 4.9, 236.94, 240.38, 0.932127);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2021, 'estadual', 'anos_iniciais', NULL, 5.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2021, 'municipal', 'anos_iniciais', 4.6, 5.9, 191.31, 186.22, 0.918184);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2021, 'publica', 'anos_iniciais', 4.6, 5.8, 191.31, 186.22, 0.918184);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2023, 'estadual', 'anos_finais', 3.8, NULL, 228.22, 235.61, 0.853013);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2023, 'municipal', 'anos_finais', 4.2, NULL, 236.27, 242.49, 0.903753);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2023, 'publica', 'anos_finais', 3.8, NULL, 229.43, 236.65, 0.863446);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2023, 'municipal', 'anos_iniciais', 4.9, NULL, 203.71, 195.24, 0.907645);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2023, 'publica', 'anos_iniciais', 4.9, NULL, 203.71, 195.24, 0.907645);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2025, 'estadual', 'anos_finais', 4.0, NULL, 223.93, 226.68, 0.951484);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2025, 'municipal', 'anos_finais', 4.3, NULL, 233.47, 235.78, 0.958419);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2025, 'publica', 'anos_finais', 4.0, NULL, 225.86, 228.53, 0.952723);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2025, 'municipal', 'anos_iniciais', 5.3, NULL, 207.96, 197.16, 0.968587);
INSERT INTO analytics.seed_inep_ideb VALUES (3305109, 2025, 'publica', 'anos_iniciais', 5.3, NULL, 207.96, 197.16, 0.968587);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2021, 'estadual', 'anos_finais', 5.1, 5.1, 259.9, 252.47, 0.979488);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2021, 'publica', 'anos_finais', 5.1, 5.1, 259.9, 252.47, 0.979488);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2021, 'estadual', 'anos_iniciais', NULL, 6.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2021, 'municipal', 'anos_iniciais', 6.8, 7.2, 243.58, 230.04, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2021, 'publica', 'anos_iniciais', 6.8, 7.2, 243.58, 230.04, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2023, 'estadual', 'anos_finais', 5.1, NULL, 263.25, 264.17, 0.931965);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2023, 'publica', 'anos_finais', 5.1, NULL, 263.25, 264.17, 0.931965);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2023, 'municipal', 'anos_iniciais', 6.2, NULL, 226.32, 214.82, 0.995106);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2023, 'publica', 'anos_iniciais', 6.2, NULL, 226.32, 214.82, 0.995106);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2025, 'estadual', 'anos_finais', 5.6, NULL, 274.39, 264.22, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2025, 'publica', 'anos_finais', 5.6, NULL, 274.39, 264.22, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2025, 'municipal', 'anos_iniciais', 7.3, NULL, 261.33, 239.53, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305133, 2025, 'publica', 'anos_iniciais', 7.3, NULL, 261.33, 239.53, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2021, 'estadual', 'anos_finais', NULL, 5.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2021, 'municipal', 'anos_finais', 4.8, 5.4, 249.47, 257.09, 0.940486);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2021, 'publica', 'anos_finais', 4.8, 5.3, 249.47, 257.09, 0.940486);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2021, 'municipal', 'anos_iniciais', 5.6, 5.9, 211.66, 206.42, 0.97156);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2021, 'publica', 'anos_iniciais', 5.6, 5.9, 211.66, 206.42, 0.97156);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2023, 'municipal', 'anos_finais', 4.6, NULL, 256.78, 267.23, 0.861019);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2023, 'publica', 'anos_finais', 4.6, NULL, 256.78, 267.23, 0.861019);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2023, 'municipal', 'anos_iniciais', 5.8, NULL, 221.07, 213.97, 0.946796);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2023, 'publica', 'anos_iniciais', 5.8, NULL, 221.07, 213.97, 0.946796);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2025, 'municipal', 'anos_finais', 4.9, NULL, 261.68, 271.32, 0.882066);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2025, 'publica', 'anos_finais', 4.9, NULL, 261.68, 271.32, 0.882066);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 227.52, 216.08, 0.949195);
INSERT INTO analytics.seed_inep_ideb VALUES (3305158, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 227.52, 216.08, 0.949195);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2021, 'estadual', 'anos_finais', 4.6, 5.3, 246.21, 247.99, 0.946623);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2021, 'municipal', 'anos_finais', NULL, 5.6, NULL, NULL, 0.991995);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2021, 'publica', 'anos_finais', 4.9, 5.4, 248.66, 252.81, 0.980978);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2021, 'estadual', 'anos_iniciais', NULL, 5.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2021, 'municipal', 'anos_iniciais', 5.9, 5.9, 217.22, 213.19, 0.991184);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2021, 'publica', 'anos_iniciais', 5.9, 5.9, 217.22, 213.19, 0.991184);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2023, 'estadual', 'anos_finais', 3.6, NULL, 234.25, 238.07, 0.790795);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2023, 'municipal', 'anos_finais', 4.6, NULL, 264.03, 265.8, 0.845218);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2023, 'publica', 'anos_finais', 4.4, NULL, 256.29, 258.59, 0.833413);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2023, 'municipal', 'anos_iniciais', 5.3, NULL, 223.77, 217.43, 0.859344);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2023, 'publica', 'anos_iniciais', 5.3, NULL, 223.77, 217.43, 0.859344);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2025, 'estadual', 'anos_finais', 4.6, NULL, 242.48, 250.37, 0.939597);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2025, 'municipal', 'anos_finais', 4.7, NULL, 257.09, 258.34, 0.894538);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2025, 'publica', 'anos_finais', 4.7, NULL, 254.0, 256.65, 0.901483);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 228.2, 217.1, 0.963193);
INSERT INTO analytics.seed_inep_ideb VALUES (3305208, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 228.2, 217.1, 0.963193);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2021, 'estadual', 'anos_finais', 4.6, 5.6, 240.96, 240.57, 0.988314);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2021, 'publica', 'anos_finais', 4.6, 5.6, 240.96, 240.57, 0.990383);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2021, 'estadual', 'anos_iniciais', NULL, 8.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2021, 'municipal', 'anos_iniciais', 5.9, 6.2, 216.85, 207.44, 0.996553);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2021, 'publica', 'anos_iniciais', 5.9, 8.4, 216.85, 207.44, 0.996553);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2023, 'estadual', 'anos_finais', 4.2, NULL, 254.54, 260.92, 0.800506);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2023, 'publica', 'anos_finais', 4.3, NULL, 254.54, 260.92, 0.826399);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2023, 'municipal', 'anos_iniciais', 5.3, NULL, 225.16, 218.45, 0.853082);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2023, 'publica', 'anos_iniciais', 5.3, NULL, 225.16, 218.45, 0.853082);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2025, 'estadual', 'anos_finais', 4.7, NULL, 245.84, 240.99, 0.987551);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2025, 'publica', 'anos_finais', 4.7, NULL, 245.84, 240.99, 0.982493);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2025, 'municipal', 'anos_iniciais', 5.8, NULL, 232.83, 222.5, 0.901546);
INSERT INTO analytics.seed_inep_ideb VALUES (3305307, 2025, 'publica', 'anos_iniciais', 5.8, NULL, 232.83, 222.5, 0.901546);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2021, 'estadual', 'anos_finais', 4.5, 5.8, 238.43, 234.03, 0.992066);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2021, 'municipal', 'anos_finais', 4.6, 5.2, 242.63, 241.01, 0.966814);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2021, 'publica', 'anos_finais', 4.5, 5.7, 240.87, 238.08, 0.97665);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2021, 'estadual', 'anos_iniciais', NULL, 6.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2021, 'municipal', 'anos_iniciais', 5.5, 6.1, 209.67, 197.57, 0.98872);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2021, 'publica', 'anos_iniciais', 5.5, 6.3, 209.67, 197.57, 0.98872);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2023, 'estadual', 'anos_finais', 4.1, NULL, 247.33, 242.18, 0.859266);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2023, 'municipal', 'anos_finais', 4.9, NULL, 266.15, 263.58, 0.882647);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2023, 'publica', 'anos_finais', 4.5, NULL, 256.15, 252.21, 0.874486);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2023, 'municipal', 'anos_iniciais', 5.4, NULL, 217.91, 210.58, 0.905782);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2023, 'publica', 'anos_iniciais', 5.4, NULL, 217.91, 210.58, 0.905782);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2025, 'estadual', 'anos_finais', 5.6, NULL, 273.73, 268.14, 0.979763);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2025, 'municipal', 'anos_finais', 5.2, NULL, 263.85, 258.33, 0.975154);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2025, 'publica', 'anos_finais', 5.4, NULL, 267.95, 262.4, 0.97699);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2025, 'municipal', 'anos_iniciais', 5.8, NULL, 223.82, 207.83, 0.967398);
INSERT INTO analytics.seed_inep_ideb VALUES (3305406, 2025, 'publica', 'anos_iniciais', 5.8, NULL, 223.82, 207.83, 0.967398);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2021, 'estadual', 'anos_finais', NULL, 5.1, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2021, 'municipal', 'anos_finais', 4.9, 5.6, 255.99, 257.67, 0.931586);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2021, 'publica', 'anos_finais', 4.9, 5.4, 255.99, 257.67, 0.931586);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2021, 'estadual', 'anos_iniciais', NULL, 5.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2021, 'municipal', 'anos_iniciais', 5.8, 5.6, 220.39, 217.08, 0.952232);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2021, 'publica', 'anos_iniciais', 5.8, 5.6, 220.39, 217.08, 0.952232);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2023, 'municipal', 'anos_finais', 5.3, NULL, 270.06, 272.29, 0.925076);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2023, 'publica', 'anos_finais', 5.3, NULL, 270.06, 272.29, 0.925076);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2023, 'municipal', 'anos_iniciais', 6.0, NULL, 234.39, 224.68, 0.921558);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2023, 'publica', 'anos_iniciais', 6.0, NULL, 234.39, 224.68, 0.921558);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2025, 'municipal', 'anos_finais', 5.3, NULL, 262.94, 266.8, 0.961006);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2025, 'publica', 'anos_finais', 5.3, NULL, 262.94, 266.8, 0.961006);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2025, 'municipal', 'anos_iniciais', 6.5, NULL, 241.72, 227.06, 0.963996);
INSERT INTO analytics.seed_inep_ideb VALUES (3305505, 2025, 'publica', 'anos_iniciais', 6.5, NULL, 241.72, 227.06, 0.963996);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2021, 'estadual', 'anos_finais', NULL, 5.3, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2021, 'municipal', 'anos_finais', 5.2, 5.5, 250.91, 260.95, 0.997249);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2021, 'publica', 'anos_finais', 5.2, 5.4, 250.91, 260.95, 0.997249);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2021, 'estadual', 'anos_iniciais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2021, 'municipal', 'anos_iniciais', 5.5, 5.4, 205.02, 201.49, 0.996398);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2021, 'publica', 'anos_iniciais', 5.5, 5.4, 205.02, 201.49, 0.996398);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2023, 'municipal', 'anos_finais', 4.2, NULL, 239.13, 244.68, 0.892209);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2023, 'publica', 'anos_finais', 4.2, NULL, 239.13, 244.68, 0.892209);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2023, 'municipal', 'anos_iniciais', 4.9, NULL, 203.7, 199.39, 0.893197);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2023, 'publica', 'anos_iniciais', 4.9, NULL, 203.7, 199.39, 0.893197);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2025, 'municipal', 'anos_finais', 4.4, NULL, 239.45, 246.76, 0.925929);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2025, 'publica', 'anos_finais', 4.4, NULL, 239.45, 246.76, 0.925929);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2025, 'municipal', 'anos_iniciais', 5.2, NULL, 205.15, 200.45, 0.941767);
INSERT INTO analytics.seed_inep_ideb VALUES (3305554, 2025, 'publica', 'anos_iniciais', 5.2, NULL, 205.15, 200.45, 0.941767);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2021, 'estadual', 'anos_finais', NULL, 5.7, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2021, 'municipal', 'anos_finais', 4.4, 6.0, 236.92, 245.47, 0.932392);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2021, 'publica', 'anos_finais', 4.4, 5.8, 236.92, 245.47, 0.932392);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2021, 'estadual', 'anos_iniciais', NULL, 6.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2021, 'municipal', 'anos_iniciais', 5.0, 6.1, 196.41, 191.1, 0.958913);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2021, 'publica', 'anos_iniciais', 5.0, 6.0, 196.41, 191.1, 0.958913);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2023, 'municipal', 'anos_finais', 4.0, NULL, 245.2, 245.51, 0.826432);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2023, 'publica', 'anos_finais', 4.0, NULL, 245.2, 245.51, 0.826432);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 212.02, 197.62, 0.887884);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 212.02, 197.62, 0.887884);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2025, 'municipal', 'anos_finais', 4.0, NULL, 229.73, 243.31, 0.885211);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2025, 'publica', 'anos_finais', 4.0, NULL, 229.73, 243.31, 0.885211);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2025, 'municipal', 'anos_iniciais', 5.4, NULL, 219.83, 215.13, 0.897037);
INSERT INTO analytics.seed_inep_ideb VALUES (3305604, 2025, 'publica', 'anos_iniciais', 5.4, NULL, 219.83, 215.13, 0.897037);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2021, 'estadual', 'anos_finais', 5.5, 6.2, 262.22, 269.26, 0.997735);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2021, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2021, 'publica', 'anos_finais', 5.5, 6.0, 262.22, 269.26, 0.994988);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2021, 'estadual', 'anos_iniciais', NULL, 7.6, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2021, 'municipal', 'anos_iniciais', 5.4, 5.4, 206.52, 197.61, 0.973449);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2021, 'publica', 'anos_iniciais', 5.4, 7.2, 206.52, 197.61, 0.973449);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2023, 'estadual', 'anos_finais', 5.2, NULL, 278.54, 272.94, 0.888066);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2023, 'publica', 'anos_finais', 5.1, NULL, 278.54, 272.94, 0.870266);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2023, 'municipal', 'anos_iniciais', 4.8, NULL, 207.43, 189.93, 0.888795);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2023, 'publica', 'anos_iniciais', 4.8, NULL, 207.43, 189.93, 0.888795);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2025, 'estadual', 'anos_finais', 5.7, NULL, 275.47, 274.71, 0.971826);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2025, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2025, 'publica', 'anos_finais', 5.4, NULL, 275.47, 274.71, 0.92208);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2025, 'municipal', 'anos_iniciais', 6.1, NULL, 227.59, 222.1, 0.955895);
INSERT INTO analytics.seed_inep_ideb VALUES (3305703, 2025, 'publica', 'anos_iniciais', 6.1, NULL, 227.59, 222.1, 0.955895);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2021, 'estadual', 'anos_finais', NULL, 4.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2021, 'municipal', 'anos_finais', 4.7, 5.0, 244.01, 247.84, 0.972438);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2021, 'publica', 'anos_finais', 4.7, 4.8, 244.01, 247.84, 0.972438);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2021, 'estadual', 'anos_iniciais', NULL, 5.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2021, 'municipal', 'anos_iniciais', 5.3, 5.5, 205.37, 204.16, 0.952328);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2021, 'publica', 'anos_iniciais', 5.3, 5.5, 205.37, 204.16, 0.952328);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2023, 'municipal', 'anos_finais', 4.0, NULL, 243.95, 248.6, 0.828135);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2023, 'publica', 'anos_finais', 4.0, NULL, 243.95, 248.6, 0.828135);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2023, 'municipal', 'anos_iniciais', 5.0, NULL, 209.29, 200.32, 0.896789);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2023, 'publica', 'anos_iniciais', 5.0, NULL, 209.29, 200.32, 0.896789);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2025, 'municipal', 'anos_finais', 4.4, NULL, 247.55, 254.66, 0.872321);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2025, 'publica', 'anos_finais', 4.4, NULL, 247.55, 254.66, 0.872321);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2025, 'municipal', 'anos_iniciais', 5.2, NULL, 213.23, 202.33, 0.916572);
INSERT INTO analytics.seed_inep_ideb VALUES (3305752, 2025, 'publica', 'anos_iniciais', 5.2, NULL, 213.23, 202.33, 0.916572);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2021, 'estadual', 'anos_finais', 4.7, 5.7, 244.9, 244.97, 0.97786);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2021, 'municipal', 'anos_finais', 5.2, 5.7, 253.8, 256.8, 0.995746);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2021, 'publica', 'anos_finais', 5.1, 5.7, 252.53, 255.1, 0.993743);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2021, 'estadual', 'anos_iniciais', NULL, 5.4, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2021, 'municipal', 'anos_iniciais', 5.7, 6.1, 210.3, 202.66, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2021, 'publica', 'anos_iniciais', 5.7, 6.1, 210.3, 202.66, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2023, 'estadual', 'anos_finais', 4.2, NULL, 240.65, 249.14, 0.865941);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2023, 'municipal', 'anos_finais', 4.5, NULL, 245.08, 251.19, 0.919901);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2023, 'publica', 'anos_finais', 4.5, NULL, 244.41, 250.88, 0.914396);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2023, 'municipal', 'anos_iniciais', 5.8, NULL, 218.18, 209.97, 0.975923);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2023, 'publica', 'anos_iniciais', 5.8, NULL, 218.18, 209.97, 0.975923);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2025, 'estadual', 'anos_finais', 4.8, NULL, 245.43, 251.92, 0.95988);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2025, 'municipal', 'anos_finais', 4.6, NULL, 244.4, 249.19, 0.932594);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2025, 'publica', 'anos_finais', 4.6, NULL, 244.52, 249.53, 0.935113);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2025, 'municipal', 'anos_iniciais', 5.9, NULL, 222.98, 210.45, 0.98416);
INSERT INTO analytics.seed_inep_ideb VALUES (3305802, 2025, 'publica', 'anos_iniciais', 5.9, NULL, 222.98, 210.45, 0.98416);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2021, 'estadual', 'anos_finais', 4.9, 6.2, 246.87, 246.37, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2021, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2021, 'publica', 'anos_finais', 4.9, 6.2, 246.87, 246.37, 0.99497);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2021, 'estadual', 'anos_iniciais', NULL, 9.0, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2021, 'municipal', 'anos_iniciais', 6.2, 7.2, 221.52, 217.95, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2021, 'publica', 'anos_iniciais', 6.2, 7.8, 221.52, 217.95, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2023, 'estadual', 'anos_finais', 4.6, NULL, 249.26, 247.86, 0.932759);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2023, 'publica', 'anos_finais', 4.6, NULL, 249.26, 247.86, 0.91964);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2023, 'municipal', 'anos_iniciais', 5.6, NULL, 225.51, 205.96, 0.929128);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2023, 'publica', 'anos_iniciais', 5.6, NULL, 225.51, 205.96, 0.929128);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2025, 'estadual', 'anos_finais', 4.7, NULL, 246.33, 243.9, 0.975916);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2025, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2025, 'publica', 'anos_finais', 4.7, NULL, 246.33, 243.9, 0.962059);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2025, 'municipal', 'anos_iniciais', 6.8, NULL, 251.03, 230.79, 0.975298);
INSERT INTO analytics.seed_inep_ideb VALUES (3305901, 2025, 'publica', 'anos_iniciais', 6.8, NULL, 251.03, 230.79, 0.975298);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2021, 'estadual', 'anos_finais', 4.4, 5.7, 234.83, 230.21, 0.985728);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2021, 'municipal', 'anos_finais', 4.6, 5.9, 237.8, 243.06, 0.97589);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2021, 'publica', 'anos_finais', 4.5, 5.8, 236.64, 238.02, 0.978693);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2021, 'estadual', 'anos_iniciais', NULL, 6.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2021, 'municipal', 'anos_iniciais', 5.0, 6.1, 193.3, 185.61, 0.984933);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2021, 'publica', 'anos_iniciais', 5.0, 6.2, 193.3, 185.61, 0.984933);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2023, 'estadual', 'anos_finais', 4.0, NULL, 233.03, 237.3, 0.882628);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2023, 'municipal', 'anos_finais', 4.7, NULL, 251.72, 253.86, 0.916114);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2023, 'publica', 'anos_finais', 4.4, NULL, 244.19, 247.19, 0.903065);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2023, 'municipal', 'anos_iniciais', 5.9, NULL, 222.79, 212.08, 0.971466);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2023, 'publica', 'anos_iniciais', 5.9, NULL, 222.79, 212.08, 0.971466);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2025, 'estadual', 'anos_finais', 4.3, NULL, 232.25, 235.98, 0.960873);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2025, 'municipal', 'anos_finais', 4.6, NULL, 244.18, 246.6, 0.955077);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2025, 'publica', 'anos_finais', 4.5, NULL, 239.16, 242.13, 0.955624);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2025, 'municipal', 'anos_iniciais', 6.4, NULL, 233.17, 220.48, 0.991765);
INSERT INTO analytics.seed_inep_ideb VALUES (3306008, 2025, 'publica', 'anos_iniciais', 6.4, NULL, 233.17, 220.48, 0.991765);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2021, 'estadual', 'anos_finais', 5.3, 6.0, 258.53, 263.1, 0.995221);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2021, 'municipal', 'anos_finais', 4.6, 6.1, 252.38, 263.51, 0.87529);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2021, 'publica', 'anos_finais', 4.7, 6.0, 254.79, 263.35, 0.892419);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2021, 'estadual', 'anos_iniciais', NULL, 6.5, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2021, 'municipal', 'anos_iniciais', 5.1, 6.0, 210.62, 204.87, 0.895095);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2021, 'publica', 'anos_iniciais', 5.1, 6.3, 210.62, 204.87, 0.895095);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2023, 'estadual', 'anos_finais', 4.5, NULL, 259.3, 263.58, 0.843711);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2023, 'municipal', 'anos_finais', 4.0, NULL, 241.96, 248.45, 0.834226);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2023, 'publica', 'anos_finais', 4.3, NULL, 249.31, 254.87, 0.838351);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2023, 'municipal', 'anos_iniciais', 4.9, NULL, 217.29, 204.68, 0.835275);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2023, 'publica', 'anos_iniciais', 4.9, NULL, 217.29, 204.68, 0.835275);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2025, 'estadual', 'anos_finais', 5.2, NULL, 261.08, 257.35, 0.977488);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2025, 'municipal', 'anos_finais', 5.0, NULL, 254.13, 261.65, 0.957652);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2025, 'publica', 'anos_finais', 5.1, NULL, 256.78, 260.01, 0.961386);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2025, 'municipal', 'anos_iniciais', 5.7, NULL, 223.55, 209.71, 0.938785);
INSERT INTO analytics.seed_inep_ideb VALUES (3306107, 2025, 'publica', 'anos_iniciais', 5.7, NULL, 223.55, 209.71, 0.938785);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2021, 'estadual', 'anos_finais', 4.0, 5.3, 226.79, 220.63, 0.980564);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2021, 'municipal', 'anos_finais', 4.3, 4.7, 244.22, 233.52, 0.930646);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2021, 'publica', 'anos_finais', 4.1, 5.4, 234.12, 226.05, 0.950508);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2021, 'municipal', 'anos_iniciais', 4.8, 6.7, 202.14, 187.34, 0.926746);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2021, 'publica', 'anos_iniciais', 4.8, 6.7, 202.14, 187.34, 0.926746);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2023, 'estadual', 'anos_finais', 3.7, NULL, 231.86, 228.63, 0.856119);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2023, 'municipal', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2023, 'publica', 'anos_finais', 3.9, NULL, 231.86, 228.63, 0.908096);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2023, 'municipal', 'anos_iniciais', 5.5, NULL, 212.68, 202.42, 0.958131);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2023, 'publica', 'anos_iniciais', 5.5, NULL, 212.68, 202.42, 0.958131);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2025, 'estadual', 'anos_finais', 4.3, NULL, 232.98, 222.07, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2025, 'municipal', 'anos_finais', 5.0, NULL, 259.92, 255.27, 0.952473);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2025, 'publica', 'anos_finais', 4.4, NULL, 243.18, 234.64, 0.959873);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2025, 'municipal', 'anos_iniciais', 6.0, NULL, 225.07, 207.87, 0.988041);
INSERT INTO analytics.seed_inep_ideb VALUES (3306156, 2025, 'publica', 'anos_iniciais', 6.0, NULL, 225.07, 207.87, 0.988041);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2021, 'estadual', 'anos_finais', 5.0, 5.8, 251.09, 251.76, 0.983909);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2021, 'municipal', 'anos_finais', 4.9, 4.8, 238.86, 254.92, 1.0);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2021, 'publica', 'anos_finais', 5.0, 5.6, 249.38, 252.2, 0.989962);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2021, 'estadual', 'anos_iniciais', NULL, 5.8, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2021, 'municipal', 'anos_iniciais', 5.6, 5.8, 204.78, 205.96, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2021, 'publica', 'anos_iniciais', 5.6, 5.6, 204.78, 205.96, 0.999399);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2023, 'estadual', 'anos_finais', 4.2, NULL, 252.15, 259.55, 0.815711);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2023, 'municipal', 'anos_finais', 3.8, NULL, 223.77, 225.75, 0.920177);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2023, 'publica', 'anos_finais', 4.3, NULL, 246.92, 253.32, 0.856922);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2023, 'municipal', 'anos_iniciais', 5.4, NULL, 211.19, 201.52, 0.950648);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2023, 'publica', 'anos_iniciais', 5.4, NULL, 211.19, 201.52, 0.950648);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2025, 'estadual', 'anos_finais', 5.0, NULL, 253.88, 253.17, 0.977369);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2025, 'municipal', 'anos_finais', 5.2, NULL, 259.37, 264.14, 0.962122);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2025, 'publica', 'anos_finais', 5.0, NULL, 254.84, 255.09, 0.971297);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2025, 'municipal', 'anos_iniciais', 5.8, NULL, 223.37, 211.86, 0.954593);
INSERT INTO analytics.seed_inep_ideb VALUES (3306206, 2025, 'publica', 'anos_iniciais', 5.8, NULL, 223.37, 211.86, 0.954593);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2021, 'estadual', 'anos_finais', NULL, 5.2, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2021, 'municipal', 'anos_finais', 5.3, 6.1, 261.77, 265.06, 0.967987);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2021, 'publica', 'anos_finais', 5.3, 5.9, 261.77, 265.06, 0.967737);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2021, 'estadual', 'anos_iniciais', NULL, 6.9, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2021, 'municipal', 'anos_iniciais', 6.1, 6.7, 226.03, 221.88, 0.972971);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2021, 'publica', 'anos_iniciais', 6.1, 6.7, 226.03, 221.88, 0.973008);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2023, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2023, 'municipal', 'anos_finais', 5.4, NULL, 273.08, 274.37, 0.938284);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2023, 'publica', 'anos_finais', 5.4, NULL, 273.08, 274.37, 0.938792);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2023, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2023, 'municipal', 'anos_iniciais', 6.1, NULL, 237.86, 229.1, 0.911416);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2023, 'publica', 'anos_iniciais', 6.1, NULL, 237.86, 229.1, 0.911416);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2025, 'estadual', 'anos_finais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2025, 'municipal', 'anos_finais', 5.3, NULL, 267.2, 269.23, 0.939727);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2025, 'publica', 'anos_finais', 5.3, NULL, 267.2, 269.23, 0.937473);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2025, 'estadual', 'anos_iniciais', NULL, NULL, NULL, NULL, NULL);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2025, 'municipal', 'anos_iniciais', 6.3, NULL, 240.14, 228.68, 0.938715);
INSERT INTO analytics.seed_inep_ideb VALUES (3306305, 2025, 'publica', 'anos_iniciais', 6.3, NULL, 240.14, 228.68, 0.938715);


--
-- Data for Name: seed_inep_ideb_estados; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_inep_ideb_estados VALUES (11, 'RO', 2021, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (11, 'RO', 2023, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (11, 'RO', 2025, 'publica', 'anos_iniciais', 5.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (11, 'RO', 2021, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (11, 'RO', 2023, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (11, 'RO', 2025, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (12, 'AC', 2021, 'publica', 'anos_iniciais', 5.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (12, 'AC', 2023, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (12, 'AC', 2025, 'publica', 'anos_iniciais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (12, 'AC', 2021, 'publica', 'anos_finais', 4.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (12, 'AC', 2023, 'publica', 'anos_finais', 4.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (12, 'AC', 2025, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (13, 'AM', 2021, 'publica', 'anos_iniciais', 5.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (13, 'AM', 2023, 'publica', 'anos_iniciais', 5.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (13, 'AM', 2025, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (13, 'AM', 2021, 'publica', 'anos_finais', 4.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (13, 'AM', 2023, 'publica', 'anos_finais', 4.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (13, 'AM', 2025, 'publica', 'anos_finais', 4.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (14, 'RR', 2021, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (14, 'RR', 2023, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (14, 'RR', 2025, 'publica', 'anos_iniciais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (14, 'RR', 2021, 'publica', 'anos_finais', 4.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (14, 'RR', 2023, 'publica', 'anos_finais', 4.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (14, 'RR', 2025, 'publica', 'anos_finais', 4.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (15, 'PA', 2021, 'publica', 'anos_iniciais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (15, 'PA', 2023, 'publica', 'anos_iniciais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (15, 'PA', 2025, 'publica', 'anos_iniciais', 5.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (15, 'PA', 2021, 'publica', 'anos_finais', 4.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (15, 'PA', 2023, 'publica', 'anos_finais', 4.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (15, 'PA', 2025, 'publica', 'anos_finais', 4.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (16, 'AP', 2021, 'publica', 'anos_iniciais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (16, 'AP', 2023, 'publica', 'anos_iniciais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (16, 'AP', 2025, 'publica', 'anos_iniciais', 5.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (16, 'AP', 2021, 'publica', 'anos_finais', 4.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (16, 'AP', 2023, 'publica', 'anos_finais', 4.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (16, 'AP', 2025, 'publica', 'anos_finais', 4.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (17, 'TO', 2021, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (17, 'TO', 2023, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (17, 'TO', 2025, 'publica', 'anos_iniciais', 5.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (17, 'TO', 2021, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (17, 'TO', 2023, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (17, 'TO', 2025, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (21, 'MA', 2021, 'publica', 'anos_iniciais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (21, 'MA', 2023, 'publica', 'anos_iniciais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (21, 'MA', 2025, 'publica', 'anos_iniciais', 5.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (21, 'MA', 2021, 'publica', 'anos_finais', 4.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (21, 'MA', 2023, 'publica', 'anos_finais', 4.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (21, 'MA', 2025, 'publica', 'anos_finais', 4.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (22, 'PI', 2021, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (22, 'PI', 2023, 'publica', 'anos_iniciais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (22, 'PI', 2025, 'publica', 'anos_iniciais', 5.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (22, 'PI', 2021, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (22, 'PI', 2023, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (22, 'PI', 2025, 'publica', 'anos_finais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (23, 'CE', 2021, 'publica', 'anos_iniciais', 6.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (23, 'CE', 2023, 'publica', 'anos_iniciais', 6.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (23, 'CE', 2025, 'publica', 'anos_iniciais', 6.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (23, 'CE', 2021, 'publica', 'anos_finais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (23, 'CE', 2023, 'publica', 'anos_finais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (23, 'CE', 2025, 'publica', 'anos_finais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (24, 'RN', 2021, 'publica', 'anos_iniciais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (24, 'RN', 2023, 'publica', 'anos_iniciais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (24, 'RN', 2025, 'publica', 'anos_iniciais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (24, 'RN', 2021, 'publica', 'anos_finais', 4.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (24, 'RN', 2023, 'publica', 'anos_finais', 4.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (24, 'RN', 2025, 'publica', 'anos_finais', 4.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (25, 'PB', 2021, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (25, 'PB', 2023, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (25, 'PB', 2025, 'publica', 'anos_iniciais', 5.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (25, 'PB', 2021, 'publica', 'anos_finais', 4.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (25, 'PB', 2023, 'publica', 'anos_finais', 4.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (25, 'PB', 2025, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (26, 'PE', 2021, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (26, 'PE', 2023, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (26, 'PE', 2025, 'publica', 'anos_iniciais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (26, 'PE', 2021, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (26, 'PE', 2023, 'publica', 'anos_finais', 4.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (26, 'PE', 2025, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (27, 'AL', 2021, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (27, 'AL', 2023, 'publica', 'anos_iniciais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (27, 'AL', 2025, 'publica', 'anos_iniciais', 5.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (27, 'AL', 2021, 'publica', 'anos_finais', 4.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (27, 'AL', 2023, 'publica', 'anos_finais', 4.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (27, 'AL', 2025, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (28, 'SE', 2021, 'publica', 'anos_iniciais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (28, 'SE', 2023, 'publica', 'anos_iniciais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (28, 'SE', 2025, 'publica', 'anos_iniciais', 5.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (28, 'SE', 2021, 'publica', 'anos_finais', 4.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (28, 'SE', 2023, 'publica', 'anos_finais', 4.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (28, 'SE', 2025, 'publica', 'anos_finais', 4.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (29, 'BA', 2021, 'publica', 'anos_iniciais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (29, 'BA', 2023, 'publica', 'anos_iniciais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (29, 'BA', 2025, 'publica', 'anos_iniciais', 5.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (29, 'BA', 2021, 'publica', 'anos_finais', 4.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (29, 'BA', 2023, 'publica', 'anos_finais', 4.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (29, 'BA', 2025, 'publica', 'anos_finais', 4.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (31, 'MG', 2021, 'publica', 'anos_iniciais', 6.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (31, 'MG', 2023, 'publica', 'anos_iniciais', 6.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (31, 'MG', 2025, 'publica', 'anos_iniciais', 6.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (31, 'MG', 2021, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (31, 'MG', 2023, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (31, 'MG', 2025, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (32, 'ES', 2021, 'publica', 'anos_iniciais', 5.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (32, 'ES', 2023, 'publica', 'anos_iniciais', 6.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (32, 'ES', 2025, 'publica', 'anos_iniciais', 6.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (32, 'ES', 2021, 'publica', 'anos_finais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (32, 'ES', 2023, 'publica', 'anos_finais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (32, 'ES', 2025, 'publica', 'anos_finais', 5.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (33, 'RJ', 2021, 'publica', 'anos_iniciais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (33, 'RJ', 2023, 'publica', 'anos_iniciais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (33, 'RJ', 2025, 'publica', 'anos_iniciais', 5.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (33, 'RJ', 2021, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (33, 'RJ', 2023, 'publica', 'anos_finais', 4.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (33, 'RJ', 2025, 'publica', 'anos_finais', 4.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (35, 'SP', 2021, 'publica', 'anos_iniciais', 6.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (35, 'SP', 2023, 'publica', 'anos_iniciais', 6.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (35, 'SP', 2025, 'publica', 'anos_iniciais', 6.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (35, 'SP', 2021, 'publica', 'anos_finais', 5.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (35, 'SP', 2023, 'publica', 'anos_finais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (35, 'SP', 2025, 'publica', 'anos_finais', 5.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (41, 'PR', 2021, 'publica', 'anos_iniciais', 6.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (41, 'PR', 2023, 'publica', 'anos_iniciais', 6.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (41, 'PR', 2025, 'publica', 'anos_iniciais', 6.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (41, 'PR', 2021, 'publica', 'anos_finais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (41, 'PR', 2023, 'publica', 'anos_finais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (41, 'PR', 2025, 'publica', 'anos_finais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (42, 'SC', 2021, 'publica', 'anos_iniciais', 6.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (42, 'SC', 2023, 'publica', 'anos_iniciais', 6.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (42, 'SC', 2025, 'publica', 'anos_iniciais', 6.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (42, 'SC', 2021, 'publica', 'anos_finais', 5.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (42, 'SC', 2023, 'publica', 'anos_finais', 5.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (42, 'SC', 2025, 'publica', 'anos_finais', 5.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (43, 'RS', 2021, 'publica', 'anos_iniciais', 6.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (43, 'RS', 2023, 'publica', 'anos_iniciais', 5.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (43, 'RS', 2025, 'publica', 'anos_iniciais', 6.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (43, 'RS', 2021, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (43, 'RS', 2023, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (43, 'RS', 2025, 'publica', 'anos_finais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (50, 'MS', 2021, 'publica', 'anos_iniciais', 5.5);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (50, 'MS', 2023, 'publica', 'anos_iniciais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (50, 'MS', 2025, 'publica', 'anos_iniciais', 5.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (50, 'MS', 2021, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (50, 'MS', 2023, 'publica', 'anos_finais', 4.6);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (50, 'MS', 2025, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (51, 'MT', 2021, 'publica', 'anos_iniciais', 5.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (51, 'MT', 2023, 'publica', 'anos_iniciais', 5.7);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (51, 'MT', 2025, 'publica', 'anos_iniciais', 5.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (51, 'MT', 2021, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (51, 'MT', 2023, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (51, 'MT', 2025, 'publica', 'anos_finais', 5.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (52, 'GO', 2021, 'publica', 'anos_iniciais', 6.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (52, 'GO', 2023, 'publica', 'anos_iniciais', 6.1);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (52, 'GO', 2025, 'publica', 'anos_iniciais', 6.2);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (52, 'GO', 2021, 'publica', 'anos_finais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (52, 'GO', 2023, 'publica', 'anos_finais', 5.3);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (52, 'GO', 2025, 'publica', 'anos_finais', 5.4);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (53, 'DF', 2021, 'publica', 'anos_iniciais', 5.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (53, 'DF', 2023, 'publica', 'anos_iniciais', 5.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (53, 'DF', 2025, 'publica', 'anos_iniciais', 6.0);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (53, 'DF', 2021, 'publica', 'anos_finais', 4.9);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (53, 'DF', 2023, 'publica', 'anos_finais', 4.8);
INSERT INTO analytics.seed_inep_ideb_estados VALUES (53, 'DF', 2025, 'publica', 'anos_finais', 5.0);


--
-- Data for Name: seed_natividade_prefeitura_orgaos; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_natividade_prefeitura_orgaos VALUES ('natividade_prefeitura', '1', 'PREFEITURA MUNICIPAL DE NATIVIDADE', '28920304000196');
INSERT INTO analytics.seed_natividade_prefeitura_orgaos VALUES ('natividade_prefeitura', '3', 'FUNDO MUNICIPAL DE SAÚDE', '12396542000104');
INSERT INTO analytics.seed_natividade_prefeitura_orgaos VALUES ('natividade_prefeitura', '5', 'FUNDO MUNICIPAL DE EDUCAÇÃO E CULTURA', '23570466000128');
INSERT INTO analytics.seed_natividade_prefeitura_orgaos VALUES ('natividade_prefeitura', '4', 'FUNDO MUNICIPAL DE ASSISTÊNCIA SOCIAL', '14789074000163');
INSERT INTO analytics.seed_natividade_prefeitura_orgaos VALUES ('natividade_prefeitura', '9', 'FUNDO MUNICIPAL DE MEIO AMBIENTE', '63642426000169');
INSERT INTO analytics.seed_natividade_prefeitura_orgaos VALUES ('natividade_prefeitura', '7', 'FUNDO MUNICIPAL DO IDOSO', ' 43889802000107');
INSERT INTO analytics.seed_natividade_prefeitura_orgaos VALUES ('natividade_prefeitura', '6', 'NATPREVI', '01709035000167');


--
-- Data for Name: seed_natividade_prefeitura_siconfi_orgaos; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_natividade_prefeitura_siconfi_orgaos VALUES ('natividade_prefeitura', '10131', 'livre', '1', 'Recursos Livres e Ordinários da Prefeitura');
INSERT INTO analytics.seed_natividade_prefeitura_siconfi_orgaos VALUES ('natividade_prefeitura', '10131', 'saude', '3', 'Fundo Municipal de Saúde');
INSERT INTO analytics.seed_natividade_prefeitura_siconfi_orgaos VALUES ('natividade_prefeitura', '10131', 'educacao', '5', 'Fundo Municipal de Educação e Cultura');
INSERT INTO analytics.seed_natividade_prefeitura_siconfi_orgaos VALUES ('natividade_prefeitura', '10131', 'assistencia_social', '4', 'Fundo Municipal de Assistência Social');
INSERT INTO analytics.seed_natividade_prefeitura_siconfi_orgaos VALUES ('natividade_prefeitura', '10131', 'meio_ambiente', '9', 'Fundo Municipal de Meio Ambiente');
INSERT INTO analytics.seed_natividade_prefeitura_siconfi_orgaos VALUES ('natividade_prefeitura', '10131', 'outros_vinculados', '1', 'Convênios e Outras Vinculações da Prefeitura');


--
-- Data for Name: seed_natureza_despesa; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_natureza_despesa VALUES ('3120', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '20', 'Transferências à União');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3130', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '30', 'Transferências a Estados e ao DF');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3140', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '40', 'Transferências a Municípios');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3150', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3170', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '70', 'Transferências a Consórcios Públicos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3190', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '90', 'Aplicações Diretas');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3191', '3', 'Despesas Correntes', '1', 'Pessoal e Encargos Sociais', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3220', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '20', 'Transferências à União');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3230', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '30', 'Transferências a Estados e ao DF');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3240', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '40', 'Transferências a Municípios');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3250', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3270', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '70', 'Transferências a Consórcios Públicos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3290', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '90', 'Aplicações Diretas');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3291', '3', 'Despesas Correntes', '2', 'Juros e Encargos da Dívida', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3320', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '20', 'Transferências à União');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3330', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '30', 'Transferências a Estados e ao DF');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3340', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '40', 'Transferências a Municípios');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3350', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3370', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '70', 'Transferências a Consórcios Públicos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3390', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '90', 'Aplicações Diretas');
INSERT INTO analytics.seed_natureza_despesa VALUES ('3391', '3', 'Despesas Correntes', '3', 'Outras Despesas Correntes', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4420', '4', 'Despesas de Capital', '4', 'Investimentos', '20', 'Transferências à União');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4430', '4', 'Despesas de Capital', '4', 'Investimentos', '30', 'Transferências a Estados e ao DF');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4440', '4', 'Despesas de Capital', '4', 'Investimentos', '40', 'Transferências a Municípios');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4450', '4', 'Despesas de Capital', '4', 'Investimentos', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4470', '4', 'Despesas de Capital', '4', 'Investimentos', '70', 'Transferências a Consórcios Públicos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4490', '4', 'Despesas de Capital', '4', 'Investimentos', '90', 'Aplicações Diretas');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4491', '4', 'Despesas de Capital', '4', 'Investimentos', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4520', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '20', 'Transferências à União');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4530', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '30', 'Transferências a Estados e ao DF');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4540', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '40', 'Transferências a Municípios');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4550', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4570', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '70', 'Transferências a Consórcios Públicos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4590', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '90', 'Aplicações Diretas');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4591', '4', 'Despesas de Capital', '5', 'Inversões Financeiras', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4620', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '20', 'Transferências à União');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4630', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '30', 'Transferências a Estados e ao DF');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4640', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '40', 'Transferências a Municípios');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4650', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '50', 'Transferências a Entidades Privadas sem Fins Lucrativos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4670', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '70', 'Transferências a Consórcios Públicos');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4690', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '90', 'Aplicações Diretas');
INSERT INTO analytics.seed_natureza_despesa VALUES ('4691', '4', 'Despesas de Capital', '6', 'Amortização da Dívida', '91', 'Aplicação Direta Decorrente de Operação entre Órgãos');


--
-- Data for Name: seed_naturezas_despesa_stn; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.71.70.00', 'Rateio pela Participação em Consórcio Público', '70', 'consorcios_publicos', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.13.00', 'Obrigações Patronais', '13', 'previdencia', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.14.00', 'Diárias - Civil', '14', 'diarias_viagens', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.14.01', 'Diárias no País', '14', 'diarias_viagens', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.30.01', 'Combustíveis e Lubrificantes Automotivos', '30', 'combustivel_frota', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.30.07', 'Gêneros de Alimentação', '30', 'generos_alimenticios', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.30.39', 'Material para Manutenção de Veículos', '30', 'pecas_manutencao_frota', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.33.00', 'Passagens e Despesas com Locomoção', '33', 'diarias_viagens', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.33.01', 'Passagens no País', '33', 'diarias_viagens', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.35.00', 'Serviços de Consultoria', '35', 'consultoria_tecnica', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.36.02', 'Diárias a Colaboradores Eventuais no País', '36', 'diarias_viagens', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.36.06', 'Serviços Técnicos Profissionais', '36', 'plantoes_medicos', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.36.15', 'Locação de Imóveis', '36', 'locacao_imoveis', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.36.16', 'Locação de Bens Móveis', '36', 'locacao_maquinas_veiculos', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.36.19', 'Locação de Máquinas e Equipamentos', '36', 'locacao_maquinas_veiculos', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.37.00', 'Locação de Mão-de-Obra', '37', 'terceirizacao_mao_obra', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.05', 'Serviços Técnicos Profissionais', '39', 'consultoria_tecnica', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.10', 'Locação de Imóveis', '39', 'locacao_imoveis', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.12', 'Locação de Máquinas e Equipamentos', '39', 'locacao_maquinas_veiculos', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.13', 'Locação de Veículos', '39', 'locacao_maquinas_veiculos', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.14', 'Locação de Bens Móveis e Outras Naturezas e Intangíveis', '39', 'locacao_imoveis', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.21', 'Serviços de Áudio Vídeo e Foto', '39', 'eventos_festas', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.22', 'Exposições Congressos e Conferências', '39', 'eventos_festas', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.23', 'Festividades e Homenagens', '39', 'eventos_festas', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.44', 'Serviços de Limpeza Urbana e Manejo de Resíduos Sólidos', '39', 'limpeza_residuos', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.39.50', 'Serviços Médico-Hospitalares Odontológicos e Laboratoriais', '39', 'plantoes_medicos', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.48.00', 'Outros Auxílios Financeiros a Pessoas Físicas', '48', 'aluguel_social', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('3.3.90.91.00', 'Sentenças Judiciais', '91', 'bloqueios_sentencas', false);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('4.4.90.51.00', 'Obras e Instalações', '51', 'obras_infraestrutura', true);
INSERT INTO analytics.seed_naturezas_despesa_stn VALUES ('4.4.90.51.91', 'Obras em Andamento', '51', 'obras_infraestrutura', true);


--
-- Data for Name: seed_pncp_licitacoes_mapeamento; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2024, '000050', 2024, 1, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2024, '000054', 2024, 2, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2025, '000761', 2025, 1, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2025, '000983', 2025, 3, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2025, '001101', 2025, 7, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2025, '001102', 2025, 6, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000004', 2026, 2, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000120', 2026, 4, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000121', 2026, 5, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000122', 2026, 6, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000123', 2026, 7, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000125', 2026, 8, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000126', 2026, 10, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000127', 2026, 9, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000288', 2026, 11, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000289', 2026, 12, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000290', 2026, 13, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000291', 2026, 14, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000292', 2026, 15, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000514', 2026, 17, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000515', 2026, 18, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000480', 2026, 19, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000516', 2026, 20, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000517', 2026, 21, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000518', 2026, 22, 'alta');
INSERT INTO analytics.seed_pncp_licitacoes_mapeamento VALUES ('porciuncula_prefeitura', 2026, '000519', 2026, 23, 'alta');


--
-- Data for Name: seed_porciuncula_prefeitura_orgaos; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', '7', 'PREFEITURA MUNICIPAL DE PORCIÚNCULA', '28920999000106');
INSERT INTO analytics.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', '2', 'FUNDO MUNICIPAL DE SAUDE', '12097798000110');
INSERT INTO analytics.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', '8', 'FUNDO MUNICIPAL DE EDUCAÇÃO', '32169444000141');
INSERT INTO analytics.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', '3', 'FUNDO MUNICIPAL DE ASSISTENCIA SOCIAL', '12124826000141');
INSERT INTO analytics.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', '9', 'FUNDO MUNICIPAL DE DEFESA AMBIENTAL', '43472312000100');
INSERT INTO analytics.seed_porciuncula_prefeitura_orgaos VALUES ('porciuncula_prefeitura', '10', 'FUNDO DE SOLIDARIEDADE - FUNDESOL', '43849391000126');


--
-- Data for Name: seed_porciuncula_prefeitura_siconfi_orgaos; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_porciuncula_prefeitura_siconfi_orgaos VALUES ('porciuncula_prefeitura', '10131', 'livre', '7', 'Recursos Livres e Ordinários da Prefeitura');
INSERT INTO analytics.seed_porciuncula_prefeitura_siconfi_orgaos VALUES ('porciuncula_prefeitura', '10131', 'saude', '2', 'Fundo Municipal de Saúde');
INSERT INTO analytics.seed_porciuncula_prefeitura_siconfi_orgaos VALUES ('porciuncula_prefeitura', '10131', 'educacao', '8', 'Fundo Municipal de Educação');
INSERT INTO analytics.seed_porciuncula_prefeitura_siconfi_orgaos VALUES ('porciuncula_prefeitura', '10131', 'assistencia_social', '3', 'Fundo Municipal de Assistência Social');
INSERT INTO analytics.seed_porciuncula_prefeitura_siconfi_orgaos VALUES ('porciuncula_prefeitura', '10131', 'meio_ambiente', '9', 'Fundo Municipal de Defesa Ambiental');
INSERT INTO analytics.seed_porciuncula_prefeitura_siconfi_orgaos VALUES ('porciuncula_prefeitura', '10131', 'outros_vinculados', '7', 'Convênios e Outras Vinculações da Prefeitura');


--
-- Data for Name: seed_portais; Type: TABLE DATA; Schema: analytics; Owner: -
--

INSERT INTO analytics.seed_portais VALUES ('porciuncula_prefeitura', 'Prefeitura de Porciúncula', 'RJ', 'https://transparencia.porciuncula.rj.gov.br/transparencia/', 'https://transparencia.porciuncula.rj.gov.br', 'PORCIUNCULA', 2021, '7', 'brasao-porciuncula.png', true, 'CAPREM', 'Caixa de Aposentadoria e Pensões dos Servidores Públicos de Porciúncula', '01180031000134', '[{"slug":"saude","titulo":"Saúde","descricao":"Execução orçamentária e fornecedores da saúde","icone":"HeartPulse"},{"slug":"previdencia","titulo":"CAPREM","descricao":"Previdência municipal e sustentabilidade atuarial","icone":"Landmark"}]', 3304102, true, 'Caixa de Assistência a Saúde dos Servidores Municipais de Porciúncula', 'CASP', '07573075000100');
INSERT INTO analytics.seed_portais VALUES ('natividade_prefeitura', 'Prefeitura de Natividade', 'RJ', 'https://portal-pm-natividade.transpgp.com.br/transparencia/', 'https://transparencia.natividade.rj.gov.br', 'NATIVIDADE', 2021, '1', 'brasao-natividade.png', true, 'NATPREVI', 'Instituto de Previdência dos Servidores Públicos do Município de Natividade - NATPREVI', '01709035000167', '[{"slug":"saude","titulo":"Saúde","descricao":"Execução orçamentária e fornecedores da saúde","icone":"HeartPulse"},{"slug":"previdencia","titulo":"NATPREVI","descricao":"Previdência municipal e sustentabilidade atuarial","icone":"Landmark"}]', 3303104, false, NULL, NULL, NULL);


--
-- PostgreSQL database dump complete
--


